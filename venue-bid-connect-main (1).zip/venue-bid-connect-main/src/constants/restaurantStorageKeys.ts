
export const RESTAURANT_STORAGE_KEY = "venueApp_restaurant";
export const DINING_SECTIONS_STORAGE_KEY = "venueApp_restaurant_sections";
export const DINING_PACKAGES_STORAGE_KEY = "venueApp_restaurant_packages";
