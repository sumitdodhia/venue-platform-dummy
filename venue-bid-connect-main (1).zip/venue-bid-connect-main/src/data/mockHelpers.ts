
import { faker } from '@faker-js/faker';
import { BaseVenue } from '@/types/venue';

// Common function to generate a basic venue
export const generateBaseVenue = (category: 'rooms' | 'conference' | 'restaurants'): BaseVenue => {
  // Generate a consistent total number of reviews
  const totalReviews = faker.number.int({ min: 10, max: 200 });
  
  // Generate a consistent Google Maps location
  const longitude = faker.location.longitude();
  const latitude = faker.location.latitude();
  const googleLocation = `https://maps.google.com/?q=${latitude},${longitude}`;
  
  // Generate placeholder photos
  const photos = Array.from({ length: faker.number.int({ min: 2, max: 5 }) }, () => 
    faker.image.urlPicsumPhotos({ width: 1200, height: 800 })
  );
  
  // Generate a base venue with common properties
  return {
    id: faker.string.uuid(),
    title: faker.company.name(),
    location: `${faker.location.city()}, ${faker.location.country()}`,
    price: faker.number.int({ min: 50, max: 500 }),
    priceLabel: category === 'rooms' ? '/night' : category === 'conference' ? '/day' : '/person',
    rating: faker.number.float({ min: 3, max: 5, fractionDigits: 1 }),
    imageUrl: faker.image.urlPicsumPhotos({ width: 640, height: 480 }),
    tags: Array.from({ length: faker.number.int({ min: 1, max: 4 }) }, () => faker.word.adjective()),
    category: category,
    totalReviews: totalReviews,
    googleLocation: googleLocation,
    photos: photos,
    facilities: Array.from(
      { length: faker.number.int({ min: 3, max: 8 }) },
      () => faker.helpers.arrayElement([
        'Free Wi-Fi', 'Parking', 'Air Conditioning', 'Restaurant', 
        'Meeting Room', 'Fitness Center', 'Swimming Pool', 'Business Center',
        'Airport Shuttle', 'Concierge Service', 'Laundry', 'Room Service',
        'Bar/Lounge', 'Spa', 'Pet Friendly', 'Breakfast Included'
      ])
    ),
    description: faker.lorem.paragraphs(3),
  };
};
