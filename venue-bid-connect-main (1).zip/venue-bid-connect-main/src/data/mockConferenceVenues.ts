
import { ConferenceVenue } from '@/types/venue';
import { generateBaseVenue } from './mockHelpers';

export const getConferenceVenues = (): ConferenceVenue[] => {
  return [
    {
      ...generateBaseVenue('conference'),
      id: 'conference-1',
      title: 'Metropolitan Convention Center',
      location: 'Chicago, USA',
      price: 2500,
      priceLabel: '/day',
      rating: 4.7,
      imageUrl: 'https://images.unsplash.com/photo-1431540015161-0bf868a2d407?q=80&w=1770&auto=format',
      photos: [
        'https://images.unsplash.com/photo-1431540015161-0bf868a2d407?q=80&w=1770&auto=format',
        'https://images.unsplash.com/photo-1517457373958-b7bdd4587205?q=80&w=1769&auto=format',
        'https://images.unsplash.com/photo-1576846804693-1045847385364?q=80&w=1770&auto=format',
        'https://images.unsplash.com/photo-1505373877841-8d25f7d46678?q=80&w=1712&auto=format'
      ],
      tags: ['Large Scale', 'AV Equipment', 'Catering'],
      category: 'conference',
      capacity: 500,
      facilities: ['AV Equipment', 'Staging', 'Catering Services', 'Breakout Rooms', 'Free Wi-Fi', 'Parking'],
      description: 'Metropolitan Convention Center is Chicago\'s premier venue for large-scale corporate events, conferences, and exhibitions. With over 50,000 square feet of flexible event space, we can accommodate gatherings of any size and configuration.\n\nOur state-of-the-art technology includes integrated audio-visual systems, high-definition projection, and broadcast capabilities. Our experienced event planning team can assist with every aspect of your event, from initial concept to final execution.\n\nStrategically located in downtown Chicago with excellent transportation links and nearby accommodations.',
      totalReviews: 145,
      googleLocation: 'https://maps.google.com/?q=41.8781,-87.6298',
      venueTypes: [
        {
          id: 'venue-type-1-1',
          name: 'Grand Ballroom',
          type: 'Ballroom',
          description: 'Our flagship space with 20,000 square feet of column-free space, 24-foot ceilings, and capacity for up to 500 guests in theater-style seating. Features built-in stage, advanced lighting systems, and multiple entry points.',
          maxCapacity: 500,
          priceFrom: 2500,
          photos: [
            'https://images.unsplash.com/photo-1431540015161-0bf868a2d407?q=80&w=1770&auto=format',
            'https://images.unsplash.com/photo-1517457373958-b7bdd4587205?q=80&w=1769&auto=format'
          ]
        },
        {
          id: 'venue-type-1-2',
          name: 'Executive Board Room',
          type: 'Meeting Room',
          description: 'Sophisticated meeting room with solid oak conference table, leather executive chairs, and integrated technology. Features video conferencing capabilities and digital whiteboard.',
          maxCapacity: 20,
          priceFrom: 800,
          photos: [
            'https://images.unsplash.com/photo-1576846804693-1045847385364?q=80&w=1770&auto=format'
          ]
        },
        {
          id: 'venue-type-1-3',
          name: 'Breakout Rooms',
          type: 'Multiple Rooms',
          description: 'Four configurable rooms that can be used individually or combined. Perfect for workshop sessions, team meetings, or as support spaces for larger events.',
          maxCapacity: 40,
          priceFrom: 500,
          photos: [
            'https://images.unsplash.com/photo-1505373877841-8d25f7d46678?q=80&w=1712&auto=format'
          ]
        }
      ],
      facilitiesOffered: [
        {
          name: 'AV Package',
          isCharged: true,
          rate: 300,
          chargeType: 'Per Event'
        },
        {
          name: 'Coffee Breaks',
          isCharged: true,
          rate: 15,
          chargeType: 'Per Person'
        },
        {
          name: 'Wi-Fi',
          isCharged: false,
          chargeType: 'Inclusive'
        },
        {
          name: 'Basic Staging',
          isCharged: false,
          chargeType: 'Inclusive'
        },
        {
          name: 'Advanced Lighting',
          isCharged: true,
          rate: 450,
          chargeType: 'Per Event'
        }
      ]
    },
    {
      ...generateBaseVenue('conference'),
      id: 'conference-2',
      title: 'Tech Innovation Hub',
      location: 'San Francisco, USA',
      price: 1800,
      priceLabel: '/day',
      rating: 4.8,
      imageUrl: 'https://images.unsplash.com/photo-1505373877841-8d25f7d46678?q=80&w=1712&auto=format',
      photos: [
        'https://images.unsplash.com/photo-1505373877841-8d25f7d46678?q=80&w=1712&auto=format',
        'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?q=80&w=1770&auto=format',
        'https://images.unsplash.com/photo-1606761568499-6d2451b23c66?q=80&w=1774&auto=format',
        'https://images.unsplash.com/photo-1492571350019-22de08371fd3?q=80&w=1753&auto=format'
      ],
      tags: ['Modern', 'Tech-Ready', 'Flexible Space'],
      category: 'conference',
      capacity: 150,
      facilities: ['Ultra-fast Wi-Fi', 'Video Conferencing', 'Interactive Displays', 'Breakout Areas', 'Catering'],
      description: 'Tech Innovation Hub is a cutting-edge venue designed for forward-thinking companies and tech-focused events. Our spaces combine modern design with state-of-the-art technology to facilitate collaboration and innovation.\n\nOur venue features gigabit Wi-Fi, seamless video conferencing between rooms, interactive touchscreen displays, and modular furniture that can be configured to suit your event\'s specific needs.\n\nLocated in the heart of San Francisco\'s tech district, our venue embodies the innovative spirit of Silicon Valley.',
      totalReviews: 98,
      googleLocation: 'https://maps.google.com/?q=37.7749,-122.4194',
      venueTypes: [
        {
          id: 'venue-type-2-1',
          name: 'Innovation Hall',
          type: 'Open Space',
          description: 'Open concept space with modular furniture that can be arranged in various configurations. Features floor-to-ceiling windows, interactive touchscreen walls, and immersive audio system.',
          maxCapacity: 150,
          priceFrom: 1800,
          photos: [
            'https://images.unsplash.com/photo-1505373877841-8d25f7d46678?q=80&w=1712&auto=format',
            'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?q=80&w=1770&auto=format'
          ]
        },
        {
          id: 'venue-type-2-2',
          name: 'Collaboration Pods',
          type: 'Meeting Spaces',
          description: 'Set of four glass-enclosed meeting pods, each equipped with video conferencing technology and digital collaboration tools. Perfect for breakout sessions or team discussions.',
          maxCapacity: 8,
          priceFrom: 400,
          photos: [
            'https://images.unsplash.com/photo-1606761568499-6d2451b23c66?q=80&w=1774&auto=format'
          ]
        },
        {
          id: 'venue-type-2-3',
          name: 'Presentation Theater',
          type: 'Auditorium',
          description: 'Tiered seating arrangement ideal for product launches or keynote presentations. Features 4K projection, surround sound, and recording capabilities.',
          maxCapacity: 75,
          priceFrom: 1200,
          photos: [
            'https://images.unsplash.com/photo-1492571350019-22de08371fd3?q=80&w=1753&auto=format'
          ]
        }
      ],
      facilitiesOffered: [
        {
          name: 'Tech Support Staff',
          isCharged: true,
          rate: 250,
          chargeType: 'Per Event'
        },
        {
          name: 'Innovative Lunch Options',
          isCharged: true,
          rate: 45,
          chargeType: 'Per Person'
        },
        {
          name: 'Presentation Equipment',
          isCharged: false,
          chargeType: 'Inclusive'
        },
        {
          name: 'Virtual Reality Setup',
          isCharged: true,
          rate: 600,
          chargeType: 'Per Event'
        },
        {
          name: 'Recording Service',
          isCharged: true,
          rate: 350,
          chargeType: 'Per Event'
        }
      ]
    },
    {
      ...generateBaseVenue('conference'),
      id: 'conference-3',
      title: 'Executive Meeting Center',
      location: 'Singapore',
      price: 1200,
      priceLabel: '/day',
      rating: 4.9,
      imageUrl: 'https://images.unsplash.com/photo-1517457373958-b7bdd4587205?q=80&w=1769&auto=format',
      photos: [
        'https://images.unsplash.com/photo-1517457373958-b7bdd4587205?q=80&w=1769&auto=format',
        'https://images.unsplash.com/photo-1517502884422-41eaead166d4?q=80&w=1925&auto=format',
        'https://images.unsplash.com/photo-1573167507387-6b4b98cb7c13?q=80&w=1769&auto=format',
        'https://images.unsplash.com/photo-1577962917302-cd874c4e31d2?q=80&w=1772&auto=format'
      ],
      tags: ['Corporate', 'Premium', 'Full-Service'],
      category: 'conference',
      capacity: 80,
      facilities: ['Executive Seating', 'Premium AV', 'Secretarial Services', 'Concierge', 'Fine Dining'],
      description: 'Executive Meeting Center offers premium meeting spaces designed for senior leadership gatherings, board meetings, and high-level corporate events. We provide an environment of exclusivity and discretion.\n\nOur spaces feature the finest furnishings, custom lighting, and advanced communication systems. Our attentive staff ensures seamless execution of your event, with personalized service and attention to detail.\n\nConveniently located in Singapore\'s central business district, we are the preferred venue for discerning corporate clients.',
      totalReviews: 87,
      googleLocation: 'https://maps.google.com/?q=1.3521,103.8198',
      venueTypes: [
        {
          id: 'venue-type-3-1',
          name: 'The Boardroom',
          type: 'Boardroom',
          description: 'Our signature meeting room featuring a handcrafted boardroom table, leather executive chairs, and sophisticated design elements. Includes executive concierge service.',
          maxCapacity: 20,
          priceFrom: 1200,
          photos: [
            'https://images.unsplash.com/photo-1517457373958-b7bdd4587205?q=80&w=1769&auto=format',
            'https://images.unsplash.com/photo-1517502884422-41eaead166d4?q=80&w=1925&auto=format'
          ]
        },
        {
          id: 'venue-type-3-2',
          name: 'Strategy Suite',
          type: 'Meeting Room',
          description: 'Elegant space for strategic discussions and planning sessions. Features digital collaboration tools, video conferencing, and comfortable seating arrangement.',
          maxCapacity: 15,
          priceFrom: 800,
          photos: [
            'https://images.unsplash.com/photo-1573167507387-6b4b98cb7c13?q=80&w=1769&auto=format'
          ]
        },
        {
          id: 'venue-type-3-3',
          name: 'Garden Pavilion',
          type: 'Indoor/Outdoor',
          description: 'Unique space with floor-to-ceiling windows overlooking a private garden. Can be opened to create an indoor/outdoor space for receptions or networking events.',
          maxCapacity: 80,
          priceFrom: 1500,
          photos: [
            'https://images.unsplash.com/photo-1577962917302-cd874c4e31d2?q=80&w=1772&auto=format'
          ]
        }
      ],
      facilitiesOffered: [
        {
          name: 'Executive Catering',
          isCharged: true,
          rate: 85,
          chargeType: 'Per Person'
        },
        {
          name: 'Administrative Support',
          isCharged: true,
          rate: 200,
          chargeType: 'Per Event'
        },
        {
          name: 'Meeting Amenities',
          isCharged: false,
          chargeType: 'Inclusive'
        },
        {
          name: 'Transportation Service',
          isCharged: true,
          rate: 150,
          chargeType: 'Subject to Enquiry'
        },
        {
          name: 'Professional Photography',
          isCharged: true,
          rate: 300,
          chargeType: 'Per Event'
        }
      ]
    }
  ];
};
