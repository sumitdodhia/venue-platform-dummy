
import { RestaurantVenue } from '@/types/venue';
import { generateBaseVenue } from './mockHelpers';
import { faker } from '@faker-js/faker';

export const getRestaurantVenues = (): RestaurantVenue[] => {
  return [
    {
      ...generateBaseVenue('restaurants'),
      id: 'restaurant-1',
      title: 'La Bella Italia',
      location: 'Rome, Italy',
      price: 45,
      priceLabel: '/person',
      rating: 4.8,
      imageUrl: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=1770&auto=format',
      photos: [
        'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=1770&auto=format',
        'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?q=80&w=1770&auto=format',
        'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=1770&auto=format'
      ],
      tags: ['Italian', 'Fine Dining', 'Wine Bar'],
      category: 'restaurants',
      cuisineType: 'Italian',
      capacity: 80,
      facilities: ['Private Dining', 'Outdoor Seating', 'Wine Cellar', 'Wheelchair Accessible'],
      priceRange: 3,
      description: 'La Bella Italia offers an authentic Italian dining experience in the heart of Rome. Our expert chefs prepare traditional dishes using only the finest locally-sourced ingredients.\n\nWith our extensive wine cellar featuring vintages from across Italy, we can perfectly pair your meal with the ideal complement.\n\nOur elegant dining room and attentive service make us the perfect choice for corporate events, special celebrations, or business meetings.',
      totalReviews: 124,
      googleLocation: 'https://maps.google.com/?q=41.9028,12.4964',
      openingHours: {
        monday: '12:00 PM - 10:00 PM',
        tuesday: '12:00 PM - 10:00 PM',
        wednesday: '12:00 PM - 10:00 PM',
        thursday: '12:00 PM - 11:00 PM',
        friday: '12:00 PM - 11:30 PM',
        saturday: '12:00 PM - 11:30 PM',
        sunday: '12:00 PM - 9:00 PM'
      },
      diningSections: [
        {
          id: 'section-1-1',
          name: 'Main Dining Room',
          description: 'Elegant main dining area with views of our open kitchen',
          capacity: 50,
          isPrivate: false,
          isOutdoor: false,
          photos: ['https://images.unsplash.com/photo-1414235077428-338989a2e8c0?q=80&w=1770&auto=format']
        },
        {
          id: 'section-1-2',
          name: 'Private Wine Room',
          description: 'Intimate private dining room surrounded by our premium wine collection',
          capacity: 15,
          isPrivate: true,
          isOutdoor: false,
          photos: ['https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=1770&auto=format']
        },
        {
          id: 'section-1-3',
          name: 'Terrace Garden',
          description: 'Beautiful outdoor terrace with views of the city',
          capacity: 25,
          isPrivate: false,
          isOutdoor: true,
          photos: ['https://images.unsplash.com/photo-1551632436-cbf8dd35adfa?q=80&w=1771&auto=format']
        }
      ],
      diningPackages: [
        {
          id: 'package-1',
          name: 'Business Lunch',
          description: 'Three-course lunch perfect for corporate meetings',
          pricePerPerson: 45,
          includes: ['Appetizer', 'Main Course', 'Dessert', 'Soft Drinks', 'Coffee'],
          minGuests: 10,
          maxGuests: 50
        },
        {
          id: 'package-1-2',
          name: 'Executive Dinner',
          description: 'Four-course dinner with wine pairing',
          pricePerPerson: 75,
          includes: ['Appetizer', 'Pasta Course', 'Main Course', 'Dessert', 'Wine Pairing'],
          minGuests: 15,
          maxGuests: 80
        }
      ]
    },
    {
      ...generateBaseVenue('restaurants'),
      id: 'restaurant-2',
      title: 'Sakura Japanese',
      location: 'Tokyo, Japan',
      price: 65,
      priceLabel: '/person',
      rating: 4.9,
      imageUrl: 'https://images.unsplash.com/photo-1585032226651-759b368d7246?q=80&w=1770&auto=format',
      photos: [
        'https://images.unsplash.com/photo-1585032226651-759b368d7246?q=80&w=1770&auto=format',
        'https://images.unsplash.com/photo-1621871908119-595c583f7ce6?q=80&w=1770&auto=format',
        'https://images.unsplash.com/photo-1580822184713-fc5400e7fe10?q=80&w=1770&auto=format'
      ],
      tags: ['Japanese', 'Sushi', 'Private Rooms'],
      category: 'restaurants',
      cuisineType: 'Japanese',
      capacity: 60,
      facilities: ['Tatami Rooms', 'Sushi Bar', 'Private Dining', 'Catering'],
      priceRange: 4,
      description: 'Sakura Japanese brings authentic flavors of Japan to your corporate events. Our master chef has trained in Tokyo and specializes in traditional Kaiseki cuisine with a modern twist.\n\nWe offer intimate tatami rooms for private meetings, as well as our striking main dining area with views of our expert sushi chefs at work.\n\nOur attentive staff and meticulous attention to presentation make any business gathering a memorable experience.',
      totalReviews: 186,
      googleLocation: 'https://maps.google.com/?q=35.6762,139.6503',
      openingHours: {
        monday: '11:30 AM - 10:00 PM',
        tuesday: '11:30 AM - 10:00 PM',
        wednesday: '11:30 AM - 10:00 PM',
        thursday: '11:30 AM - 10:30 PM',
        friday: '11:30 AM - 11:00 PM',
        saturday: '12:00 PM - 11:00 PM',
        sunday: '12:00 PM - 9:30 PM'
      },
      diningSections: [
        {
          id: 'section-2-1',
          name: 'Traditional Tatami Room',
          description: 'Authentic tatami mat room with traditional low seating',
          capacity: 12,
          isPrivate: true,
          isOutdoor: false,
          photos: ['https://images.unsplash.com/photo-1621871908119-595c583f7ce6?q=80&w=1770&auto=format']
        },
        {
          id: 'section-2-2',
          name: 'Sushi Counter',
          description: 'Interactive dining at our premium sushi counter',
          capacity: 15,
          isPrivate: false,
          isOutdoor: false,
          photos: ['https://images.unsplash.com/photo-1580822184713-fc5400e7fe10?q=80&w=1770&auto=format']
        },
        {
          id: 'section-2-3',
          name: 'Main Dining Area',
          description: 'Modern Japanese-inspired dining room',
          capacity: 35,
          isPrivate: false,
          isOutdoor: false,
          photos: ['https://images.unsplash.com/photo-1585032226651-759b368d7246?q=80&w=1770&auto=format']
        }
      ],
      diningPackages: [
        {
          id: 'package-2',
          name: 'Executive Dinner',
          description: 'Premium sushi and sake tasting experience',
          pricePerPerson: 65,
          includes: ['Omakase Menu', 'Sake Pairing', 'Dessert', 'Green Tea'],
          minGuests: 8,
          maxGuests: 40
        },
        {
          id: 'package-2-2',
          name: 'Corporate Lunch',
          description: 'Bento box selection perfect for business meetings',
          pricePerPerson: 45,
          includes: ['Miso Soup', 'Signature Bento Box', 'Dessert', 'Tea'],
          minGuests: 10,
          maxGuests: 60
        }
      ]
    },
    {
      ...generateBaseVenue('restaurants'),
      id: 'restaurant-3',
      title: 'Bistro Moderne',
      location: 'Paris, France',
      price: 55,
      priceLabel: '/person',
      rating: 4.7,
      imageUrl: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?q=80&w=1770&auto=format',
      photos: [
        'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?q=80&w=1770&auto=format',
        'https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c?q=80&w=1770&auto=format',
        'https://images.unsplash.com/photo-1551632811-561732d1e306?q=80&w=1770&auto=format'
      ],
      tags: ['French', 'Modern', 'Cocktails'],
      category: 'restaurants',
      cuisineType: 'French',
      capacity: 70,
      facilities: ['Bar Area', 'Private Room', 'Outdoor Terrace', 'AV Equipment'],
      priceRange: 3,
      description: 'Bistro Moderne combines classic French culinary techniques with contemporary flair, creating an ideal atmosphere for business meetings and corporate events.\n\nOur versatile spaces can be configured for presentations, networking events, or formal dinners. Our sommelier can curate wine pairings to complement your chosen menu.\n\nWith a prime location in central Paris, we offer exceptional French cuisine in a sophisticated yet relaxed setting.',
      totalReviews: 142,
      googleLocation: 'https://maps.google.com/?q=48.8566,2.3522',
      openingHours: {
        monday: '11:30 AM - 10:30 PM',
        tuesday: '11:30 AM - 10:30 PM',
        wednesday: '11:30 AM - 10:30 PM',
        thursday: '11:30 AM - 11:00 PM',
        friday: '11:30 AM - 11:30 PM',
        saturday: '12:00 PM - 11:30 PM',
        sunday: '12:00 PM - 10:00 PM'
      },
      diningSections: [
        {
          id: 'section-3-1',
          name: 'La Salle Principale',
          description: 'Elegant main dining room with classic French bistro ambiance',
          capacity: 45,
          isPrivate: false,
          isOutdoor: false,
          photos: ['https://images.unsplash.com/photo-1414235077428-338989a2e8c0?q=80&w=1770&auto=format']
        },
        {
          id: 'section-3-2',
          name: 'Le Salon Privé',
          description: 'Intimate private dining room perfect for business meetings',
          capacity: 15,
          isPrivate: true,
          isOutdoor: false,
          photos: ['https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c?q=80&w=1770&auto=format']
        },
        {
          id: 'section-3-3',
          name: 'La Terrasse',
          description: 'Charming outdoor terrace with heaters for year-round use',
          capacity: 25,
          isPrivate: false,
          isOutdoor: true,
          photos: ['https://images.unsplash.com/photo-1551632811-561732d1e306?q=80&w=1770&auto=format']
        }
      ],
      diningPackages: [
        {
          id: 'package-3',
          name: 'Corporate Reception',
          description: 'Standing reception with canapés and champagne',
          pricePerPerson: 55,
          includes: ['Selection of Canapés', 'Champagne Welcome', '3-hour Drink Package', 'Petit Fours'],
          minGuests: 20,
          maxGuests: 70
        },
        {
          id: 'package-3-2',
          name: 'Business Lunch',
          description: 'Three-course classic French lunch',
          pricePerPerson: 40,
          includes: ['Starter', 'Main Course', 'Dessert', 'Coffee/Tea'],
          minGuests: 10,
          maxGuests: 45
        }
      ]
    }
  ];
};
