
import { RoomVenue } from '@/types/venue';
import { generateBaseVenue } from './mockHelpers';

export const getRoomVenues = (): RoomVenue[] => {
  return [
    {
      ...generateBaseVenue('rooms'),
      id: 'room-1',
      title: 'Grand Plaza Hotel',
      location: 'New York, USA',
      price: 189,
      priceLabel: '/night',
      rating: 4.6,
      imageUrl: 'https://images.unsplash.com/photo-1618773928121-c32242e63f39?q=80&w=1770&auto=format',
      photos: [
        'https://images.unsplash.com/photo-1618773928121-c32242e63f39?q=80&w=1770&auto=format',
        'https://images.unsplash.com/photo-1566665797739-1674de7a421a?q=80&w=1974&auto=format',
        'https://images.unsplash.com/photo-1590490360182-c33d57733427?q=80&w=1774&auto=format',
        'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?q=80&w=1770&auto=format'
      ],
      tags: ['Business Center', 'City View', 'Gym'],
      category: 'rooms',
      totalRooms: 250,
      basisOffered: ['Bed & Breakfast', 'Room Only', 'Half Board'],
      facilities: ['Free Wi-Fi', 'Fitness Center', 'Business Center', 'Restaurant', 'Meeting Rooms', 'Airport Shuttle'],
      description: 'Grand Plaza Hotel is a premier business hotel located in the heart of Manhattan. With modern amenities and exceptional service, we provide the perfect environment for business travelers and corporate events.\n\nOur spacious rooms are designed for comfort and functionality, with ergonomic workspaces and high-speed Wi-Fi. Our meeting facilities can accommodate groups from 10 to 200 people.\n\nOur location provides easy access to major business districts, shopping areas, and cultural attractions.',
      totalReviews: 175,
      googleLocation: 'https://maps.google.com/?q=40.7128,-74.0060',
      about: 'Grand Plaza Hotel offers 250 luxurious rooms and suites with modern amenities and stunning city views. Our dedicated business center and meeting facilities make us an ideal choice for corporate travelers and events.',
      rooms: [
        {
          id: 'room-type-1',
          name: 'Executive Room',
          type: 'Executive Room',
          description: 'Spacious room with king-size bed, ergonomic workspace, and city views. Includes access to the Executive Lounge with complimentary refreshments throughout the day.',
          maxPax: 2,
          price: 189,
          priceFrom: 189,
          numberOfRooms: 120,
          photos: [
            'https://images.unsplash.com/photo-1618773928121-c32242e63f39?q=80&w=1770&auto=format',
            'https://images.unsplash.com/photo-1566665797739-1674de7a421a?q=80&w=1974&auto=format'
          ]
        },
        {
          id: 'room-type-2',
          name: 'Business Suite',
          type: 'Suite',
          description: 'Luxury suite with separate living area, king-size bed, spacious work desk, and premium amenities. Perfect for executives needing extra space or for small meetings.',
          maxPax: 3,
          price: 289,
          priceFrom: 289,
          numberOfRooms: 75,
          photos: [
            'https://images.unsplash.com/photo-1590490360182-c33d57733427?q=80&w=1774&auto=format',
            'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?q=80&w=1770&auto=format'
          ]
        }
      ]
    },
    {
      ...generateBaseVenue('rooms'),
      id: 'room-2',
      title: 'Seaside Resort',
      location: 'Bali, Indonesia',
      price: 225,
      priceLabel: '/night',
      rating: 4.8,
      imageUrl: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=1770&auto=format',
      photos: [
        'https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=1770&auto=format',
        'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?q=80&w=1770&auto=format',
        'https://images.unsplash.com/photo-1564501049412-61c2a3083791?q=80&w=1932&auto=format',
        'https://images.unsplash.com/photo-1601662528567-526cd06f6582?q=80&w=1830&auto=format'
      ],
      tags: ['Beach Access', 'Spa', 'Pool'],
      category: 'rooms',
      totalRooms: 120,
      basisOffered: ['All-Inclusive', 'Bed & Breakfast', 'Half Board'],
      facilities: ['Swimming Pool', 'Spa', 'Restaurant', 'Beach Access', 'Free Wi-Fi', 'Room Service'],
      description: 'Seaside Resort offers a perfect blend of luxury and natural beauty, making it an ideal destination for corporate retreats and incentive trips. Our beachfront property combines business facilities with relaxation opportunities.\n\nOur meeting rooms feature floor-to-ceiling windows with ocean views, creating an inspiring environment for creativity and collaboration. After meetings, teams can bond over water sports, spa treatments, or guided local excursions.\n\nOur all-inclusive packages can be customized to meet your corporate needs.',
      totalReviews: 210,
      googleLocation: 'https://maps.google.com/?q=-8.3405,115.0920',
      about: 'Seaside Resort is a luxury beachfront property perfect for incentive trips and executive retreats. With 120 rooms and villas, we offer a harmonious blend of business facilities and leisure activities.',
      rooms: [
        {
          id: 'room-type-3',
          name: 'Deluxe Room',
          type: 'Deluxe Room',
          description: 'Elegant room with king-size bed or twin beds, private balcony with garden views, and modern amenities. Features spacious bathroom with rain shower.',
          maxPax: 2,
          price: 225,
          priceFrom: 225,
          numberOfRooms: 80,
          photos: [
            'https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=1770&auto=format',
            'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?q=80&w=1770&auto=format'
          ]
        },
        {
          id: 'room-type-4',
          name: 'Ocean Villa',
          type: 'Villa',
          description: 'Luxurious villa with direct beach access, private plunge pool, spacious living area, and outdoor shower. Perfect for executives or as hospitality suite for high-value clients.',
          maxPax: 4,
          price: 450,
          priceFrom: 450,
          numberOfRooms: 25,
          photos: [
            'https://images.unsplash.com/photo-1564501049412-61c2a3083791?q=80&w=1932&auto=format',
            'https://images.unsplash.com/photo-1601662528567-526cd06f6582?q=80&w=1830&auto=format'
          ]
        }
      ]
    },
    {
      ...generateBaseVenue('rooms'),
      id: 'room-3',
      title: 'Business Suites',
      location: 'London, UK',
      price: 175,
      priceLabel: '/night',
      rating: 4.5,
      imageUrl: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?q=80&w=1774&auto=format',
      photos: [
        'https://images.unsplash.com/photo-1590490360182-c33d57733427?q=80&w=1774&auto=format',
        'https://images.unsplash.com/photo-1592229505726-ca121723b8ef?q=80&w=1974&auto=format',
        'https://images.unsplash.com/photo-1611892440504-42a792e24d32?q=80&w=1770&auto=format',
        'https://images.unsplash.com/photo-1630660664869-c9d3cc676880?q=80&w=1770&auto=format'
      ],
      tags: ['Central Location', 'Meeting Rooms', 'Executive Lounge'],
      category: 'rooms',
      totalRooms: 180,
      basisOffered: ['Room Only', 'Bed & Breakfast'],
      facilities: ['Business Center', 'Meeting Rooms', 'Executive Lounge', 'Restaurant', 'Free Wi-Fi', 'Fitness Center'],
      description: 'Business Suites is strategically located in the financial district of London, offering premium accommodations for business travelers. Our property specializes in extended stays and corporate housing solutions.\n\nEach room and suite features a fully-equipped workspace with ergonomic furniture, high-speed internet, and technology connections. Our meeting spaces are available 24/7 with smart booking systems.\n\nOur Executive Lounge provides a quiet environment for work or networking, with complimentary refreshments throughout the day.',
      totalReviews: 165,
      googleLocation: 'https://maps.google.com/?q=51.5074,-0.1278',
      about: 'Business Suites offers 180 rooms and suites designed specifically for corporate travelers in central London. Our business-focused amenities and strategic location make us the preferred choice for business travelers.',
      rooms: [
        {
          id: 'room-type-5',
          name: 'Standard Room',
          type: 'Standard Room',
          description: 'Well-appointed room with queen-size bed and dedicated workspace. Features smart TV, coffee maker, and ergonomic chair. Ideal for business travelers on shorter stays.',
          maxPax: 2,
          price: 175,
          priceFrom: 175,
          numberOfRooms: 100,
          photos: [
            'https://images.unsplash.com/photo-1590490360182-c33d57733427?q=80&w=1774&auto=format',
            'https://images.unsplash.com/photo-1592229505726-ca121723b8ef?q=80&w=1974&auto=format'
          ]
        },
        {
          id: 'room-type-6',
          name: 'Executive Suite',
          type: 'Suite',
          description: 'Sophisticated suite with separate bedroom and living area. Features extended work desk, meeting table for 4, premium coffee machine, and luxury bathroom with walk-in shower.',
          maxPax: 2,
          price: 275,
          priceFrom: 275,
          numberOfRooms: 60,
          photos: [
            'https://images.unsplash.com/photo-1611892440504-42a792e24d32?q=80&w=1770&auto=format',
            'https://images.unsplash.com/photo-1630660664869-c9d3cc676880?q=80&w=1770&auto=format'
          ]
        }
      ]
    }
  ];
};
