import { Venue } from '@/types/venue';

// Re-export the Venue type from our types
export type { Venue } from '@/types/venue';

// This file now only exports types - all venue data comes from suppliers or database
// No more mock data - the marketplace shows only real supplier-added venues

// Keep this function for backward compatibility but return empty array
export const getAllMockVenues = (): Venue[] => {
  return [];
};

// Get venues by specific category - now returns empty since we use real data
export function getVenuesByCategory(category: 'rooms' | 'conference' | 'restaurants'): Venue[] {
  return [];
}

// Export empty venues array for backward compatibility
export const venues: Venue[] = [];
