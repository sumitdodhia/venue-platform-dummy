
import { useState, useEffect } from "react";
import { useSearchParams } from 'react-router-dom';
import { parseISO, format } from "date-fns";
import { toast } from "sonner";
import { getCategoryLabel } from "@/components/venue/VenueDetailHeader";
import { useEnquiryFormState } from "./enquiryForm/useEnquiryFormState";
import { useUrlParamsSync } from "./enquiryForm/useUrlParamsSync";
import { useEnquiryFormSubmit } from "./enquiryForm/useEnquiryFormSubmit";

interface UseEnquiryFormProps {
  venueCategory: string;
  roomTypes?: Array<{id: string, name: string}>;
  basisOptions?: string[];
  capacity?: number;
  diningPackages?: Array<{id: string, name: string}>;
  diningSections?: Array<{id: string, name: string}>;
}

export const useEnquiryForm = ({ 
  venueCategory,
  roomTypes = [],
  basisOptions = [],
  capacity,
  diningPackages = [],
  diningSections = []
}: UseEnquiryFormProps) => {
  const [searchParams] = useSearchParams();
  
  // Use our extracted hooks for state management, URL syncing, and submission
  const {
    name, setName,
    email, setEmail,
    phone, setPhone,
    message, setMessage,
    startDate, setStartDate,
    endDate, setEndDate,
    roomCount, setRoomCount,
    selectedRoomType, setSelectedRoomType,
    selectedBasis, setSelectedBasis,
    attendees, setAttendees,
    layout, setLayout,
    equipment, setEquipment,
    eventType, setEventType,
    venueSpace, setVenueSpace,
    guests, setGuests,
    cuisine, setCuisine,
    seatingType, setSeatingType,
    packageType, setPackageType,
    diningSection, setDiningSection,
    specialRequirements, setSpecialRequirements,
    eventTime, setEventTime,
    resetForm
  } = useEnquiryFormState(venueCategory, basisOptions);

  // Sync URL parameters to form state
  useUrlParamsSync({
    searchParams,
    venueCategory,
    roomTypes,
    basisOptions,
    capacity,
    setStartDate,
    setEndDate,
    setRoomCount,
    setSelectedBasis,
    setSelectedRoomType,
    setVenueSpace,
    setAttendees,
    setEventType
  });

  // Set default values
  useEffect(() => {
    if (basisOptions.length > 0 && !selectedBasis) {
      setSelectedBasis(basisOptions[0]);
    }
    
    // Set initial attendees value based on capacity (half of the capacity as default)
    if (venueCategory === 'conference' && capacity && !attendees) {
      setAttendees(Math.floor(capacity / 2).toString());
    }
    
    // Set initial dining section if available
    if (venueCategory === 'restaurants' && diningSections && diningSections.length > 0) {
      setDiningSection(diningSections[0].id);
    }
    
    // Set initial package type if available
    if (venueCategory === 'restaurants' && diningPackages && diningPackages.length > 0) {
      setPackageType(diningPackages[0].id);
    }
  }, [
    basisOptions, 
    selectedBasis, 
    venueCategory, 
    capacity, 
    attendees, 
    diningSections, 
    diningPackages
  ]);

  // Get the form submission handler
  const handleSubmitEnquiry = useEnquiryFormSubmit({
    name,
    email,
    phone,
    message,
    startDate,
    endDate,
    roomCount,
    selectedRoomType,
    selectedBasis,
    venueCategory,
    eventType,
    venueSpace,
    attendees,
    layout,
    equipment,
    guests,
    cuisine,
    seatingType,
    packageType,
    diningSection,
    specialRequirements,
    eventTime,
    resetForm
  });

  return {
    // Contact information
    name, setName, email, setEmail, phone, setPhone, message, setMessage,
    
    // Dates
    startDate, setStartDate, endDate, setEndDate,
    
    // Room details
    roomCount, setRoomCount, selectedRoomType, setSelectedRoomType, 
    selectedBasis, setSelectedBasis,
    
    // Conference details
    attendees, setAttendees, layout, setLayout, equipment, setEquipment,
    eventType, setEventType, venueSpace, setVenueSpace,
    
    // Restaurant details
    guests, setGuests,
    cuisine, setCuisine,
    seatingType, setSeatingType,
    packageType, setPackageType,
    diningSection, setDiningSection,
    specialRequirements, setSpecialRequirements,
    eventTime, setEventTime,
    
    // Form handlers
    handleSubmitEnquiry
  };
};
