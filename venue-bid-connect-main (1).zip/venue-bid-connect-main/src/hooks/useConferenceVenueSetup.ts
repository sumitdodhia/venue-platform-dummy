
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ConferenceVenueDetails, ConferenceVenueType } from "@/types/conferenceSupplier";
import { useVenueStorage } from "./useVenueStorage";

const initialVenueDetails: ConferenceVenueDetails = {
  name: "",
  area: "",
  country: "",
  googleLocation: "",
  about: "",
  totalCapacity: 0,
  photos: [],
  facilities: [],
  facilitiesOffered: []
};

export const useConferenceVenueSetup = () => {
  const [venueDetails, setVenueDetails] = useState<ConferenceVenueDetails>(initialVenueDetails);
  const [venueTypes, setVenueTypes] = useState<ConferenceVenueType[]>([]);
  const [step, setStep] = useState<"venue" | "types" | "review">("venue");
  const navigate = useNavigate();
  const { saveVenue, isSubmitting } = useVenueStorage();

  const handleVenueSave = (details: ConferenceVenueDetails) => {
    setVenueDetails(details);
    setStep("types");
  };

  const handleAddVenue = (venueType: ConferenceVenueType) => {
    setVenueTypes(prev => [...prev, { ...venueType, id: Date.now().toString() }]);
  };

  const handleEditVenue = (venueType: ConferenceVenueType) => {
    setVenueTypes(prev => 
      prev.map(v => v.id === venueType.id ? venueType : v)
    );
  };

  const handleDeleteVenue = (id: string) => {
    setVenueTypes(prev => prev.filter(v => v.id !== id));
  };

  const handleSubmit = () => {
    setStep("review");
  };

  const handleGoToVenueStep = () => {
    setStep("venue");
  };

  const handleGoToTypesStep = () => {
    setStep("types");
  };

  const handlePublish = async () => {
    const venueData = {
      ...venueDetails,
      type: "conference",
      category: "conference",
      venueTypes: venueTypes,
    };

    const result = await saveVenue(venueData);
    if (result.success) {
      navigate("/supplier/venues");
    }
  };

  return {
    venueDetails,
    venueTypes,
    step,
    isPublishing: isSubmitting,
    handleVenueSave,
    handleAddVenue,
    handleEditVenue,
    handleDeleteVenue,
    handleSubmit,
    handleGoToVenueStep,
    handleGoToTypesStep,
    handlePublish
  };
};
