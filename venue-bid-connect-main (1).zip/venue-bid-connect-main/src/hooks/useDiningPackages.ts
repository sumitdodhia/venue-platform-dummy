
import { useState } from 'react';
import { DiningPackage } from "@/types/restaurantSupplier";

export const useDiningPackages = (initialPackages: DiningPackage[] = []) => {
  const [diningPackage, setDiningPackage] = useState<Partial<DiningPackage>>({
    name: "",
    description: "",
    pricePerPerson: 0,
    includes: [],
    minGuests: undefined,
    maxGuests: undefined
  });
  const [includesText, setIncludesText] = useState("");
  const [editIndex, setEditIndex] = useState<number | null>(null);
  const [packages, setPackages] = useState<DiningPackage[]>(initialPackages);

  const handleAddIncludesItem = () => {
    if (!includesText.trim()) return;
    
    setDiningPackage(prev => ({
      ...prev,
      includes: [...(prev.includes || []), includesText.trim()]
    }));
    
    setIncludesText("");
  };

  const handleRemoveIncludesItem = (indexToRemove: number) => {
    setDiningPackage(prev => ({
      ...prev,
      includes: (prev.includes || []).filter((_, idx) => idx !== indexToRemove)
    }));
  };

  const handleAddPackage = () => {
    if (!diningPackage.name || !diningPackage.pricePerPerson) {
      return; // Basic validation
    }

    const newPackage: DiningPackage = {
      id: editIndex !== null && packages[editIndex]?.id ? packages[editIndex].id : `package-${Date.now()}`,
      name: diningPackage.name || "",
      description: diningPackage.description || "",
      pricePerPerson: diningPackage.pricePerPerson || 0,
      includes: diningPackage.includes || [],
      minGuests: diningPackage.minGuests,
      maxGuests: diningPackage.maxGuests
    };

    let updatedPackages: DiningPackage[];

    if (editIndex !== null) {
      // Edit existing
      updatedPackages = packages.map((pkg, idx) => 
        idx === editIndex ? newPackage : pkg
      );
      setEditIndex(null);
    } else {
      // Add new
      updatedPackages = [...packages, newPackage];
    }

    setPackages(updatedPackages);
    resetForm();
  };

  const handleEditPackage = (index: number) => {
    const packageToEdit = packages[index];
    setDiningPackage(packageToEdit);
    setEditIndex(index);
  };

  const handleRemovePackage = (index: number) => {
    const updatedPackages = packages.filter((_, idx) => idx !== index);
    setPackages(updatedPackages);
    
    if (editIndex === index) {
      resetForm();
    } else if (editIndex !== null && editIndex > index) {
      setEditIndex(editIndex - 1);
    }
  };

  const resetForm = () => {
    setDiningPackage({
      name: "",
      description: "",
      pricePerPerson: 0,
      includes: [],
      minGuests: undefined,
      maxGuests: undefined
    });
    setIncludesText("");
    setEditIndex(null);
  };

  return {
    diningPackage,
    setDiningPackage,
    includesText,
    setIncludesText,
    editIndex,
    setEditIndex,
    packages,
    setPackages,
    handleAddIncludesItem,
    handleRemoveIncludesItem,
    handleAddPackage,
    handleEditPackage,
    handleRemovePackage,
    resetForm
  };
};
