
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { RestaurantDetails, PartialRestaurantDetails } from "@/types/restaurantSupplier";
import { useVenueStorage } from "./useVenueStorage";

const initialRestaurant: RestaurantDetails = {
  id: "",
  name: "",
  description: "",
  cuisineType: "",
  priceRange: 2,
  capacity: 50,
  minimumNotice: 2,
  location: {
    address: "",
    city: "",
    state: "",
    postalCode: "",
    country: "",
    googleMapUrl: "",
  },
  openingHours: {
    monday: "09:00-22:00",
    tuesday: "09:00-22:00",
    wednesday: "09:00-22:00",
    thursday: "09:00-22:00",
    friday: "09:00-22:00",
    saturday: "09:00-23:00",
    sunday: "09:00-23:00",
  },
  facilities: [],
  photos: [],
  sections: [],
  packages: [],
};

export const useRestaurantSupplierSetup = () => {
  const [restaurant, setRestaurant] = useState<RestaurantDetails>(initialRestaurant);
  const navigate = useNavigate();
  const { saveVenue, isSubmitting } = useVenueStorage();

  const saveRestaurantDetails = (details: PartialRestaurantDetails) => {
    setRestaurant(prev => {
      // Merge location properly
      const mergedLocation = {
        ...prev.location,
        ...details.location
      };
      
      // Merge opening hours properly
      const mergedOpeningHours = {
        ...prev.openingHours,
        ...details.openingHours
      };

      return {
        ...prev,
        ...details,
        location: mergedLocation,
        openingHours: mergedOpeningHours
      };
    });
  };

  const saveDiningSections = (sections: RestaurantDetails["sections"]) => {
    setRestaurant(prev => ({ ...prev, sections }));
  };

  const saveDiningPackages = (packages: RestaurantDetails["packages"]) => {
    setRestaurant(prev => ({ ...prev, packages }));
  };

  const publishRestaurant = async () => {
    const venueData = {
      ...restaurant,
      type: "restaurant",
      category: "restaurants",
      location: `${restaurant.location.city}, ${restaurant.location.country}`,
      about: restaurant.description,
    };

    const result = await saveVenue(venueData);
    if (result.success) {
      navigate("/supplier/venues");
    }
  };

  return {
    restaurant,
    saveRestaurantDetails,
    saveDiningSections,
    saveDiningPackages,
    publishRestaurant,
    isPublishing: isSubmitting
  };
};
