
import { useState } from "react";
import { PropertyDetails, RoomType } from "@/types/roomSupplier";
import { publishProperty, validatePropertySetup } from "@/services/propertyService";
import { toast } from "sonner";

export const useRoomSupplierSetup = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [isPublishing, setIsPublishing] = useState(false);
  
  const [propertyDetails, setPropertyDetails] = useState<PropertyDetails>({
    name: "",
    photos: [],
    area: "",
    country: "",
    about: "",
    totalRooms: 0,
    facilities: [],
    googleLocation: "",
    basisOffered: [],
    rating: 4.5,
    ratingCount: 0,
  });

  const [roomTypes, setRoomTypes] = useState<RoomType[]>([]);

  const handlePropertySubmit = (values: PropertyDetails) => {
    setPropertyDetails(values);
    setCurrentStep(2);
  };

  const handleRoomTypesSubmit = (rooms: RoomType[]) => {
    const validation = validatePropertySetup(propertyDetails, rooms);
    
    if (!validation.valid) {
      toast.error(validation.message);
      return;
    }
    
    setRoomTypes(rooms);
    setCurrentStep(3);
  };

  const handlePublish = async () => {
    setIsPublishing(true);
    
    try {
      const result = await publishProperty(propertyDetails, roomTypes);
      
      if (result.success) {
        toast.success("Property published successfully!");
        // Reset form
        setPropertyDetails({
          name: "",
          photos: [],
          area: "",
          country: "",
          about: "",
          totalRooms: 0,
          facilities: [],
          googleLocation: "",
          basisOffered: [],
          rating: 4.5,
          ratingCount: 0,
        });
        setRoomTypes([]);
        setCurrentStep(1);
      } else {
        toast.error("Failed to publish property completely, but saved locally");
      }
    } catch (error) {
      console.error("Error publishing property:", error);
      toast.error("Failed to publish property");
    } finally {
      setIsPublishing(false);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  return {
    currentStep,
    propertyDetails,
    roomTypes,
    isPublishing,
    handlePropertySubmit,
    handleRoomTypesSubmit,
    handlePublish,
    handleBack,
    setPropertyDetails,
    setRoomTypes
  };
};
