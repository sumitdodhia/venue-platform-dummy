
import { useState, useRef } from 'react';
import { DiningSection } from '@/types/restaurantSupplier';

export const useDiningSections = (initialSections: DiningSection[] = []) => {
  const [diningSection, setDiningSection] = useState<Partial<DiningSection>>({
    name: "",
    description: "",
    capacity: 0,
    isPrivate: false,
    isOutdoor: false,
  });
  const [editIndex, setEditIndex] = useState<number | null>(null);
  const [sections, setSections] = useState<DiningSection[]>(initialSections);
  const [photoUrls, setPhotoUrls] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || photoUrls.length >= 5) return;

    const newPhotoUrls = [...photoUrls];
    
    Array.from(files).forEach(file => {
      if (newPhotoUrls.length < 5) {
        const reader = new FileReader();
        reader.onload = () => {
          if (typeof reader.result === 'string') {
            newPhotoUrls.push(reader.result);
            setPhotoUrls([...newPhotoUrls]);
          }
        };
        reader.readAsDataURL(file);
      }
    });
    
    // Reset the input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleRemovePhoto = (index: number) => {
    const newPhotoUrls = [...photoUrls];
    newPhotoUrls.splice(index, 1);
    setPhotoUrls(newPhotoUrls);
  };

  const handleAddPhotos = () => {
    fileInputRef.current?.click();
  };

  const handleAddSection = () => {
    if (!diningSection.name || !diningSection.capacity) {
      return; // Basic validation
    }

    const newSection: DiningSection = {
      id: editIndex !== null && sections[editIndex]?.id ? sections[editIndex].id : `section-${Date.now()}`,
      name: diningSection.name || "",
      description: diningSection.description || "",
      capacity: diningSection.capacity || 0,
      isPrivate: diningSection.isPrivate || false,
      isOutdoor: diningSection.isOutdoor || false,
      photo: photoUrls.length > 0 ? photoUrls[0] : undefined,
      photos: photoUrls.length > 0 ? photoUrls : undefined,
    };

    let updatedSections: DiningSection[];

    if (editIndex !== null) {
      // Edit existing
      updatedSections = sections.map((section, idx) => 
        idx === editIndex ? newSection : section
      );
      setEditIndex(null);
    } else {
      // Add new
      updatedSections = [...sections, newSection];
    }

    setSections(updatedSections);
    resetForm();
  };

  const handleEditSection = (index: number) => {
    const sectionToEdit = sections[index];
    setDiningSection(sectionToEdit);
    setPhotoUrls(sectionToEdit.photos || (sectionToEdit.photo ? [sectionToEdit.photo] : []));
    setEditIndex(index);
  };

  const handleRemoveSection = (index: number) => {
    const updatedSections = sections.filter((_, idx) => idx !== index);
    setSections(updatedSections);
    
    // If currently editing this section, reset the form
    if (editIndex === index) {
      resetForm();
    } else if (editIndex !== null && editIndex > index) {
      // Adjust edit index if removing a section before the one being edited
      setEditIndex(editIndex - 1);
    }
  };

  const resetForm = () => {
    setDiningSection({
      name: "",
      description: "",
      capacity: 0,
      isPrivate: false,
      isOutdoor: false,
    });
    setPhotoUrls([]);
    setEditIndex(null);
  };

  return {
    diningSection,
    setDiningSection,
    photoUrls,
    fileInputRef,
    editIndex,
    sections,
    handleFileChange,
    handleRemovePhoto,
    handleAddPhotos,
    handleAddSection,
    handleEditSection, 
    handleRemoveSection,
    resetForm
  };
};

export default useDiningSections;
