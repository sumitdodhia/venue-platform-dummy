
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Venue } from "@/types/venue";

export const useVenuesFromDatabase = () => {
  const [venues, setVenues] = useState<Venue[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchVenues = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      console.log("Fetching all venues from database for marketplace...");
      
      // Fetch all venues from database (not just user's venues for marketplace)
      const { data, error } = await supabase
        .from('venues')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching venues:', error);
        setError(error.message);
        setVenues([]);
        return;
      }

      // If no data, set empty array
      if (!data || data.length === 0) {
        console.log('No venues found in database');
        setVenues([]);
        return;
      }

      console.log("Found venues in database:", data.length);

      // Transform database venues to match the Venue interface
      const transformedVenues: Venue[] = data.map(venue => ({
        id: venue.id,
        title: venue.name,
        location: venue.location || '',
        price: venue.price_from || 0,
        priceLabel: venue.type === 'rooms' || venue.type === 'hotel' ? '/night' : 
                   venue.type === 'conference' || venue.type === 'conference_venue' ? '/event' : '/person',
        rating: venue.rating || 4.5,
        totalReviews: venue.total_reviews || 0,
        imageUrl: venue.photos && venue.photos.length > 0 
          ? venue.photos[0] 
          : 'https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=1770&auto=format&fit=crop&ixlib=rb-4.0.3',
        photos: venue.photos || [],
        tags: venue.facilities || [],
        facilities: venue.facilities || [],
        category: venue.type === 'conference' || venue.type === 'conference_venue' ? 'conference' : 
                 venue.type === 'hotel' || venue.type === 'rooms' ? 'rooms' : 'restaurants',
        description: venue.description,
        capacity: venue.capacity,
        googleLocation: ''
      }));

      console.log("Transformed venues:", transformedVenues);
      setVenues(transformedVenues);
    } catch (err: any) {
      console.error('Unexpected error fetching venues:', err);
      setError(err.message);
      setVenues([]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchVenues();
  }, []);

  return {
    venues,
    isLoading,
    error,
    refetch: fetchVenues
  };
};
