
import { useState } from "react";
import { getCategoryLabel } from "@/components/venue/VenueDetailHeader";

export const useEnquiryFormState = (venueCategory: string, basisOptions: string[] = []) => {
  // Contact information state
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [message, setMessage] = useState(`I'm interested in booking this ${getCategoryLabel(venueCategory).toLowerCase()}. Please provide more details.`);
  
  // Date state
  const [startDate, setStartDate] = useState<Date | undefined>();
  const [endDate, setEndDate] = useState<Date | undefined>();
  
  // Room-specific state
  const [roomCount, setRoomCount] = useState("1");
  const [selectedRoomType, setSelectedRoomType] = useState("all");
  const [selectedBasis, setSelectedBasis] = useState("");
  
  // Conference-specific state
  const [attendees, setAttendees] = useState("");
  const [layout, setLayout] = useState("any");
  const [equipment, setEquipment] = useState<string[]>([]);
  const [eventType, setEventType] = useState("full-day");
  const [venueSpace, setVenueSpace] = useState("any");
  
  // Restaurant-specific state
  const [guests, setGuests] = useState("2");
  const [cuisine, setCuisine] = useState("any");
  const [seatingType, setSeatingType] = useState("any");
  const [packageType, setPackageType] = useState("none");
  const [diningSection, setDiningSection] = useState("any");
  const [specialRequirements, setSpecialRequirements] = useState<string[]>([]);
  const [eventTime, setEventTime] = useState("19:00");

  // Reset form function
  const resetForm = () => {
    setName("");
    setEmail("");
    setPhone("");
    setMessage(`I'm interested in booking this ${getCategoryLabel(venueCategory).toLowerCase()}. Please provide more details.`);
    setStartDate(undefined);
    setEndDate(undefined);
    setRoomCount("1");
    setSelectedRoomType("all");
    setAttendees("");
    setLayout("any");
    setEquipment([]);
    setEventType("full-day");
    setVenueSpace("any");
    setGuests("2");
    setCuisine("any");
    setSeatingType("any");
    setPackageType("none");
    setDiningSection("any");
    setSpecialRequirements([]);
    setEventTime("19:00");
    
    if (basisOptions.length > 0) {
      setSelectedBasis(basisOptions[0]);
    } else {
      setSelectedBasis("");
    }
  };

  return {
    // Contact information
    name, setName,
    email, setEmail,
    phone, setPhone,
    message, setMessage,
    
    // Dates
    startDate, setStartDate,
    endDate, setEndDate,
    
    // Room details
    roomCount, setRoomCount,
    selectedRoomType, setSelectedRoomType,
    selectedBasis, setSelectedBasis,
    
    // Conference details
    attendees, setAttendees,
    layout, setLayout,
    equipment, setEquipment,
    eventType, setEventType,
    venueSpace, setVenueSpace,
    
    // Restaurant details
    guests, setGuests,
    cuisine, setCuisine,
    seatingType, setSeatingType,
    packageType, setPackageType,
    diningSection, setDiningSection,
    specialRequirements, setSpecialRequirements,
    eventTime, setEventTime,
    
    // Reset function
    resetForm
  };
};
