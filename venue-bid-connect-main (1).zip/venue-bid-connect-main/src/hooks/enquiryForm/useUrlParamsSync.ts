
import { useEffect } from "react";
import { parseISO } from "date-fns";

interface UseUrlParamsSyncProps {
  searchParams: URLSearchParams;
  venueCategory: string;
  roomTypes?: Array<{id: string, name: string}>;
  basisOptions?: string[];
  capacity?: number;
  setStartDate: (date: Date | undefined) => void;
  setEndDate: (date: Date | undefined) => void;
  setRoomCount: (count: string) => void;
  setSelectedBasis: (basis: string) => void;
  setSelectedRoomType: (type: string) => void;
  setVenueSpace: (space: string) => void;
  setAttendees: (count: string) => void;
  setEventType: (type: string) => void;
}

export const useUrlParamsSync = ({
  searchParams,
  venueCategory,
  roomTypes = [],
  basisOptions = [],
  setStartDate,
  setEndDate,
  setRoomCount,
  setSelectedBasis,
  setSelectedRoomType,
  setVenueSpace,
  setAttendees,
  setEventType
}: UseUrlParamsSyncProps) => {
  
  // Process URL parameters on component mount
  useEffect(() => {
    // Get check-in date from URL
    const checkInParam = searchParams.get('checkInDate');
    if (checkInParam) {
      try {
        setStartDate(parseISO(checkInParam));
      } catch (e) {
        console.log("Invalid check-in date format in URL");
      }
    }
    
    // Get check-out date from URL
    const checkOutParam = searchParams.get('checkOutDate');
    if (checkOutParam) {
      try {
        setEndDate(parseISO(checkOutParam));
      } catch (e) {
        console.log("Invalid check-out date format in URL");
      }
    }
    
    // Get rooms count from URL
    const roomsParam = searchParams.get('rooms');
    if (roomsParam) {
      setRoomCount(roomsParam);
    }
    
    // Get basis from URL
    const basisParam = searchParams.get('basis');
    if (basisParam && basisOptions.includes(basisParam)) {
      setSelectedBasis(basisParam);
    } else if (basisOptions.length > 0) {
      setSelectedBasis(basisOptions[0]);
    }
    
    // Get room type from URL
    const roomTypeParam = searchParams.get('roomType');
    if (roomTypeParam && roomTypes.some(room => room.id === roomTypeParam)) {
      setSelectedRoomType(roomTypeParam);
    }
    
    // Get venue space from URL for conference venues
    const venueSpaceParam = searchParams.get('venueSpace');
    if (venueSpaceParam && venueCategory === 'conference' && 
        (venueSpaceParam === 'any' || roomTypes.some(space => space.id === venueSpaceParam))) {
      setVenueSpace(venueSpaceParam);
    }
    
    // Get attendees from URL if it's a conference venue
    const attendeesParam = searchParams.get('attendees');
    if (attendeesParam && venueCategory === 'conference') {
      setAttendees(attendeesParam);
    }
    
    // Get event type from URL for conference venues
    const eventTypeParam = searchParams.get('eventType');
    if (eventTypeParam && venueCategory === 'conference') {
      setEventType(eventTypeParam);
    }
    
    // Get start and end dates from URL for multi-day conference events
    const startDateParam = searchParams.get('startDate');
    const endDateParam = searchParams.get('endDate');
    
    if (startDateParam && venueCategory === 'conference') {
      try {
        setStartDate(parseISO(startDateParam));
      } catch (e) {
        console.log("Invalid start date format in URL");
      }
    }
    
    if (endDateParam && venueCategory === 'conference') {
      try {
        setEndDate(parseISO(endDateParam));
      } catch (e) {
        console.log("Invalid end date format in URL");
      }
    }
  }, [searchParams, basisOptions, roomTypes, venueCategory, setStartDate, setEndDate, 
      setRoomCount, setSelectedBasis, setSelectedRoomType, setVenueSpace, setAttendees, setEventType]);
};
