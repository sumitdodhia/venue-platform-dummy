
import { format } from "date-fns";
import { toast } from "sonner";

interface UseEnquiryFormSubmitProps {
  name: string;
  email: string;
  phone: string;
  message: string;
  startDate: Date | undefined;
  endDate: Date | undefined;
  roomCount: string;
  selectedRoomType: string;
  selectedBasis: string;
  venueCategory: string;
  eventType: string;
  venueSpace: string;
  attendees: string;
  layout: string;
  equipment: string[];
  guests: string;
  cuisine: string;
  seatingType: string;
  packageType: string;
  diningSection: string;
  specialRequirements: string[];
  eventTime: string;
  resetForm: () => void;
}

export const useEnquiryFormSubmit = ({
  name,
  email,
  phone,
  message,
  startDate,
  endDate,
  roomCount,
  selectedRoomType,
  selectedBasis,
  venueCategory,
  eventType,
  venueSpace,
  attendees,
  layout,
  equipment,
  guests,
  cuisine,
  seatingType,
  packageType,
  diningSection,
  specialRequirements,
  eventTime,
  resetForm
}: UseEnquiryFormSubmitProps) => {
  
  // Form submission handler
  return (e: React.FormEvent) => {
    e.preventDefault();
    
    // Create a summary of the enquiry for the toast message
    let enquirySummary = `Name: ${name}\nEmail: ${email}`;
    
    if (venueCategory === 'rooms') {
      if (startDate) enquirySummary += `\nCheck-in: ${format(startDate, 'PP')}`;
      if (endDate) enquirySummary += `\nCheck-out: ${format(endDate, 'PP')}`;
      enquirySummary += `\nRooms: ${roomCount}`;
      enquirySummary += `\nRoom Type: ${selectedRoomType === 'all' ? 'Any' : selectedRoomType}`;
      if (selectedBasis) enquirySummary += `\nBasis: ${selectedBasis}`;
    } 
    else if (venueCategory === 'conference') {
      if (eventType === 'multi-day') {
        if (startDate) enquirySummary += `\nStart Date: ${format(startDate, 'PP')}`;
        if (endDate) enquirySummary += `\nEnd Date: ${format(endDate, 'PP')}`;
      } else {
        if (startDate) enquirySummary += `\nDate: ${format(startDate, 'PP')}`;
      }
      enquirySummary += `\nEvent Type: ${eventType}`;
      enquirySummary += `\nVenue Space: ${venueSpace === 'any' ? 'Any' : venueSpace}`;
      enquirySummary += `\nAttendees: ${attendees}`;
      enquirySummary += `\nLayout: ${layout}`;
      if (equipment.length > 0) {
        enquirySummary += `\nEquipment: ${equipment.join(', ')}`;
      }
    }
    else if (venueCategory === 'restaurants') {
      if (startDate) enquirySummary += `\nDate: ${format(startDate, 'PP')}`;
      enquirySummary += `\nTime: ${eventTime}`;
      enquirySummary += `\nGuests: ${guests}`;
      if (diningSection !== 'any') enquirySummary += `\nSection: ${diningSection}`;
      if (packageType !== 'none') enquirySummary += `\nPackage: ${packageType}`;
      if (cuisine !== 'any') enquirySummary += `\nCuisine: ${cuisine}`;
      if (seatingType !== 'any') enquirySummary += `\nSeating: ${seatingType}`;
      if (specialRequirements.length > 0) {
        enquirySummary += `\nSpecial Requirements: ${specialRequirements.join(', ')}`;
      }
    }

    toast.success("Enquiry sent successfully! The venue will contact you shortly.");
    
    // Reset form
    resetForm();
  };
};
