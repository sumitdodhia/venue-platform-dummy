
import { useEffect, useState } from "react";
import { PropertyDetails, RoomType } from "@/types/roomSupplier";
import { validatePropertySetup } from "@/services/propertyService";

export const useRoomValidation = (property: PropertyDetails, rooms: RoomType[]) => {
  const [isValid, setIsValid] = useState(true);
  const [validationMessage, setValidationMessage] = useState<string | undefined>();
  const [totalRoomsFromTypes, setTotalRoomsFromTypes] = useState(0);

  useEffect(() => {
    // Calculate total rooms from all room types
    const totalFromTypes = rooms.reduce((sum, room) => sum + room.numberOfRooms, 0);
    setTotalRoomsFromTypes(totalFromTypes);
    
    // Validate property setup
    const { valid, message } = validatePropertySetup(property, rooms);
    setIsValid(valid);
    setValidationMessage(message);
  }, [property, rooms]);

  return {
    isValid,
    validationMessage,
    totalRoomsFromTypes,
    remainingRooms: Math.max(0, (property.totalRooms || 0) - totalRoomsFromTypes)
  };
};
