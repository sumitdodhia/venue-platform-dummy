
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";

export const useVenueStorage = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { user } = useAuth();

  const saveVenue = async (venueData: any) => {
    if (!user) {
      toast.error("You must be logged in to save venues");
      return { success: false };
    }

    setIsSubmitting(true);
    try {
      const { data, error } = await supabase
        .from('venues')
        .insert([
          {
            name: venueData.name,
            type: venueData.type || venueData.category,
            description: venueData.description || venueData.about,
            location: venueData.location || `${venueData.area}, ${venueData.country}`,
            owner_id: user.id,
          }
        ])
        .select()
        .single();

      if (error) {
        console.error('Error saving venue:', error);
        toast.error('Failed to save venue: ' + error.message);
        return { success: false, error };
      }

      toast.success('Venue saved successfully!');
      return { success: true, data };
    } catch (error: any) {
      console.error('Unexpected error:', error);
      toast.error('An unexpected error occurred');
      return { success: false, error };
    } finally {
      setIsSubmitting(false);
    }
  };

  return {
    saveVenue,
    isSubmitting
  };
};
