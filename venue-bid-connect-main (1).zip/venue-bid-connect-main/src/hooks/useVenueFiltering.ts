
import { useState, useMemo } from "react";
import { Venue } from "@/types/venue";
import { useVenuesFromDatabase } from "./useVenuesFromDatabase";

export type CategoryType = "restaurants" | "rooms" | "conference";

export const useVenueFiltering = (activeCategory: CategoryType) => {
  const [filters, setFilters] = useState<Record<string, any>>({});
  const { venues: dbVenues, isLoading } = useVenuesFromDatabase();

  // Use only database venues - no localStorage
  const allVenues = useMemo(() => {
    console.log("All venues for filtering:", dbVenues.length);
    return dbVenues;
  }, [dbVenues]);

  const filteredVenues = useMemo(() => {
    console.log(`Filtering venues for category: ${activeCategory}`);
    
    const filtered = allVenues.filter((venue) => {
      // Filter by category
      if (venue.category !== activeCategory) {
        return false;
      }

      // Apply other filters
      for (const [key, value] of Object.entries(filters)) {
        if (!value) continue;

        switch (key) {
          case "location":
            if (!venue.location.toLowerCase().includes(value.toLowerCase())) {
              return false;
            }
            break;
          case "priceRange":
            // Implement price range filtering logic
            break;
          case "capacity":
            // Implement capacity filtering logic
            break;
          // Add more filter cases as needed
        }
      }

      return true;
    });

    console.log(`Filtered venues for ${activeCategory}:`, filtered.length);
    return filtered;
  }, [allVenues, activeCategory, filters]);

  const handleFilterChange = (newFilters: Record<string, any>) => {
    setFilters(newFilters);
  };

  return {
    filteredVenues,
    isLoading,
    handleFilterChange
  };
};
