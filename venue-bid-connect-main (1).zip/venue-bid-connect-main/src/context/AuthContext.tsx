
import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { User, Session } from '@supabase/supabase-js';
import { toast } from 'sonner';
import { useNavigate, useLocation } from 'react-router-dom';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  profile: any | null;
  isLoading: boolean;
  signIn: (email: string, password: string) => Promise<{ success: boolean, error?: any }>;
  signUp: (data: {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    companyName?: string;
    userType: 'venue' | 'corporate' | 'agent';
    phone?: string;
    city?: string;
    country?: string;
  }) => Promise<{ success: boolean, error?: any }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<any | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();
  const location = useLocation();

  // Check if user should be redirected to dashboard
  const shouldRedirectToDashboard = (profile: any, currentPath: string) => {
    if (!profile) return false;
    
    // Don't redirect if already on a dashboard route
    if (currentPath.startsWith('/dashboard') || currentPath.startsWith('/supplier')) {
      return false;
    }
    
    // Don't redirect if on certain auth pages
    const authPages = ['/login', '/register', '/supplier-register'];
    return authPages.includes(currentPath);
  };

  const redirectToDashboard = (profile: any) => {
    // Check current path to avoid unnecessary redirects
    const currentPath = location.pathname;
    
    if (profile?.user_type === 'venue') {
      if (!currentPath.startsWith('/supplier')) {
        navigate('/supplier', { replace: true });
      }
    } else {
      if (!currentPath.startsWith('/dashboard')) {
        navigate('/dashboard', { replace: true });
      }
    }
  };

  useEffect(() => {
    // Set up auth state listener first
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, newSession) => {
        console.log("Auth state changed:", event, newSession?.user?.email);
        setSession(newSession);
        setUser(newSession?.user ?? null);
        
        // Fetch user profile when session changes
        if (newSession?.user) {
          fetchProfile(newSession.user.id);
        } else {
          setProfile(null);
          setIsLoading(false);
        }
      }
    );
    
    // Check for existing session
    supabase.auth.getSession().then(({ data: { session: existingSession } }) => {
      console.log("Initial session check:", existingSession?.user?.email);
      setSession(existingSession);
      setUser(existingSession?.user ?? null);
      
      if (existingSession?.user) {
        fetchProfile(existingSession.user.id);
      } else {
        setIsLoading(false);
      }
    });
    
    return () => {
      subscription.unsubscribe();
    };
  }, []);
  
  // Handle redirects when profile is loaded
  useEffect(() => {
    if (profile && !isLoading) {
      if (shouldRedirectToDashboard(profile, location.pathname)) {
        redirectToDashboard(profile);
      }
    }
  }, [profile, isLoading, location.pathname, navigate]);
  
  const fetchProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();
      
      if (error) {
        console.error('Error fetching profile:', error);
      } else {
        console.log("Profile fetched:", data);
        setProfile(data);
      }
    } catch (error) {
      console.error('Error in fetchProfile:', error);
    } finally {
      setIsLoading(false);
    }
  };
  
  const signIn = async (email: string, password: string) => {
    try {
      console.log("Signing in with:", email);
      const { data, error } = await supabase.auth.signInWithPassword({ 
        email, 
        password 
      });
      
      if (error) {
        console.error("Login error:", error);
        return { success: false, error };
      }
      
      console.log("Login successful:", data);
      return { success: true };
    } catch (error: any) {
      console.error("Unexpected login error:", error);
      return { success: false, error };
    }
  };
  
  const signUp = async (data: {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    companyName?: string;
    userType: 'venue' | 'corporate' | 'agent';
    phone?: string;
    city?: string;
    country?: string;
  }) => {
    try {
      const { email, password, firstName, lastName, companyName, userType, phone, city, country } = data;
      
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            first_name: firstName,
            last_name: lastName,
            company_name: companyName,
            user_type: userType,
            phone,
            city,
            country
          }
        }
      });
      
      if (error) {
        toast.error(error.message);
        return { success: false, error };
      }
      
      toast.success('Successfully signed up! Please check your email to verify your account.');
      return { success: true };
    } catch (error: any) {
      toast.error(error.message || 'Failed to sign up');
      return { success: false, error };
    }
  };
  
  const signOut = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      
      if (error) {
        console.error('Error signing out:', error);
        toast.error(error.message);
        throw error;
      }
      
      toast.success('Successfully signed out');
    } catch (error: any) {
      console.error('Error in signOut:', error);
      toast.error(error.message || 'Failed to sign out');
      throw error;
    }
  };
  
  return (
    <AuthContext.Provider value={{
      user,
      session,
      profile,
      isLoading,
      signIn,
      signUp,
      signOut,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
