
import { useState } from "react";
import { Outlet } from "react-router-dom";
import { Sidebar } from "@/components/ui/sidebar";

const SuperadminLayout = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  
  return (
    <div className="flex h-screen">
      <Sidebar className={isSidebarOpen ? "w-64" : "w-16"}>
        {/* Sidebar content goes here */}
      </Sidebar>
      <main className="flex-1 overflow-auto p-6">
        <Outlet />
      </main>
    </div>
  );
};

export default SuperadminLayout;
