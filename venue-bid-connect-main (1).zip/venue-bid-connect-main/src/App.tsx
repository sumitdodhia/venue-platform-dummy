
import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";
import MainLayout from "./layouts/MainLayout";
import IndexPage from "./pages/IndexPage";
import ContactPage from "./pages/ContactPage";
import MarketplacePage from "./pages/MarketplacePage";
import VenueDetailsPage from "./pages/VenueDetailsPage";
import NotFound from "./pages/NotFound";
import LoginPage from "./pages/LoginPage";
import HowItWorksPage from "./pages/HowItWorksPage";
import ClientsPage from "./pages/ClientsPage";
import SuppliersPage from "./pages/SuppliersPage";
import AboutPage from "./pages/AboutPage";
import RegisterPage from "./pages/RegisterPage";
import SupplierRegisterPage from "./pages/SupplierRegisterPage";
import { AuthProvider } from "./context/AuthContext";
import RequireAuth from "./components/auth/RequireAuth";
import SupplierDashboardPage from "./pages/supplier/SupplierDashboardPage";
import VenuesListPage from "./pages/supplier/VenuesListPage";
import VenueFormPage from "./pages/supplier/VenueFormPage";
import RoomSupplierSetupPage from "./pages/supplier/RoomSupplierSetupPage";
import ConferenceVenueSetupPage from "./pages/supplier/ConferenceVenueSetupPage";
import RestaurantSetupPage from "./pages/supplier/RestaurantSetupPage";
import DirectEnquiriesPage from "./pages/supplier/DirectEnquiriesPage";
import BiddingEnquiriesPage from "./pages/supplier/BiddingEnquiriesPage";
import SupplierEnquiriesPage from "./pages/supplier/SupplierEnquiriesPage";
import { Toaster } from "@/components/ui/toaster";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import VenueEditPage from "@/pages/supplier/VenueEditPage";
import SupplierDashboardLayout from "@/components/supplier/SupplierDashboardLayout";

const queryClient = new QueryClient();

function App() {
  return (
    <div className="App">
      <QueryClientProvider client={queryClient}>
        <BrowserRouter>
          <AuthProvider>
            <Routes>
              {/* Public routes with MainLayout */}
              <Route path="/" element={<MainLayout />}>
                <Route index element={<IndexPage />} />
                <Route path="contact" element={<ContactPage />} />
                <Route path="marketplace" element={<MarketplacePage />} />
                <Route path="how-it-works" element={<HowItWorksPage />} />
                <Route path="clients" element={<ClientsPage />} />
                <Route path="suppliers" element={<SuppliersPage />} />
                <Route path="about" element={<AboutPage />} />
                <Route path="venues/:venueId" element={<VenueDetailsPage />} />
                <Route path="login" element={<LoginPage />} />
                <Route path="register" element={<RegisterPage />} />
                <Route path="supplier-register" element={<SupplierRegisterPage />} />
              </Route>
              
              {/* Supplier routes with layout */}
              <Route path="/supplier" element={<RequireAuth supplierOnly><SupplierDashboardLayout /></RequireAuth>}>
                <Route index element={<SupplierDashboardPage />} />
                <Route path="venues" element={<VenuesListPage />} />
                <Route path="venues/add" element={<VenueFormPage />} />
                <Route path="venues/add/hotel" element={<RoomSupplierSetupPage />} />
                <Route path="venues/add/conference" element={<ConferenceVenueSetupPage />} />
                <Route path="venues/add/restaurant" element={<RestaurantSetupPage />} />
                <Route path="venues/:venueId/edit" element={<VenueEditPage />} />
                <Route path="venues/:venueId/edit/hotel" element={<RoomSupplierSetupPage />} />
                <Route path="venues/:venueId/edit/conference" element={<ConferenceVenueSetupPage />} />
                <Route path="venues/:venueId/edit/restaurant" element={<RestaurantSetupPage />} />
                <Route path="enquiries" element={<SupplierEnquiriesPage />} />
                <Route path="enquiries/bidding" element={<BiddingEnquiriesPage />} />
                <Route path="enquiries/direct" element={<DirectEnquiriesPage />} />
                <Route path="bids" element={<BiddingEnquiriesPage />} />
                <Route path="subscription" element={<SupplierDashboardPage />} />
                <Route path="profile" element={<SupplierDashboardPage />} />
                <Route path="settings" element={<SupplierDashboardPage />} />
              </Route>
              
              <Route path="*" element={<NotFound />} />
            </Routes>
            <Toaster />
          </AuthProvider>
        </BrowserRouter>
      </QueryClientProvider>
    </div>
  );
}

export default App;
