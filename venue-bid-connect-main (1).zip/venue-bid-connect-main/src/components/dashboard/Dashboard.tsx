
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";

const Dashboard = () => {
  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">Welcome back, John Doe</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button asChild>
            <Link to="/dashboard/new-enquiry">New Enquiry</Link>
          </Button>
        </div>
      </div>
      
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Active Enquiries</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
          </CardContent>
          <CardFooter>
            <Link to="/dashboard/enquiries" className="text-sm text-primary hover:underline">
              View all enquiries
            </Link>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Pending Bids</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">7</div>
          </CardContent>
          <CardFooter>
            <Link to="/dashboard/bids" className="text-sm text-primary hover:underline">
              View all bids
            </Link>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Completed Bookings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
          </CardContent>
          <CardFooter>
            <Link to="/dashboard/history" className="text-sm text-primary hover:underline">
              View booking history
            </Link>
          </CardFooter>
        </Card>
      </div>
      
      {/* Recent Activity */}
      <h2 className="text-xl font-semibold mb-4">Recent Activity</h2>
      <Card>
        <CardContent className="p-0">
          <div className="divide-y">
            <div className="p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-medium">New bid received</h3>
                  <p className="text-sm text-muted-foreground">
                    Grand Plaza Hotel has responded to your conference room request
                  </p>
                </div>
                <p className="text-sm text-muted-foreground">2 hours ago</p>
              </div>
            </div>
            
            <div className="p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-medium">Enquiry submitted</h3>
                  <p className="text-sm text-muted-foreground">
                    Your enquiry for restaurant booking has been sent to 5 venues
                  </p>
                </div>
                <p className="text-sm text-muted-foreground">Yesterday</p>
              </div>
            </div>
            
            <div className="p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-medium">Booking confirmed</h3>
                  <p className="text-sm text-muted-foreground">
                    Your meeting room booking at Executive Business Center is confirmed
                  </p>
                </div>
                <p className="text-sm text-muted-foreground">3 days ago</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;
