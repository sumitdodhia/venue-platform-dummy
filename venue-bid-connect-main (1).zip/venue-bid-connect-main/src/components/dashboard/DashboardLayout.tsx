
import { Link, Outlet, useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/context/AuthContext";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  FileText, 
  Home, 
  LogOut, 
  Menu, 
  MessageSquare, 
  Settings, 
  User 
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState, useEffect } from "react";

const DashboardLayout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, profile, signOut } = useAuth();
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  
  const handleLogout = async () => {
    try {
      await signOut();
      navigate("/");
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  // Helper function to check if a route is active
  const isActive = (path: string) => {
    return location.pathname === path || location.pathname.startsWith(`${path}/`);
  };
  
  // Get user initials for avatar fallback
  const getInitials = () => {
    if (!profile) return "?";
    
    const firstInitial = profile.first_name?.charAt(0) || '';
    const lastInitial = profile.last_name?.charAt(0) || '';
    
    return (firstInitial + lastInitial).toUpperCase() || user?.email?.charAt(0).toUpperCase() || '?';
  };
  
  const displayName = profile 
    ? `${profile.first_name || ''} ${profile.last_name || ''}`.trim() 
    : user?.email?.split('@')[0] || 'User';
  
  const userEmail = user?.email || '';
  
  const SidebarContent = () => (
    <nav className="space-y-1">
      <Link 
        to="/dashboard"
        className={cn(
          "flex items-center px-3 py-2 text-sm rounded-md transition-colors hover:bg-accent",
          isActive("/dashboard") && !location.pathname.includes('/dashboard/') && "bg-accent font-medium"
        )}
      >
        <Home className="mr-2 h-4 w-4" />
        Dashboard
      </Link>
      
      <Link 
        to="/dashboard/enquiries"
        className={cn(
          "flex items-center px-3 py-2 text-sm rounded-md transition-colors hover:bg-accent",
          location.pathname.includes('/dashboard/enquiries') && "bg-accent font-medium"
        )}
      >
        <FileText className="mr-2 h-4 w-4" />
        My Enquiries
      </Link>
      
      <Link 
        to="/dashboard/active-bids"
        className={cn(
          "flex items-center px-3 py-2 text-sm rounded-md transition-colors hover:bg-accent",
          isActive("/dashboard/active-bids") && "bg-accent font-medium"
        )}
      >
        <MessageSquare className="mr-2 h-4 w-4" />
        Active Bids
      </Link>
      
      <Link 
        to="/dashboard/history"
        className={cn(
          "flex items-center px-3 py-2 text-sm rounded-md transition-colors hover:bg-accent",
          isActive("/dashboard/history") && "bg-accent font-medium"
        )}
      >
        <FileText className="mr-2 h-4 w-4" />
        Booking History
      </Link>
      
      <div className="pt-4 mt-4 border-t">
        <h3 className="px-3 text-xs font-semibold text-muted-foreground mb-2">
          Account
        </h3>
        <Link 
          to="/dashboard/profile"
          className={cn(
            "flex items-center px-3 py-2 text-sm rounded-md transition-colors hover:bg-accent",
            isActive("/dashboard/profile") && "bg-accent font-medium"
          )}
        >
          <User className="mr-2 h-4 w-4" />
          My Profile
        </Link>
        
        <Link 
          to="/dashboard/settings"
          className={cn(
            "flex items-center px-3 py-2 text-sm rounded-md transition-colors hover:bg-accent",
            isActive("/dashboard/settings") && "bg-accent font-medium"
          )}
        >
          <Settings className="mr-2 h-4 w-4" />
          Settings
        </Link>
        
        <Button 
          variant="ghost" 
          size="sm" 
          className="w-full justify-start px-3 py-2 h-auto text-sm font-normal text-red-500 hover:text-red-600 hover:bg-red-50"
          onClick={handleLogout}
        >
          <LogOut className="mr-2 h-4 w-4" />
          Logout
        </Button>
      </div>
    </nav>
  );

  return (
    <div className="min-h-screen flex flex-col">
      {/* Dashboard Header */}
      <header className="sticky top-0 z-30 w-full bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center">
            <Link to="/dashboard" className="font-bold text-xl text-primary">
              FindToTable
            </Link>
            <span className="ml-2 hidden md:block text-sm text-muted-foreground">Client Dashboard</span>
            
            {/* Mobile menu trigger */}
            {isMobile && (
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="md:hidden ml-2">
                    <Menu className="h-5 w-5" />
                    <span className="sr-only">Toggle menu</span>
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-[240px] sm:w-[300px] p-0">
                  <div className="px-4 py-6 border-b">
                    <div className="flex items-center mb-4">
                      <Avatar className="h-10 w-10 mr-3">
                        <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${getInitials()}`} />
                        <AvatarFallback>{getInitials()}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium">{displayName}</p>
                        <p className="text-xs text-muted-foreground truncate max-w-[180px]">{userEmail}</p>
                      </div>
                    </div>
                  </div>
                  <div className="py-4">
                    <SidebarContent />
                  </div>
                </SheetContent>
              </Sheet>
            )}
          </div>
          
          <div className="flex items-center space-x-4">
            <Button variant="outline" size="sm" asChild className="hidden md:flex">
              <Link to="/marketplace">Browse Marketplace</Link>
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="relative flex items-center gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${getInitials()}`} />
                    <AvatarFallback>{getInitials()}</AvatarFallback>
                  </Avatar>
                  <span className="hidden md:inline-block">{displayName}</span>
                  <span className="absolute top-0 right-0 md:right-7 h-2 w-2 bg-green-500 rounded-full" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="px-2 pt-2 pb-2">
                  <div className="text-sm font-medium">{displayName}</div>
                  <div className="text-xs text-muted-foreground truncate">{userEmail}</div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link to="/dashboard/profile" className="cursor-pointer">My Profile</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link to="/dashboard/settings" className="cursor-pointer">Settings</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-red-500 focus:text-red-500 cursor-pointer">
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>
      
      {/* Dashboard Content */}
      <div className="flex-1 flex">
        {/* Sidebar */}
        <div className="hidden md:block w-64 border-r bg-muted p-4">
          <SidebarContent />
        </div>
        
        {/* Main Content */}
        <div className="flex-1 p-4 md:p-6 overflow-auto bg-background">
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default DashboardLayout;
