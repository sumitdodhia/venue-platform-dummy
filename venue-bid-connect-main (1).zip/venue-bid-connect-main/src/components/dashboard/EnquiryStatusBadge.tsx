
import { Badge } from "@/components/ui/badge";

type EnquiryStatusBadgeProps = {
  status: string;
};

const EnquiryStatusBadge = ({ status }: EnquiryStatusBadgeProps) => {
  switch (status) {
    case "active":
      return <Badge className="bg-green-500">Active</Badge>;
    case "closed":
      return <Badge variant="outline">Closed</Badge>;
    case "awarded":
      return <Badge className="bg-blue-500">Awarded</Badge>;
    default:
      return <Badge variant="secondary">Unknown</Badge>;
  }
};

export default EnquiryStatusBadge;
