
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

type EnquiryFiltersProps = {
  filter: string;
  setFilter: (filter: string) => void;
};

const EnquiryFilters = ({ filter, setFilter }: EnquiryFiltersProps) => {
  return (
    <Card className="mb-6">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Filter Enquiries</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2">
          <Button
            variant={filter === "all" ? "default" : "outline"}
            onClick={() => setFilter("all")}
          >
            All Enquiries
          </Button>
          <Button
            variant={filter === "active" ? "default" : "outline"}
            onClick={() => setFilter("active")}
          >
            Active
          </Button>
          <Button
            variant={filter === "awarded" ? "default" : "outline"}
            onClick={() => setFilter("awarded")}
          >
            Awarded
          </Button>
          <Button
            variant={filter === "closed" ? "default" : "outline"}
            onClick={() => setFilter("closed")}
          >
            Closed
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default EnquiryFilters;
