
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";
import EnquiryFilters from "./EnquiryFilters";
import EnquiryTable from "./EnquiryTable";
import EnquiryPagination from "./EnquiryPagination";

// Mock data for enquiries
const mockEnquiries = [
  {
    id: "ENQ-001",
    title: "Corporate Conference Room Booking",
    category: "Conference",
    submittedDate: "2025-05-10",
    dueDate: "2025-05-25",
    status: "active",
    bidCount: 3,
  },
  {
    id: "ENQ-002",
    title: "Executive Team Dinner",
    category: "Restaurant",
    submittedDate: "2025-05-08",
    dueDate: "2025-05-20",
    status: "active",
    bidCount: 5,
  },
  {
    id: "ENQ-003",
    title: "Annual Sales Meeting",
    category: "Meeting Room",
    submittedDate: "2025-05-05",
    dueDate: "2025-05-15",
    status: "closed",
    bidCount: 4,
  },
  {
    id: "ENQ-004",
    title: "Client Accommodation for Conference",
    category: "Rooms",
    submittedDate: "2025-04-28",
    dueDate: "2025-05-12",
    status: "awarded",
    bidCount: 7,
  },
  {
    id: "ENQ-005",
    title: "Board Meeting with Lunch",
    category: "Meeting Room",
    submittedDate: "2025-04-25",
    dueDate: "2025-05-09",
    status: "closed",
    bidCount: 2,
  },
];

const EnquiriesList = () => {
  const [filter, setFilter] = useState("all");

  const filteredEnquiries = filter === "all" 
    ? mockEnquiries 
    : mockEnquiries.filter(enquiry => enquiry.status === filter);

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold">My Enquiries</h1>
          <p className="text-muted-foreground">
            Manage your active and past enquiries
          </p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button asChild>
            <Link to="/dashboard/new-enquiry">New Enquiry</Link>
          </Button>
        </div>
      </div>

      <EnquiryFilters filter={filter} setFilter={setFilter} />

      <Card>
        <CardContent className="p-0">
          <EnquiryTable enquiries={filteredEnquiries} />
        </CardContent>
      </Card>

      <div className="mt-4">
        <EnquiryPagination />
      </div>
    </div>
  );
};

export default EnquiriesList;
