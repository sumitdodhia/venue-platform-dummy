
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import EnquiryStatusBadge from "./EnquiryStatusBadge";

type Enquiry = {
  id: string;
  title: string;
  category: string;
  submittedDate: string;
  dueDate: string;
  status: string;
  bidCount: number;
};

type EnquiryTableProps = {
  enquiries: Enquiry[];
};

const EnquiryTable = ({ enquiries }: EnquiryTableProps) => {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>ID</TableHead>
          <TableHead>Title</TableHead>
          <TableHead>Category</TableHead>
          <TableHead>Submitted</TableHead>
          <TableHead>Due Date</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Bids</TableHead>
          <TableHead>Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {enquiries.map((enquiry) => (
          <TableRow key={enquiry.id}>
            <TableCell className="font-medium">{enquiry.id}</TableCell>
            <TableCell>{enquiry.title}</TableCell>
            <TableCell>{enquiry.category}</TableCell>
            <TableCell>{enquiry.submittedDate}</TableCell>
            <TableCell>{enquiry.dueDate}</TableCell>
            <TableCell>
              <EnquiryStatusBadge status={enquiry.status} />
            </TableCell>
            <TableCell>{enquiry.bidCount}</TableCell>
            <TableCell>
              <Button variant="outline" size="sm" asChild>
                <Link to={`/dashboard/enquiries/${enquiry.id}`}>
                  View Details
                </Link>
              </Button>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
};

export default EnquiryTable;
