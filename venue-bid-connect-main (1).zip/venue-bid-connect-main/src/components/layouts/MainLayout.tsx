
import { Outlet } from "react-router-dom";
import MainNavbar from "@/components/MainNavbar";
import Footer from "@/components/Footer";

const MainLayout = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <MainNavbar />
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
};

export default MainLayout;
