
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";

const Testimonials = () => {
  const testimonials = [
    {
      quote: "VenueBid saved us countless hours searching for conference venues. The bidding system helped us get an excellent rate for our annual company retreat.",
      name: "Sarah Johnson",
      title: "Event Manager, TechCorp Inc.",
      avatar: "https://i.pravatar.cc/150?img=1",
    },
    {
      quote: "As a hotel manager, VenueBid has connected us with quality corporate clients we wouldn't have reached otherwise. The platform is intuitive and a valuable part of our business.",
      name: "Michael Rodriguez",
      title: "General Manager, Grand Plaza Hotel",
      avatar: "https://i.pravatar.cc/150?img=3",
    },
    {
      quote: "Finding meeting rooms used to be a headache for our admin team. Now we use VenueBid for all our bookings, saving time and budget across multiple departments.",
      name: "Emma Chen",
      title: "Operations Director, Global Solutions",
      avatar: "https://i.pravatar.cc/150?img=5",
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 }
    }
  };

  return (
    <section className="bg-muted py-16 md:py-24">
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-bold mb-4">What Our Users Say</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Discover how VenueBid has helped businesses and venues streamline their booking process and find perfect matches.
          </p>
        </motion.div>

        <motion.div 
          className="grid grid-cols-1 md:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
        >
          {testimonials.map((testimonial, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className="bg-card">
                <CardContent className="p-6">
                  <div className="flex flex-col h-full">
                    <div className="mb-4 text-xl">
                      <span className="text-4xl text-primary">"</span>
                      <p className="mt-2 italic text-base">{testimonial.quote}</p>
                    </div>
                    
                    <div className="mt-auto flex items-center">
                      <div className="mr-4">
                        <img 
                          src={testimonial.avatar} 
                          alt={testimonial.name} 
                          className="rounded-full w-12 h-12 object-cover"
                        />
                      </div>
                      <div>
                        <p className="font-medium">{testimonial.name}</p>
                        <p className="text-sm text-muted-foreground">{testimonial.title}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Testimonials;
