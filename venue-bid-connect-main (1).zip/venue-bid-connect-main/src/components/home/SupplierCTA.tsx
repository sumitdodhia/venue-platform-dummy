
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const SupplierCTA = () => {
  return (
    <section className="bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 py-16 md:py-24">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-4">
              Are you a Hotel, Restaurant, or Venue Owner?
            </h2>
            <p className="mb-6 text-lg opacity-90">
              Join our platform to connect with corporate clients, receive booking requests, and grow your business.
            </p>
            <ul className="space-y-2 mb-8">
              {[
                "Expand your reach to corporate clients",
                "Receive qualified booking inquiries",
                "Flexible bidding system for optimal pricing",
                "Complete booking management tools",
              ].map((item, index) => (
                <li key={index} className="flex items-center">
                  <span className="mr-2">✓</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
            <Link to="/suppliers">
              <Button variant="secondary" size="lg">
                Become a Supplier
              </Button>
            </Link>
          </div>
          
          <div className="rounded-lg overflow-hidden shadow-xl">
            <img 
              src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158" 
              alt="Supplier Dashboard" 
              className="w-full h-auto"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default SupplierCTA;
