
import { ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

const HowItWorks = () => {
  const steps = [
    {
      number: "01",
      title: "Search & Filter",
      description: "Browse through our extensive collection of venues and filter based on your requirements.",
      icon: "🔍"
    },
    {
      number: "02",
      title: "Send Direct Enquiry",
      description: "Contact venues directly or submit a detailed enquiry for multiple venues to bid on.",
      icon: "✉️"
    },
    {
      number: "03",
      title: "Receive Proposals",
      description: "Venues will respond with their availability, pricing, and special offers tailored to your needs.",
      icon: "📋"
    },
    {
      number: "04",
      title: "Compare & Select",
      description: "Compare proposals side by side and select the best option for your event or booking.",
      icon: "✅"
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 }
    }
  };

  return (
    <section className="container mx-auto px-4 py-16 md:py-24">
      <motion.div 
        className="text-center mb-16"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
      >
        <h2 className="text-3xl font-bold mb-4">How VenueBid Works</h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Our platform makes it easy to find and book the perfect venue for your needs. 
          Follow these simple steps to get started.
        </p>
      </motion.div>

      <motion.div 
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.2 }}
      >
        {steps.map((step, index) => (
          <motion.div 
            key={index} 
            className="relative bg-card rounded-lg p-6 hover:shadow-md transition-all"
            variants={itemVariants}
          >
            <div className="text-4xl mb-4">{step.icon}</div>
            <div className="text-5xl font-bold text-primary/10 absolute top-4 right-4">{step.number}</div>
            <h3 className="text-xl font-semibold mt-4 mb-3">{step.title}</h3>
            <p className="text-muted-foreground">{step.description}</p>
            
            {index < steps.length - 1 && (
              <motion.div 
                className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2 z-10"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.5 }}
              >
                <ArrowRight className="h-6 w-6 text-muted-foreground/50" />
              </motion.div>
            )}
          </motion.div>
        ))}
      </motion.div>
    </section>
  );
};

export default HowItWorks;
