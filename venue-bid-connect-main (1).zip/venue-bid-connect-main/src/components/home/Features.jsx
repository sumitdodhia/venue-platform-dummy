
import React from "react";

const Features = () => {
  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Our Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="p-6 border rounded-lg shadow-sm">
            <h3 className="text-xl font-semibold mb-3">Find the Perfect Venue</h3>
            <p>
              Search and filter through hundreds of venues to find the perfect match for your event needs.
            </p>
          </div>
          <div className="p-6 border rounded-lg shadow-sm">
            <h3 className="text-xl font-semibold mb-3">Compare Prices</h3>
            <p>
              Easily compare pricing and packages from multiple venues to get the best value.
            </p>
          </div>
          <div className="p-6 border rounded-lg shadow-sm">
            <h3 className="text-xl font-semibold mb-3">Direct Booking</h3>
            <p>
              Book your venue directly through our platform with secure payments and instant confirmation.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;
