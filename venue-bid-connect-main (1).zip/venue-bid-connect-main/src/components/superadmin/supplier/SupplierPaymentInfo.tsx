
import React from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { CreditCard, Building } from "lucide-react";
import InfoItem from "../InfoItem";

interface PaymentInfo {
  accountName: string;
  accountNumber: string;
  bankName: string;
}

interface SupplierPaymentInfoProps {
  paymentInfo: PaymentInfo;
}

const SupplierPaymentInfo = ({ paymentInfo }: SupplierPaymentInfoProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Payment Information</CardTitle>
        <CardDescription>Banking details for payments</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <InfoItem 
            icon={<CreditCard />} 
            label="Account Name" 
            value={paymentInfo.accountName} 
          />
          <InfoItem 
            icon={<CreditCard />} 
            label="Account Number" 
            value={paymentInfo.accountNumber} 
          />
          <InfoItem 
            icon={<Building />} 
            label="Bank Name" 
            value={paymentInfo.bankName} 
          />
        </div>
      </CardContent>
    </Card>
  );
};

export default SupplierPaymentInfo;
