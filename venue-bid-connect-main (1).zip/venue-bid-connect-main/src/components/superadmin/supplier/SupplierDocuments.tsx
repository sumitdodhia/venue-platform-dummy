
import React from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Document {
  name: string;
  status: string;
  date: string;
}

interface SupplierDocumentsProps {
  documents: Document[];
}

const SupplierDocuments = ({ documents }: SupplierDocumentsProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Documents</CardTitle>
        <CardDescription>Verification documents submitted by the supplier</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {documents.map((doc, index) => (
            <div 
              key={index} 
              className="p-4 border rounded-lg flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2"
            >
              <div>
                <h3 className="font-medium">{doc.name}</h3>
                <div className="text-sm text-muted-foreground">Uploaded on {doc.date}</div>
              </div>
              <Badge 
                variant="outline" 
                className={doc.status === 'verified' ? 'bg-green-50 text-green-700 border-green-200' : 'bg-orange-50 text-orange-700 border-orange-200'}
              >
                {doc.status.charAt(0).toUpperCase() + doc.status.slice(1)}
              </Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default SupplierDocuments;
