
import React from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Phone, MapPin } from "lucide-react";
import InfoItem from "../InfoItem";

interface SupplierAdditionalInfoProps {
  phone: string;
  address: string;
  description: string;
}

const SupplierAdditionalInfo = ({ phone, address, description }: SupplierAdditionalInfoProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Additional Information</CardTitle>
        <CardDescription>Additional details about the supplier</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <InfoItem icon={<Phone />} label="Phone" value={phone} />
          <InfoItem icon={<MapPin />} label="Address" value={address} />
        </div>
        
        <div>
          <h3 className="font-medium mb-2">Business Description</h3>
          <p className="text-muted-foreground">{description}</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default SupplierAdditionalInfo;
