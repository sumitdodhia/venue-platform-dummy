
import React from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Venue {
  id: string;
  name: string;
  type: string;
  address: string;
  city: string;
}

interface SupplierVenuesProps {
  venues: Venue[];
}

const SupplierVenues = ({ venues }: SupplierVenuesProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Registered Venues</CardTitle>
        <CardDescription>Venues managed by this supplier</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {venues.map((venue) => (
            <div 
              key={venue.id} 
              className="p-4 border rounded-lg flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2"
            >
              <div>
                <h3 className="font-medium">{venue.name}</h3>
                <div className="text-sm text-muted-foreground">{venue.address}, {venue.city}</div>
              </div>
              <Badge variant="outline">{venue.type}</Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default SupplierVenues;
