
import React from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Building, User, Mail, FileText } from "lucide-react";
import InfoItem from "../InfoItem";

interface SupplierDetailsProps {
  businessName: string;
  name: string;
  email: string;
  taxPin: string;
}

const SupplierBasicDetails = ({ businessName, name, email, taxPin }: SupplierDetailsProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Registration Information</CardTitle>
        <CardDescription>Details provided during supplier registration</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <InfoItem icon={<Building />} label="Business Name" value={businessName} />
          <InfoItem icon={<User />} label="Contact Person" value={name} />
          <InfoItem icon={<Mail />} label="Email" value={email} />
          <InfoItem icon={<FileText />} label="Tax PIN" value={taxPin} />
        </div>
      </CardContent>
    </Card>
  );
};

export default SupplierBasicDetails;
