
import { useState } from "react";
import { Link, Outlet, useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "@/components/ui/sonner";
import { 
  User,
  Settings,
  Users,
  CreditCard,
  List,
  Mail,
  Check
} from "lucide-react";

const SuperAdminLayout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const handleLogout = () => {
    toast.success("Logged out successfully");
    navigate("/login");
  };

  const isActive = (path: string) => {
    return location.pathname === path || location.pathname.startsWith(`${path}/`);
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-primary text-primary-foreground shadow-md h-16 z-20">
        <div className="container mx-auto px-4 h-full flex items-center justify-between">
          <div className="flex items-center">
            <Link to="/superadmin" className="font-bold text-xl">
              FindToTable Admin
            </Link>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button variant="secondary" size="sm" asChild>
              <Link to="/">View Website</Link>
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="relative">
                  <span>Super Admin</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem asChild>
                  <Link to="/superadmin/system-settings">Settings</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>
      
      <div className="flex-1 flex">
        {/* Sidebar */}
        <div className={`bg-muted border-r transition-all duration-300 ${isSidebarOpen ? "w-64" : "w-16"}`}>
          <div className="p-4">
            <Button 
              variant="outline" 
              size="icon" 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="mb-4 w-full"
            >
              <List className="h-4 w-4" />
            </Button>
            
            <nav className="space-y-2">
              <SidebarLink 
                to="/superadmin/suppliers" 
                icon={<User className="h-5 w-5" />} 
                label="Supplier Verification" 
                isActive={isActive('/superadmin/suppliers')} 
                isSidebarOpen={isSidebarOpen}
              />
              
              <SidebarLink 
                to="/superadmin/clients" 
                icon={<Users className="h-5 w-5" />} 
                label="Client Management" 
                isActive={isActive('/superadmin/clients')} 
                isSidebarOpen={isSidebarOpen}
              />
              
              <SidebarLink 
                to="/superadmin/system-settings" 
                icon={<Settings className="h-5 w-5" />} 
                label="System Settings" 
                isActive={isActive('/superadmin/system-settings')} 
                isSidebarOpen={isSidebarOpen}
              />
              
              <SidebarLink 
                to="/superadmin/payment-integrations" 
                icon={<CreditCard className="h-5 w-5" />} 
                label="Payment Integrations" 
                isActive={isActive('/superadmin/payment-integrations')} 
                isSidebarOpen={isSidebarOpen}
              />
              
              <SidebarLink 
                to="/superadmin/platform-options" 
                icon={<List className="h-5 w-5" />} 
                label="Platform Options" 
                isActive={isActive('/superadmin/platform-options')} 
                isSidebarOpen={isSidebarOpen}
              />
            </nav>
          </div>
        </div>
        
        {/* Main Content */}
        <div className="flex-1 overflow-auto p-6 bg-background">
          <Outlet />
        </div>
      </div>
    </div>
  );
};

interface SidebarLinkProps {
  to: string;
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
  isSidebarOpen: boolean;
}

const SidebarLink = ({ to, icon, label, isActive, isSidebarOpen }: SidebarLinkProps) => {
  return (
    <Link
      to={to}
      className={`flex items-center px-3 py-2 rounded-md transition-colors ${
        isActive 
          ? "bg-primary text-primary-foreground" 
          : "hover:bg-accent hover:text-accent-foreground"
      }`}
      title={isSidebarOpen ? undefined : label}
    >
      {icon}
      {isSidebarOpen && <span className="ml-2">{label}</span>}
    </Link>
  );
};

export default SuperAdminLayout;
