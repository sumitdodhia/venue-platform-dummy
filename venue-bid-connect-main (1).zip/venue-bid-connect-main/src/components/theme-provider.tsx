
"use client";

import * as React from "react";

type ThemeProviderProps = {
  children: React.ReactNode;
};

export function ThemeProvider({
  children,
  ...props
}: ThemeProviderProps) {
  return (
    <div {...props}>
      {children}
    </div>
  );
}

export const useTheme = () => {
  return {
    theme: "light",
    setTheme: () => null,
  };
};
