
import { Navigate } from "react-router-dom";

const SupplierEnquiriesList = () => {
  // Redirect to bidding enquiries by default
  return <Navigate to="/supplier/enquiries/bidding" replace />;
};

export default SupplierEnquiriesList;
