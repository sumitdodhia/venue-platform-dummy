
import { RoomEnquiryType } from "./types";

type RoomsEnquiryDetailsProps = {
  enquiry: RoomEnquiryType;
};

const RoomsEnquiryDetails = ({ enquiry }: RoomsEnquiryDetailsProps) => {
  return (
    <div className="border-t pt-4">
      <dl className="space-y-2 text-sm">
        <div className="flex justify-between">
          <dt className="font-medium">Check-in Date:</dt>
          <dd>{enquiry.checkInDate}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="font-medium">Check-out Date:</dt>
          <dd>{enquiry.checkOutDate}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="font-medium">Number of Rooms:</dt>
          <dd>{enquiry.roomCount}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="font-medium">Room Type:</dt>
          <dd>{enquiry.roomType}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="font-medium">Meal Plan:</dt>
          <dd>{enquiry.mealPlan}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="font-medium">City:</dt>
          <dd>{enquiry.city}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="font-medium">Country:</dt>
          <dd>{enquiry.country}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="font-medium">Budget:</dt>
          <dd>{enquiry.budget}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="font-medium">Bid Deadline:</dt>
          <dd className="text-red-500 font-medium">{enquiry.deadline}</dd>
        </div>
      </dl>
    </div>
  );
};

export default RoomsEnquiryDetails;
