
import { EnquiryType } from "./types";
import ConferenceEnquiryDetails from "./ConferenceEnquiryDetails";
import RoomsEnquiryDetails from "./RoomsEnquiryDetails";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";

type EnquiryDetailsCardProps = {
  enquiry: EnquiryType;
};

const EnquiryDetailsCard = ({ enquiry }: EnquiryDetailsCardProps) => {
  const renderEnquiryDetails = () => {
    if (enquiry.category === "rooms") {
      return <RoomsEnquiryDetails enquiry={enquiry as any} />;
    } else {
      return <ConferenceEnquiryDetails enquiry={enquiry as any} />;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Enquiry Details</CardTitle>
        <CardDescription>Review the client's requirements</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <h3 className="font-semibold">{enquiry.title}</h3>
            <p className="text-sm text-muted-foreground">{enquiry.company}</p>
          </div>

          {renderEnquiryDetails()}

          <div className="border-t pt-4">
            <h3 className="font-medium mb-2">Requirements:</h3>
            <p className="text-sm">{enquiry.requirements}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default EnquiryDetailsCard;
