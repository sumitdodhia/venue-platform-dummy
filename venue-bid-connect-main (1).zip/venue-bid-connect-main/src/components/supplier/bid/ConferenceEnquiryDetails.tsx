
import { ConferenceEnquiryType } from "./types";

type ConferenceEnquiryDetailsProps = {
  enquiry: ConferenceEnquiryType;
};

const ConferenceEnquiryDetails = ({ enquiry }: ConferenceEnquiryDetailsProps) => {
  return (
    <div className="border-t pt-4">
      <dl className="space-y-2 text-sm">
        <div className="flex justify-between">
          <dt className="font-medium">Event Date:</dt>
          <dd>{enquiry.date}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="font-medium">Guests:</dt>
          <dd>{enquiry.guests}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="font-medium">Budget:</dt>
          <dd>{enquiry.budget}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="font-medium">Bid Deadline:</dt>
          <dd className="text-red-500 font-medium">{enquiry.deadline}</dd>
        </div>
      </dl>
    </div>
  );
};

export default ConferenceEnquiryDetails;
