
import { EnquiryType } from "./types";

export type BidStatus = 'pending' | 'accepted' | 'rejected' | 'negotiating';

export type BidType = {
  id: string;
  enquiryId: string;
  price: string;
  venue: string;
  description: string;
  inclusions: string;
  availability: string;
  status: BidStatus;
  submittedAt: string;
  lastUpdated: string;
  clientContact?: string;
  clientEmail?: string;
  clientPhone?: string;
};

// Mock data for the bids suppliers have submitted
export const bidData: BidType[] = [
  {
    id: "bid-001",
    enquiryId: "enq-conf-001",
    price: "$14,500",
    venue: "Grand Conference Center",
    description: "Our Grand Conference Center is perfectly suited for your tech conference. We offer a 200-person main hall with state-of-the-art A/V equipment, three breakout rooms, and a spacious foyer area for networking.",
    inclusions: "Full A/V setup, Wi-Fi for all attendees, basic stage lighting, water stations, notepads and pens, parking for up to 50 vehicles.",
    availability: "Available on your requested date (2025-09-15)",
    status: "pending",
    submittedAt: "2025-05-20T14:30:00Z",
    lastUpdated: "2025-05-20T14:30:00Z",
    clientContact: "Sarah Johnson",
    clientEmail: "sarah@technova.com",
    clientPhone: "+1 (555) 123-4567"
  },
  {
    id: "bid-002",
    enquiryId: "enq-conf-002",
    price: "$4,800",
    venue: "Executive Boardroom",
    description: "Our Executive Boardroom offers a premium meeting space with mahogany furnishings, comfortable seating for up to 30 people, and panoramic city views.",
    inclusions: "Premium catering package (breakfast, lunch, afternoon tea), dedicated IT support, executive stationery, secure high-speed internet, complimentary valet parking.",
    availability: "Available on your requested date (2025-07-22)",
    status: "pending",
    submittedAt: "2025-05-25T10:15:00Z",
    lastUpdated: "2025-05-25T10:15:00Z",
    clientContact: "Michael Richardson",
    clientEmail: "michael@globalfinance.com",
    clientPhone: "+1 (555) 987-6543"
  },
  {
    id: "bid-003",
    enquiryId: "enq-room-001",
    price: "$23,750",
    venue: "Oceanview Resort",
    description: "Our beachfront resort is perfect for your sales team retreat. We offer spacious rooms with ocean views, multiple meeting spaces, and team-building activities including water sports and beach olympics.",
    inclusions: "All meals included, welcome cocktail reception, two half-day team building activities, meeting room with A/V equipment for 3 days, airport transfers.",
    availability: "Available on your requested dates (2025-08-10 to 2025-08-15)",
    status: "pending",
    submittedAt: "2025-05-30T16:45:00Z",
    lastUpdated: "2025-05-30T16:45:00Z",
    clientContact: "Jennifer Smith",
    clientEmail: "jennifer@innovatex.com",
    clientPhone: "+1 (555) 234-5678"
  }
];

// Helper function to merge bid data with enquiry data
export const getBidWithEnquiry = (bid: BidType, enquiriesData: Record<string, EnquiryType>) => {
  const enquiry = enquiriesData[bid.enquiryId];
  return {
    ...bid,
    enquiry
  };
};
