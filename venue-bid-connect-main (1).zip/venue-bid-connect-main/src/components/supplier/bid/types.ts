
// Define bid form values
export type BidFormValues = {
  price: string;
  venue: string;
  description: string;
  inclusions: string;
  availability: string;
};

// Define the type for conference enquiries
export type ConferenceEnquiryType = {
  id: string;
  title: string;
  company: string;
  date: string;
  guests: number;
  requirements: string;
  budget: string;
  deadline: string;
  status: string;
  category: "conference";
};

// Define the type for room enquiries
export type RoomEnquiryType = {
  id: string;
  title: string;
  company: string;
  checkInDate: string;
  checkOutDate: string;
  roomCount: number;
  roomType: string;
  mealPlan: string;
  city: string;
  country: string;
  requirements: string;
  budget: string;
  deadline: string;
  status: string;
  category: "rooms";
};

// Combined type
export type EnquiryType = ConferenceEnquiryType | RoomEnquiryType;

// Mock enquiry data for suppliers to respond to
export const enquiryData: Record<string, EnquiryType> = {
  // Conference enquiries
  "enq-conf-001": {
    id: "enq-conf-001",
    title: "Annual Tech Conference",
    company: "TechNova",
    date: "2025-09-15",
    guests: 150,
    requirements: "Need a conference venue with A/V equipment, catering for lunch and coffee breaks, and a breakout room for smaller sessions.",
    budget: "15000",
    deadline: "2025-06-30",
    status: "new",
    category: "conference"
  },
  "enq-conf-002": {
    id: "enq-conf-002",
    title: "Executive Board Meeting",
    company: "Global Finance Group",
    date: "2025-07-22",
    guests: 25,
    requirements: "Looking for a private meeting space with premium catering options, high-speed internet, and presentation equipment.",
    budget: "5000",
    deadline: "2025-06-15",
    status: "new",
    category: "conference"
  },
  
  // Room enquiries
  "enq-room-001": {
    id: "enq-room-001",
    title: "Sales Team Retreat",
    company: "InnovateX",
    checkInDate: "2025-08-10",
    checkOutDate: "2025-08-15",
    roomCount: 20,
    roomType: "Double",
    mealPlan: "All Inclusive",
    city: "Miami",
    country: "USA",
    requirements: "Need rooms for 20 people with meeting facilities and team-building activities included.",
    budget: "25000",
    deadline: "2025-07-01",
    status: "new",
    category: "rooms"
  },
  "enq-room-002": {
    id: "enq-room-002",
    title: "Client Visit Accommodation",
    company: "DataSphere",
    checkInDate: "2025-06-05",
    checkOutDate: "2025-06-08",
    roomCount: 5,
    roomType: "Executive",
    mealPlan: "Bed & Breakfast",
    city: "London",
    country: "UK",
    requirements: "Looking for premium rooms for visiting executives with convenient access to our London office.",
    budget: "4500",
    deadline: "2025-05-20",
    status: "bid_submitted",
    category: "rooms"
  }
};
