
import { useForm } from "react-hook-form";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { BidFormValues } from "./types";

type BidFormContentProps = {
  onSubmit: (data: BidFormValues) => void;
  isSubmitting: boolean;
  onCancel: () => void;
};

const BidFormContent = ({ onSubmit, isSubmitting, onCancel }: BidFormContentProps) => {
  const form = useForm<BidFormValues>({
    defaultValues: {
      price: "",
      venue: "",
      description: "",
      inclusions: "",
      availability: "yes",
    },
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle>Your Bid</CardTitle>
        <CardDescription>Provide details of your offer</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="venue"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Select Venue</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select venue" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="grand-ballroom">Grand Ballroom</SelectItem>
                      <SelectItem value="executive-room-a">Executive Meeting Room A</SelectItem>
                      <SelectItem value="rooftop-terrace">Rooftop Terrace</SelectItem>
                      <SelectItem value="private-dining">Private Dining Room</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    Choose which of your venues is best suited for this event.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="price"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Total Price (USD)</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. 5000" {...field} />
                  </FormControl>
                  <FormDescription>
                    Enter the total cost for hosting this event at your venue.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Proposal Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Describe your offer and why your venue is perfect for this event..." 
                      className="min-h-[120px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="inclusions"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Inclusions</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="List what's included in your price (e.g., catering, equipment, staff)..." 
                      className="min-h-[120px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="availability"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Availability Confirmation</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select availability" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="yes">Yes, the venue is available on this date</SelectItem>
                      <SelectItem value="alternative">Proposing alternative date</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="flex justify-end space-x-4">
              <Button 
                type="button" 
                variant="outline" 
                onClick={onCancel}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? "Submitting..." : "Submit Bid"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};

export default BidFormContent;
