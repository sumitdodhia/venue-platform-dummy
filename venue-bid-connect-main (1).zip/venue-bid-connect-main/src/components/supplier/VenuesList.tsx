
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Link } from "react-router-dom";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Edit, ListFilter, MoreHorizontal, Plus } from "lucide-react";
import { getProperties, getPropertyRooms } from "@/services/propertyService";

const VenuesList = () => {
  const [filter, setFilter] = useState("all");
  const [venues, setVenues] = useState<any[]>([]);
  
  useEffect(() => {
    // Get properties from storage
    const properties = getProperties();
    
    // Add room counts to each property
    const venuesWithDetails = properties.map((property) => {
      const propertyRooms = getPropertyRooms(property.id || "");
      
      return {
        id: property.id,
        name: property.name,
        type: "Room Accommodation",
        capacity: property.totalRooms,
        status: "active",
        location: `${property.area}, ${property.country}`,
        enquiries: 0,
        roomTypes: propertyRooms.length
      };
    });
    
    // Combine with sample venues
    const sampleVenues = [
      {
        id: "venue-1",
        name: "Grand Ballroom",
        type: "Event Space",
        capacity: 500,
        status: "active",
        location: "Main Building, Floor 2",
        enquiries: 12
      },
      {
        id: "venue-2",
        name: "Executive Meeting Room A",
        type: "Meeting Room",
        capacity: 20,
        status: "active",
        location: "Business Center, Floor 3",
        enquiries: 8
      },
      {
        id: "venue-3",
        name: "Rooftop Terrace",
        type: "Event Space",
        capacity: 150,
        status: "active",
        location: "Rooftop, Floor 20",
        enquiries: 10
      },
      {
        id: "venue-4",
        name: "Private Dining Room",
        type: "Dining",
        capacity: 30,
        status: "active",
        location: "Restaurant, Floor 1",
        enquiries: 5
      },
      {
        id: "venue-5",
        name: "Conference Room B",
        type: "Meeting Room",
        capacity: 50,
        status: "maintenance",
        location: "Business Center, Floor 3",
        enquiries: 0
      }
    ];
    
    setVenues([...venuesWithDetails, ...sampleVenues]);
  }, []);
    
  const filteredVenues = filter === "all" 
    ? venues 
    : venues.filter(venue => venue.status === filter);
    
  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold">My Venues</h1>
          <p className="text-muted-foreground">Manage your venue listings</p>
        </div>
        <div className="mt-4 md:mt-0 flex space-x-3">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <ListFilter className="mr-2 h-4 w-4" />
                Filter
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuLabel>Filter by Status</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setFilter("all")}>
                All Venues
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter("active")}>
                Active Venues
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter("maintenance")}>
                Under Maintenance
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Button asChild>
            <Link to="/supplier/venues/new">
              <Plus className="mr-2 h-4 w-4" />
              Add Venue
            </Link>
          </Button>
        </div>
      </div>
      
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Capacity</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Location</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredVenues.length > 0 ? (
                filteredVenues.map((venue) => (
                  <TableRow key={venue.id}>
                    <TableCell>
                      <div>
                        <p className="font-medium">{venue.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {venue.roomTypes 
                            ? `${venue.roomTypes} room types` 
                            : `${venue.enquiries} recent enquiries`}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>{venue.type}</TableCell>
                    <TableCell>{venue.capacity}</TableCell>
                    <TableCell>
                      <Badge variant={venue.status === "active" ? "default" : "secondary"}>
                        {venue.status === "active" ? "Active" : "Maintenance"}
                      </Badge>
                    </TableCell>
                    <TableCell>{venue.location}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Open menu</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit Venue
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            View Analytics
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-destructive">
                            Deactivate
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center">
                    No venues found
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default VenuesList;
