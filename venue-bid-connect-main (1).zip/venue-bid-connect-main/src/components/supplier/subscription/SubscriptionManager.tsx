
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/components/ui/use-toast";
import { Check, Info, Minus, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export function SubscriptionManager() {
  const [activeSubscription, setActiveSubscription] = useState({
    credits: 1,
    nextBilling: "July 28, 2025",
    billingType: "monthly"
  });
  
  const [selectedCredits, setSelectedCredits] = useState(1);
  const [billingType, setBillingType] = useState<"monthly" | "annual">("monthly");

  const calculatePrice = (credits: number, billingType: "monthly" | "annual") => {
    const basePrice = 50; // $50 per property
    let discount = 0;
    
    // Apply volume discounts
    if (credits >= 10) {
      discount = 0.20; // 20% discount for 10+ properties
    } else if (credits >= 5) {
      discount = 0.10; // 10% discount for 5-9 properties
    }
    
    const pricePerCredit = basePrice * (1 - discount);
    let totalPrice = pricePerCredit * credits;
    
    // For annual billing, calculate total price (10 months for 12 months)
    if (billingType === "annual") {
      totalPrice = (pricePerCredit * credits) * 10;
    }
    
    return {
      pricePerCredit,
      discount,
      totalPrice,
      discountPercentage: discount * 100
    };
  };
  
  const handleQuantityChange = (value: number) => {
    const newValue = Math.max(1, Math.min(50, value));
    setSelectedCredits(newValue);
  };
  
  const handlePurchase = () => {
    // This would integrate with a payment gateway in a real implementation
    toast({
      title: "Subscription Updated",
      description: `You've successfully subscribed to ${selectedCredits} property credits with ${billingType} billing.`,
    });
    
    setActiveSubscription({
      credits: selectedCredits,
      nextBilling: "July 28, 2025", // This would be dynamically set based on the purchase date
      billingType
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Subscription Management</h2>
        <p className="text-muted-foreground mt-2">
          Manage your subscription and property listing credits
        </p>
      </div>

      <Card className="mb-6">
        <CardHeader className="pb-3">
          <CardTitle>Current Subscription</CardTitle>
          <CardDescription>
            Your current plan and available credits
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            <div className="flex items-center justify-between border-b pb-2">
              <span className="font-medium">Property Credits</span>
              <div className="flex items-center">
                <span className="mr-2">{activeSubscription.credits} credit{activeSubscription.credits > 1 ? 's' : ''}</span>
                <Badge variant="outline" className="bg-primary/10 text-primary">Active</Badge>
              </div>
            </div>
            <div className="flex items-center justify-between border-b pb-2">
              <span className="font-medium">Billing Type</span>
              <span className="capitalize">{activeSubscription.billingType}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-medium">Next Billing</span>
              <span>{activeSubscription.nextBilling}</span>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button variant="outline" className="w-full">
            Manage Payment Methods
          </Button>
        </CardFooter>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <h3 className="text-xl font-semibold mb-3">Change Plan</h3>
          <Tabs defaultValue="monthly" className="w-full" onValueChange={(value) => setBillingType(value as "monthly" | "annual")}>
            <TabsList className="mb-4">
              <TabsTrigger value="monthly">Monthly Billing</TabsTrigger>
              <TabsTrigger value="annual">Annual Billing</TabsTrigger>
            </TabsList>
            <TabsContent value="monthly" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Property Credits</CardTitle>
                  <CardDescription>
                    Select how many property listings you need
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="credits" className="text-sm font-medium">Number of Property Credits</Label>
                      <div className="flex items-center mt-2">
                        <Button 
                          variant="outline" 
                          size="icon" 
                          onClick={() => handleQuantityChange(selectedCredits - 1)}
                          disabled={selectedCredits <= 1}
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                        <Input
                          id="credits"
                          type="number"
                          min="1"
                          max="50"
                          value={selectedCredits}
                          onChange={(e) => handleQuantityChange(parseInt(e.target.value) || 1)}
                          className="h-9 w-20 mx-2 text-center"
                        />
                        <Button 
                          variant="outline" 
                          size="icon" 
                          onClick={() => handleQuantityChange(selectedCredits + 1)}
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="py-4 space-y-2">
                      {calculatePrice(selectedCredits, "monthly").discount > 0 && (
                        <div className="flex items-center text-primary">
                          <Check className="mr-2 h-4 w-4" />
                          <span>
                            {calculatePrice(selectedCredits, "monthly").discountPercentage}% volume discount applied
                          </span>
                        </div>
                      )}
                      <div className="flex items-center">
                        <Check className="mr-2 h-4 w-4 text-primary" />
                        <span>
                          ${calculatePrice(selectedCredits, "monthly").pricePerCredit.toFixed(2)} per property credit
                        </span>
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">Monthly Total:</span>
                        <span className="font-bold text-xl">
                          ${calculatePrice(selectedCredits, "monthly").totalPrice.toFixed(2)}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        For {selectedCredits} property listing{selectedCredits > 1 ? 's' : ''}
                      </p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button 
                    className="w-full" 
                    onClick={handlePurchase}
                  >
                    Subscribe
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            <TabsContent value="annual" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Property Credits</CardTitle>
                  <CardDescription>
                    Select how many property listings you need - Annual billing (Pay for 10 months, get 12)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="credits-annual" className="text-sm font-medium">Number of Property Credits</Label>
                      <div className="flex items-center mt-2">
                        <Button 
                          variant="outline" 
                          size="icon" 
                          onClick={() => handleQuantityChange(selectedCredits - 1)}
                          disabled={selectedCredits <= 1}
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                        <Input
                          id="credits-annual"
                          type="number"
                          min="1"
                          max="50"
                          value={selectedCredits}
                          onChange={(e) => handleQuantityChange(parseInt(e.target.value) || 1)}
                          className="h-9 w-20 mx-2 text-center"
                        />
                        <Button 
                          variant="outline" 
                          size="icon" 
                          onClick={() => handleQuantityChange(selectedCredits + 1)}
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="py-4 space-y-2">
                      <div className="flex items-center text-primary">
                        <Check className="mr-2 h-4 w-4" />
                        <span>2 months free with annual billing</span>
                      </div>
                      {calculatePrice(selectedCredits, "annual").discount > 0 && (
                        <div className="flex items-center text-primary">
                          <Check className="mr-2 h-4 w-4" />
                          <span>
                            {calculatePrice(selectedCredits, "annual").discountPercentage}% volume discount applied
                          </span>
                        </div>
                      )}
                      <div className="flex items-center">
                        <Check className="mr-2 h-4 w-4 text-primary" />
                        <span>
                          ${calculatePrice(selectedCredits, "annual").pricePerCredit.toFixed(2)} per property credit per month
                        </span>
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">Annual Total:</span>
                        <span className="font-bold text-xl">
                          ${calculatePrice(selectedCredits, "annual").totalPrice.toFixed(2)}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        For {selectedCredits} property listing{selectedCredits > 1 ? 's' : ''} for 12 months
                      </p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button 
                    className="w-full" 
                    onClick={handlePurchase}
                  >
                    Subscribe
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div>
          <h3 className="text-xl font-semibold mb-3">Subscription Benefits</h3>
          <Card>
            <CardHeader>
              <CardTitle>Volume Discounts</CardTitle>
              <CardDescription>Save more as you add more properties</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h4 className="font-medium mb-2">Per-Property Pricing</h4>
                <ul className="space-y-2">
                  <li className="flex items-center justify-between">
                    <span>1-4 properties:</span>
                    <span className="font-medium">$50.00 per property</span>
                  </li>
                  <li className="flex items-center justify-between">
                    <span>5-9 properties:</span>
                    <span className="font-medium">$45.00 per property (10% off)</span>
                  </li>
                  <li className="flex items-center justify-between">
                    <span>10+ properties:</span>
                    <span className="font-medium">$40.00 per property (20% off)</span>
                  </li>
                </ul>
              </div>

              <div className="border-t pt-6">
                <h4 className="font-medium mb-2">Annual Billing Bonus</h4>
                <div className="flex items-center">
                  <Info className="h-5 w-5 mr-2 text-primary" />
                  <p>Pay for 10 months and get 12 months of service with our annual billing option</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Frequently Asked Questions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-medium">What is a property credit?</h4>
                <p className="text-muted-foreground">Each property credit allows you to list one unique property on our marketplace.</p>
              </div>
              <div>
                <h4 className="font-medium">Can I upgrade my plan?</h4>
                <p className="text-muted-foreground">Yes, you can add more property credits at any time. Your billing will be prorated based on the remaining time in your current billing cycle.</p>
              </div>
              <div>
                <h4 className="font-medium">What happens if I need to list more properties?</h4>
                <p className="text-muted-foreground">Simply purchase additional property credits as needed. Volume discounts will apply automatically based on your total number of credits.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
