
import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "@/components/ui/use-toast";
import { Card, CardFooter, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BidFormValues, enquiryData } from "./bid/types";
import EnquiryDetailsCard from "./bid/EnquiryDetailsCard";
import BidFormContent from "./bid/BidFormContent";

const BidForm = () => {
  const navigate = useNavigate();
  const { enquiryId } = useParams();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Get enquiry data based on ID
  const enquiry = enquiryId ? enquiryData[enquiryId] : null;
  
  if (!enquiry) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Enquiry Not Found</CardTitle>
          <CardDescription>The enquiry you are looking for does not exist.</CardDescription>
        </CardHeader>
        <CardFooter>
          <Button onClick={() => navigate("/supplier/dashboard/enquiries")}>
            Back to Enquiries
          </Button>
        </CardFooter>
      </Card>
    );
  }
  
  const onSubmit = (data: BidFormValues) => {
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      console.log("Submitted bid:", data);
      toast({
        title: "Bid submitted successfully",
        description: `Your bid for ${enquiry.title} has been submitted.`,
      });
      navigate("/supplier/dashboard/enquiries");
      setIsSubmitting(false);
    }, 1000);
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold">Submit Bid</h1>
        <p className="text-muted-foreground">Respond to enquiry {enquiry.id}</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <EnquiryDetailsCard enquiry={enquiry} />
        </div>
        
        <div className="md:col-span-2">
          <BidFormContent 
            onSubmit={onSubmit}
            isSubmitting={isSubmitting}
            onCancel={() => navigate("/supplier/dashboard/enquiries")}
          />
        </div>
      </div>
    </div>
  );
};

export default BidForm;
