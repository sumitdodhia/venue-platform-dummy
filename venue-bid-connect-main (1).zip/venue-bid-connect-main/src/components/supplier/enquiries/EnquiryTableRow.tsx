
import {
  TableCell,
  TableRow,
} from "@/components/ui/table";
import { EnquiryType } from "@/components/supplier/bid/types";
import EnquiryStatusBadge from "./EnquiryStatusBadge";
import EnquiryActions from "./EnquiryActions";

type EnquiryTableRowProps = {
  enquiry: EnquiryType;
  onStatusChange?: (enquiryId: string, newStatus: string) => void;
};

const EnquiryTableRow = ({ enquiry, onStatusChange }: EnquiryTableRowProps) => {
  const getVenue = (enquiry: EnquiryType) => {
    if ("guests" in enquiry) {
      return "Conference Venue";
    } else if ("roomCount" in enquiry) {
      return enquiry.roomType || "Any";
    }
    return "Any";
  };

  return (
    <TableRow key={enquiry.id}>
      <TableCell>
        <div>
          <p className="font-medium">{enquiry.title}</p>
          <p className="text-xs text-muted-foreground">
            ID: {enquiry.id}
          </p>
        </div>
      </TableCell>
      <TableCell>{enquiry.company}</TableCell>
      <TableCell>
        <div>
          <p>{"date" in enquiry ? enquiry.date : "checkInDate" in enquiry ? enquiry.checkInDate : "N/A"}</p>
          <p className="text-xs text-muted-foreground">
            Deadline: {enquiry.deadline}
          </p>
        </div>
      </TableCell>
      <TableCell>{"guests" in enquiry ? enquiry.guests : "roomCount" in enquiry ? enquiry.roomCount : "N/A"}</TableCell>
      <TableCell>{getVenue(enquiry)}</TableCell>
      <TableCell><EnquiryStatusBadge status={enquiry.status} /></TableCell>
      <TableCell>
        <EnquiryActions enquiry={enquiry} onStatusChange={onStatusChange} />
      </TableCell>
    </TableRow>
  );
};

export default EnquiryTableRow;
