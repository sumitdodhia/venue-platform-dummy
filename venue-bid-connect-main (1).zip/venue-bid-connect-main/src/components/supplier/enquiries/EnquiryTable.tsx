
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronUp } from "lucide-react";
import { Link } from "react-router-dom";

interface EnquiryType {
  id: string;
  title: string;
  company: string;
  status: string;
  category: string;
  deadline: string;
  requirements: string;
  budget: string;
}

interface EnquiryTableProps {
  enquiries: EnquiryType[];
  onSort?: (key: keyof EnquiryType) => void;
  sortConfig?: {
    key: keyof EnquiryType;
    direction: "ascending" | "descending";
  } | null;
  onStatusChange?: (enquiryId: string, newStatus: string) => void;
}

const EnquiryTable = ({ enquiries, onSort, sortConfig, onStatusChange }: EnquiryTableProps) => {
  // Function to get the sort direction icon
  const getSortDirectionIcon = (key: keyof EnquiryType) => {
    if (!sortConfig || sortConfig.key !== key) {
      return null;
    }
    return sortConfig.direction === "ascending" ? 
      <ChevronUp className="ml-1 h-4 w-4" /> : 
      <ChevronDown className="ml-1 h-4 w-4" />;
  };
  
  // Function to render the status badge
  const renderStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case 'open':
        return <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">Open</span>;
      case 'closed':
        return <span className="px-2 py-1 rounded-full text-xs bg-gray-100 text-gray-800">Closed</span>;
      case 'awarded':
        return <span className="px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800">Awarded</span>;
      default:
        return <span className="px-2 py-1 rounded-full text-xs bg-gray-100 text-gray-800">{status}</span>;
    }
  };

  return (
    <div className="border rounded-md">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead 
              className={onSort ? "cursor-pointer" : ""}
              onClick={() => onSort && onSort('title')}
            >
              <div className="flex items-center">
                Title
                {onSort && getSortDirectionIcon('title')}
              </div>
            </TableHead>
            <TableHead 
              className={onSort ? "cursor-pointer" : ""}
              onClick={() => onSort && onSort('company')}
            >
              <div className="flex items-center">
                Company
                {onSort && getSortDirectionIcon('company')}
              </div>
            </TableHead>
            <TableHead 
              className={onSort ? "cursor-pointer" : ""}
              onClick={() => onSort && onSort('category')}
            >
              <div className="flex items-center">
                Category
                {onSort && getSortDirectionIcon('category')}
              </div>
            </TableHead>
            <TableHead 
              className={onSort ? "cursor-pointer" : ""}
              onClick={() => onSort && onSort('deadline')}
            >
              <div className="flex items-center">
                Deadline
                {onSort && getSortDirectionIcon('deadline')}
              </div>
            </TableHead>
            <TableHead 
              className={onSort ? "cursor-pointer" : ""}
              onClick={() => onSort && onSort('status')}
            >
              <div className="flex items-center">
                Status
                {onSort && getSortDirectionIcon('status')}
              </div>
            </TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {enquiries.length === 0 ? (
            <TableRow>
              <TableCell colSpan={6} className="text-center py-6 text-muted-foreground">
                No enquiries found
              </TableCell>
            </TableRow>
          ) : (
            enquiries.map((enquiry) => (
              <TableRow key={enquiry.id}>
                <TableCell className="font-medium">{enquiry.title}</TableCell>
                <TableCell>{enquiry.company}</TableCell>
                <TableCell>{enquiry.category}</TableCell>
                <TableCell>{enquiry.deadline}</TableCell>
                <TableCell>{renderStatusBadge(enquiry.status)}</TableCell>
                <TableCell>
                  <Button 
                    variant="secondary" 
                    size="sm" 
                    asChild
                  >
                    <Link to={`/supplier/enquiries/${enquiry.id}`}>View Details</Link>
                  </Button>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
};

export default EnquiryTable;
