
import React, { useState } from "react";
import EnquiryTable from "./EnquiryTable";
import EnquiryFilters from "./EnquiryFilters";
import EnquiryPagination from "./EnquiryPagination";
import EnquirySearch from "./EnquirySearch";
import { Card } from "@/components/ui/card";

// Define the EnquiryType for this component
interface EnquiryType {
  id: string;
  title: string;
  company: string;
  status: string;
  category: string;
  deadline: string;
  requirements: string;
  budget: string;
}

// Mock data
const mockEnquiries: EnquiryType[] = [
  {
    id: "1",
    title: "Corporate Event",
    company: "ABC Corp",
    status: "open",
    category: "Conference",
    deadline: "2025-06-01",
    requirements: "Need space for 100 people",
    budget: "$5,000"
  },
  {
    id: "2",
    title: "Wedding Reception",
    company: "Private",
    status: "open",
    category: "Restaurant",
    deadline: "2025-07-15",
    requirements: "Elegant venue for 80 guests",
    budget: "$7,000"
  },
  {
    id: "3",
    title: "Team Building Retreat",
    company: "Tech Inc",
    status: "closed",
    category: "Accommodation",
    deadline: "2025-05-30",
    requirements: "10 rooms for 2 nights",
    budget: "$3,500"
  },
  {
    id: "4",
    title: "Executive Meeting",
    company: "Finance Co",
    status: "open",
    category: "Conference",
    deadline: "2025-06-10",
    requirements: "Private boardroom",
    budget: "$1,200"
  },
  {
    id: "5",
    title: "Product Launch",
    company: "Startup XYZ",
    status: "open",
    category: "Conference",
    deadline: "2025-08-01",
    requirements: "Multimedia facilities",
    budget: "$4,000"
  }
];

const BiddingEnquiriesList = () => {
  // State for enquiries data, filtering, pagination, etc.
  const [enquiries, setEnquiries] = useState<EnquiryType[]>(mockEnquiries.slice(0, 10));
  const [filteredEnquiries, setFilteredEnquiries] = useState<EnquiryType[]>(enquiries);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(5);
  const [totalItems] = useState(mockEnquiries.length);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortConfig, setSortConfig] = useState<{
    key: keyof EnquiryType;
    direction: "ascending" | "descending";
  } | null>(null);

  // Filter enquiries based on search term
  const handleSearch = (term: string) => {
    setSearchTerm(term);
    if (term.trim() === "") {
      setFilteredEnquiries(enquiries);
    } else {
      const filtered = enquiries.filter((enquiry) =>
        Object.values(enquiry)
          .join(" ")
          .toLowerCase()
          .includes(term.toLowerCase())
      );
      setFilteredEnquiries(filtered);
    }
    setCurrentPage(1);
  };

  // Handle sorting
  const handleSort = (key: keyof EnquiryType) => {
    let direction: "ascending" | "descending" = "ascending";
    
    if (sortConfig && sortConfig.key === key && sortConfig.direction === "ascending") {
      direction = "descending";
    }
    
    setSortConfig({ key, direction });
    
    const sortedEnquiries = [...filteredEnquiries].sort((a, b) => {
      if (a[key] < b[key]) return direction === "ascending" ? -1 : 1;
      if (a[key] > b[key]) return direction === "ascending" ? 1 : -1;
      return 0;
    });
    
    setFilteredEnquiries(sortedEnquiries);
  };

  // Handle filters
  const handleFilterChange = (filterType: string, value: string) => {
    // In a real app, this would apply filters to the enquiries
    console.log(`Filter ${filterType} set to ${value}`);
  };

  // Calculate pagination
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredEnquiries.slice(indexOfFirstItem, indexOfLastItem);

  // Handle page change
  const paginate = (pageNumber: number) => setCurrentPage(pageNumber);

  return (
    <Card className="p-4">
      <div className="flex flex-col space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold">Bidding Enquiries</h2>
          <EnquirySearch onSearch={handleSearch} searchTerm={searchTerm} />
        </div>
        
        <EnquiryFilters setFilter={handleFilterChange} />
        
        <EnquiryTable 
          enquiries={currentItems} 
          onSort={handleSort} 
          sortConfig={sortConfig}
        />
        
        <div className="flex justify-between items-center mt-4">
          <div className="text-sm text-muted-foreground">
            Showing {indexOfFirstItem + 1} to {Math.min(indexOfLastItem, filteredEnquiries.length)} of {filteredEnquiries.length} entries
          </div>
          
          <EnquiryPagination 
            currentPage={currentPage}
            totalItems={filteredEnquiries.length}
            itemsPerPage={itemsPerPage}
            onPageChange={paginate}
          />
        </div>
      </div>
    </Card>
  );
};

export default BiddingEnquiriesList;
