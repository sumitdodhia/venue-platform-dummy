
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { Filter, Check } from "lucide-react";

export interface EnquiryFiltersProps {
  setFilter: (filterType: string, value: string) => void;
  isDirectEnquiry?: boolean; // Added optional prop
}

const EnquiryFilters = ({ setFilter, isDirectEnquiry = false }: EnquiryFiltersProps) => {
  const [statusFilters, setStatusFilters] = useState<Record<string, boolean>>({
    open: false,
    closed: false,
    awarded: false,
  });

  const [categoryFilters, setCategoryFilters] = useState<Record<string, boolean>>({
    Conference: false,
    Restaurant: false,
    Accommodation: false,
  });

  const handleStatusChange = (status: string) => {
    setStatusFilters(prev => {
      const newState = { ...prev, [status]: !prev[status] };
      
      // Apply the filter based on selected statuses
      const selectedStatuses = Object.entries(newState)
        .filter(([_, isSelected]) => isSelected)
        .map(([status]) => status);
      
      setFilter('status', selectedStatuses.length ? selectedStatuses.join(',') : '');
      return newState;
    });
  };

  const handleCategoryChange = (category: string) => {
    setCategoryFilters(prev => {
      const newState = { ...prev, [category]: !prev[category] };
      
      // Apply the filter based on selected categories
      const selectedCategories = Object.entries(newState)
        .filter(([_, isSelected]) => isSelected)
        .map(([category]) => category);
      
      setFilter('category', selectedCategories.length ? selectedCategories.join(',') : '');
      return newState;
    });
  };

  const clearAllFilters = () => {
    setStatusFilters({
      open: false,
      closed: false,
      awarded: false,
    });
    setCategoryFilters({
      Conference: false,
      Restaurant: false,
      Accommodation: false,
    });
    setFilter('status', '');
    setFilter('category', '');
  };

  // Count active filters
  const activeFiltersCount = 
    Object.values(statusFilters).filter(Boolean).length +
    Object.values(categoryFilters).filter(Boolean).length;

  return (
    <div className="flex items-center mb-4">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="relative">
            <Filter className="h-4 w-4 mr-2" />
            Filters
            {activeFiltersCount > 0 && (
              <span className="ml-2 h-5 w-5 bg-primary text-primary-foreground rounded-full text-xs flex items-center justify-center">
                {activeFiltersCount}
              </span>
            )}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-56">
          <DropdownMenuLabel>Status</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuCheckboxItem 
            checked={statusFilters.open}
            onCheckedChange={() => handleStatusChange('open')}
          >
            Open
          </DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem 
            checked={statusFilters.closed}
            onCheckedChange={() => handleStatusChange('closed')}
          >
            Closed
          </DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem 
            checked={statusFilters.awarded}
            onCheckedChange={() => handleStatusChange('awarded')}
          >
            Awarded
          </DropdownMenuCheckboxItem>
          
          <DropdownMenuSeparator />
          <DropdownMenuLabel>Category</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuCheckboxItem 
            checked={categoryFilters.Conference}
            onCheckedChange={() => handleCategoryChange('Conference')}
          >
            Conference
          </DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem 
            checked={categoryFilters.Restaurant}
            onCheckedChange={() => handleCategoryChange('Restaurant')}
          >
            Restaurant
          </DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem 
            checked={categoryFilters.Accommodation}
            onCheckedChange={() => handleCategoryChange('Accommodation')}
          >
            Accommodation
          </DropdownMenuCheckboxItem>
          
          <DropdownMenuSeparator />
          <div className="p-2">
            <Button 
              variant="ghost" 
              size="sm" 
              className="w-full justify-center"
              onClick={clearAllFilters}
            >
              Clear all filters
            </Button>
          </div>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
};

export default EnquiryFilters;
