
import { useState } from "react";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { enquiryData, EnquiryType } from "@/components/supplier/bid/types";
import EnquiryFilters from "./EnquiryFilters";
import EnquiryTable from "./EnquiryTable";
import EnquiryPagination from "./EnquiryPagination";

const EnquiriesList = () => {
  const [filter, setFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [enquiries, setEnquiries] = useState<EnquiryType[]>(Object.values(enquiryData));
  
  const getFilteredEnquiries = () => {
    if (filter === "all") return enquiries;
    return enquiries.filter(enquiry => enquiry.status === filter);
  };

  const handleStatusChange = (enquiryId: string, newStatus: string) => {
    // Update the status of the enquiry with the given ID
    const updatedEnquiries = enquiries.map(enquiry => 
      enquiry.id === enquiryId ? { ...enquiry, status: newStatus } : enquiry
    );
    setEnquiries(updatedEnquiries);
  };
  
  const handleFilterChange = (filterType: string, value: string) => {
    if (filterType === 'status') {
      setFilter(value || 'all');
    }
  };
  
  const filteredEnquiries = getFilteredEnquiries();
  
  // Pagination
  const itemsPerPage = 5;
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const paginatedEnquiries = filteredEnquiries.slice(indexOfFirstItem, indexOfLastItem);

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold">Enquiries</h1>
          <p className="text-muted-foreground">Manage enquiries and submit bids</p>
        </div>
        <div className="mt-4 md:mt-0 flex space-x-3">
          <EnquiryFilters setFilter={handleFilterChange} />
        </div>
      </div>
      
      <Card>
        <CardContent className="p-0">
          <EnquiryTable 
            enquiries={paginatedEnquiries}
          />
        </CardContent>
      </Card>
      
      <div className="mt-4">
        <EnquiryPagination 
          currentPage={currentPage}
          totalItems={filteredEnquiries.length}
          itemsPerPage={itemsPerPage}
          onPageChange={setCurrentPage}
        />
      </div>
    </div>
  );
};

export default EnquiriesList;
