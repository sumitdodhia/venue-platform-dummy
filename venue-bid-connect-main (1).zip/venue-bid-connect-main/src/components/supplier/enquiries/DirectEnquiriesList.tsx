
import { useState } from "react";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import EnquiryFilters from "./EnquiryFilters";
import EnquirySearch from "./EnquirySearch";
import EnquiryPagination from "./EnquiryPagination";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import EnquiryStatusBadge from "./EnquiryStatusBadge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

// Mock direct enquiries data
const directEnquiries = [
  {
    id: "dir-001",
    clientName: "TechCorp Innovations",
    subject: "Company Anniversary Dinner",
    date: "2025-08-15",
    guestCount: 45,
    status: "new",
    venue: "Grand Ballroom"
  },
  {
    id: "dir-002",
    clientName: "DataVision Partners",
    subject: "Board Meeting & Lunch",
    date: "2025-07-10",
    guestCount: 12,
    status: "confirmed",
    venue: "Executive Meeting Room"
  },
  {
    id: "dir-003",
    clientName: "CloudNet Solutions",
    subject: "Product Launch Reception",
    date: "2025-09-05",
    guestCount: 75,
    status: "pending",
    venue: "Garden Terrace"
  },
  {
    id: "dir-004",
    clientName: "GlobalPay Financial",
    subject: "Client Appreciation Dinner",
    date: "2025-10-20",
    guestCount: 30,
    status: "new",
    venue: "Private Dining Room"
  },
  {
    id: "dir-005",
    clientName: "Quantum Industries",
    subject: "Team Building Retreat",
    date: "2025-08-25",
    guestCount: 22,
    status: "cancelled",
    venue: "Conference Center"
  },
  {
    id: "dir-006",
    clientName: "EcoSolutions Inc",
    subject: "Investor Breakfast Meeting",
    date: "2025-07-05",
    guestCount: 15,
    status: "confirmed",
    venue: "Sunrise Room"
  },
];

const DirectEnquiriesList = () => {
  const [filter, setFilter] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [sortBy, setSortBy] = useState({ field: "date", direction: "asc" });
  const [enquiries, setEnquiries] = useState(directEnquiries);
  
  // Filter by status and search term
  const getFilteredEnquiries = () => {
    return enquiries
      .filter(enquiry => filter === "all" || enquiry.status === filter)
      .filter(enquiry => 
        searchTerm === "" || 
        enquiry.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
        enquiry.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        enquiry.id.toLowerCase().includes(searchTerm.toLowerCase())
      );
  };

  // Sort enquiries
  const handleSort = (field: string) => {
    setSortBy(prev => ({
      field,
      direction: prev.field === field && prev.direction === "asc" ? "desc" : "asc"
    }));
  };
  
  // Get filtered and sorted enquiries
  const filteredEnquiries = getFilteredEnquiries();
  
  // Sort enquiries
  const sortedEnquiries = [...filteredEnquiries].sort((a, b) => {
    const field = sortBy.field as keyof (typeof directEnquiries)[0];
    
    const valueA = a[field];
    const valueB = b[field];
    
    if (sortBy.direction === "asc") {
      return valueA > valueB ? 1 : -1;
    } else {
      return valueA < valueB ? 1 : -1;
    }
  });
  
  // Pagination
  const itemsPerPage = 5;
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const paginatedEnquiries = sortedEnquiries.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(sortedEnquiries.length / itemsPerPage);

  // Update filter function to match expected interface
  const handleFilterChange = (filterType: string, value: string) => {
    if (filterType === 'status') {
      setFilter(value || 'all');
    }
  };

  // Status badge for direct enquiries
  const getDirectEnquiryStatusBadge = (status: string) => {
    switch (status) {
      case "new":
        return <EnquiryStatusBadge status="new" />;
      case "confirmed":
        return <EnquiryStatusBadge status="awarded" />;
      case "pending":
        return <EnquiryStatusBadge status="bid_submitted" />;
      case "cancelled":
        return <EnquiryStatusBadge status="no_bid" />;
      default:
        return <EnquiryStatusBadge status={status} />;
    }
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold">Direct Enquiries</h1>
          <p className="text-muted-foreground">Manage direct bookings and venue requests</p>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <EnquirySearch onSearch={setSearchTerm} searchTerm={searchTerm} />
        <EnquiryFilters setFilter={handleFilterChange} isDirectEnquiry={true} />
      </div>
      
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="cursor-pointer" onClick={() => handleSort("id")}>
                  ID {sortBy.field === "id" && (sortBy.direction === "asc" ? "↑" : "↓")}
                </TableHead>
                <TableHead className="cursor-pointer" onClick={() => handleSort("clientName")}>
                  Client {sortBy.field === "clientName" && (sortBy.direction === "asc" ? "↑" : "↓")}
                </TableHead>
                <TableHead className="cursor-pointer" onClick={() => handleSort("subject")}>
                  Subject {sortBy.field === "subject" && (sortBy.direction === "asc" ? "↑" : "↓")}
                </TableHead>
                <TableHead className="cursor-pointer" onClick={() => handleSort("date")}>
                  Date {sortBy.field === "date" && (sortBy.direction === "asc" ? "↑" : "↓")}
                </TableHead>
                <TableHead className="cursor-pointer" onClick={() => handleSort("guestCount")}>
                  Guests {sortBy.field === "guestCount" && (sortBy.direction === "asc" ? "↑" : "↓")}
                </TableHead>
                <TableHead className="cursor-pointer" onClick={() => handleSort("venue")}>
                  Venue {sortBy.field === "venue" && (sortBy.direction === "asc" ? "↑" : "↓")}
                </TableHead>
                <TableHead className="cursor-pointer" onClick={() => handleSort("status")}>
                  Status {sortBy.field === "status" && (sortBy.direction === "asc" ? "↑" : "↓")}
                </TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedEnquiries.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-6">
                    No direct enquiries found
                  </TableCell>
                </TableRow>
              ) : (
                paginatedEnquiries.map((enquiry) => (
                  <TableRow key={enquiry.id}>
                    <TableCell className="font-medium">{enquiry.id}</TableCell>
                    <TableCell>{enquiry.clientName}</TableCell>
                    <TableCell>{enquiry.subject}</TableCell>
                    <TableCell>{enquiry.date}</TableCell>
                    <TableCell>{enquiry.guestCount}</TableCell>
                    <TableCell>{enquiry.venue}</TableCell>
                    <TableCell>{getDirectEnquiryStatusBadge(enquiry.status)}</TableCell>
                    <TableCell>
                      <Button variant="outline" size="sm" asChild>
                        <Link to={`/supplier/enquiries/direct/${enquiry.id}`}>
                          View Details
                        </Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      <div className="mt-4">
        <EnquiryPagination 
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={setCurrentPage}
        />
      </div>
    </div>
  );
};

export default DirectEnquiriesList;
