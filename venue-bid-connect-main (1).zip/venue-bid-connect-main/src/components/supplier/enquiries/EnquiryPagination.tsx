
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface EnquiryPaginationProps {
  currentPage: number;
  totalPages?: number;
  onPageChange: (pageNumber: number) => void;
  totalItems?: number; 
  itemsPerPage?: number;
}

const EnquiryPagination = ({ 
  currentPage, 
  totalPages, 
  onPageChange,
  totalItems,
  itemsPerPage 
}: EnquiryPaginationProps) => {
  // Calculate totalPages if both totalItems and itemsPerPage are provided
  const calculatedTotalPages = totalItems && itemsPerPage ? Math.ceil(totalItems / itemsPerPage) : totalPages;
  
  // Use calculated value or the direct totalPages prop
  const finalTotalPages = calculatedTotalPages || 1;

  // Generate page numbers to display
  const getPageNumbers = () => {
    const pageNumbers = [];
    let startPage = Math.max(1, currentPage - 1);
    let endPage = Math.min(finalTotalPages, startPage + 2);
    
    // Adjust if we're at the end
    if (endPage - startPage < 2) {
      startPage = Math.max(1, endPage - 2);
    }

    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(i);
    }
    
    return pageNumbers;
  };

  if (finalTotalPages <= 1) return null;

  return (
    <div className="flex items-center justify-center space-x-1">
      <Button
        variant="outline"
        size="icon"
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
      >
        <ChevronLeft className="h-4 w-4" />
      </Button>
      
      {getPageNumbers().map((num) => (
        <Button
          key={num}
          variant={num === currentPage ? "secondary" : "outline"}
          size="sm"
          onClick={() => onPageChange(num)}
          className="px-3"
        >
          {num}
        </Button>
      ))}
      
      <Button
        variant="outline"
        size="icon"
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === finalTotalPages}
      >
        <ChevronRight className="h-4 w-4" />
      </Button>
    </div>
  );
};

export default EnquiryPagination;
