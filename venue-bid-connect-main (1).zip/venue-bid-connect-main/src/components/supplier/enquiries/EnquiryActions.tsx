
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { MoreHorizontal, Mail, Check, X } from "lucide-react";
import { Link } from "react-router-dom";
import { EnquiryType } from "@/components/supplier/bid/types";
import { toast } from "sonner";

type EnquiryActionsProps = {
  enquiry: EnquiryType;
  onStatusChange?: (enquiryId: string, newStatus: string) => void;
};

const EnquiryActions = ({ enquiry, onStatusChange }: EnquiryActionsProps) => {
  const [isContactDialogOpen, setIsContactDialogOpen] = useState(false);
  const [isNoBidDialogOpen, setIsNoBidDialogOpen] = useState(false);

  const handleNoBid = () => {
    // In a real app, you would call an API to update the enquiry status
    toast.success(`No bid submitted for enquiry ${enquiry.id}`);
    
    if (onStatusChange) {
      onStatusChange(enquiry.id, "no_bid");
    }
    
    setIsNoBidDialogOpen(false);
  };

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="sm">
            <MoreHorizontal className="h-4 w-4" />
            <span className="sr-only">Open menu</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem asChild>
            <Link to={`/supplier/dashboard/enquiries/${enquiry.id}`}>
              View Details
            </Link>
          </DropdownMenuItem>
          
          {enquiry.status === "new" && (
            <>
              <DropdownMenuItem asChild>
                <Link to={`/supplier/dashboard/enquiries/${enquiry.id}/bid`}>
                  <Check className="h-4 w-4 mr-2" /> Submit Bid
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setIsNoBidDialogOpen(true)}>
                <X className="h-4 w-4 mr-2" /> No Bid to Submit
              </DropdownMenuItem>
            </>
          )}
          
          {enquiry.status === "bid_submitted" && (
            <DropdownMenuItem asChild>
              <Link to={`/supplier/dashboard/enquiries/${enquiry.id}/bid`}>
                Edit Bid
              </Link>
            </DropdownMenuItem>
          )}
          
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={() => setIsContactDialogOpen(true)}>
            <Mail className="h-4 w-4 mr-2" /> Contact Client
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Contact Client Dialog */}
      <Dialog open={isContactDialogOpen} onOpenChange={setIsContactDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Contact Client</DialogTitle>
            <DialogDescription>
              Contact details for {enquiry.company}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <div className="font-medium">Contact:</div>
              <div className="col-span-3">{enquiry.company} Representative</div>
            </div>
            
            <div className="grid grid-cols-4 items-center gap-4">
              <div className="font-medium">Email:</div>
              <div className="col-span-3">contact@{enquiry.company.toLowerCase().replace(/\s+/g, '')}.com</div>
            </div>
            
            <div className="grid grid-cols-4 items-center gap-4">
              <div className="font-medium">Phone:</div>
              <div className="col-span-3">+1 (555) 123-4567</div>
            </div>
          </div>
          
          <DialogFooter>
            <Button onClick={() => setIsContactDialogOpen(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* No Bid Confirmation Dialog */}
      <AlertDialog open={isNoBidDialogOpen} onOpenChange={setIsNoBidDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm No Bid</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to decline bidding on this enquiry? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleNoBid}>
              Confirm
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default EnquiryActions;
