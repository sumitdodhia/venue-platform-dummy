
import { Badge } from "@/components/ui/badge";

type EnquiryStatusBadgeProps = {
  status: string;
};

const EnquiryStatusBadge = ({ status }: EnquiryStatusBadgeProps) => {
  switch (status) {
    case "new":
      return <Badge className="bg-blue-500">New</Badge>;
    case "bid_submitted":
      return <Badge className="bg-amber-500">Bid Submitted</Badge>;
    case "no_bid":
      return <Badge variant="outline" className="border-red-500 text-red-500">No Bid</Badge>;
    case "awarded":
      return <Badge className="bg-green-500">Awarded</Badge>;
    case "rejected":
      return <Badge variant="outline" className="border-gray-500 text-gray-500">Rejected</Badge>;
    case "expired":
      return <Badge variant="secondary">Expired</Badge>;
    default:
      return <Badge variant="secondary">{status}</Badge>;
  }
};

export default EnquiryStatusBadge;
