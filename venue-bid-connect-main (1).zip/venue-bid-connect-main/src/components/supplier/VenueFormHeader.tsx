
interface VenueFormHeaderProps {
  venueType?: string;
}

const VenueFormHeader = ({ venueType }: VenueFormHeaderProps) => {
  // Get venue type display name for the header
  const getVenueTypeDisplayName = () => {
    switch (venueType) {
      case "conference":
        return "Conference Venue";
      case "hotel":
        return "Hotel";
      case "restaurant":
        return "Restaurant";
      case "event-space":
        return "Event Space";
      default:
        return "Venue";
    }
  };

  return (
    <div className="mb-8">
      <h1 className="text-2xl font-bold">Add New {getVenueTypeDisplayName()}</h1>
      <p className="text-muted-foreground">Create a new venue listing for your business</p>
    </div>
  );
};

export default VenueFormHeader;
