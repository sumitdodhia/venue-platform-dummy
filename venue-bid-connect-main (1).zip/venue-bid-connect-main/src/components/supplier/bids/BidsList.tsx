
import { useState } from "react";
import { Link } from "react-router-dom";
import { ListFilter, MoreHorizontal } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import { bidData, BidStatus, getBidWithEnquiry } from "../bid/bidTypes";
import { enquiryData } from "../bid/types";

const BidsList = () => {
  const [filter, setFilter] = useState<BidStatus | 'all'>('all');
  
  const getFilteredBids = () => {
    if (filter === 'all') return bidData;
    return bidData.filter(bid => bid.status === filter);
  };
  
  const filteredBids = getFilteredBids();
  
  // Function to get status badge
  const getStatusBadge = (status: BidStatus) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="border-amber-500 text-amber-500">Pending</Badge>;
      case "accepted":
        return <Badge className="bg-green-600">Accepted</Badge>;
      case "rejected":
        return <Badge variant="destructive">Rejected</Badge>;
      case "negotiating":
        return <Badge className="bg-blue-500">Negotiating</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  // Function to get enquiry type display name
  const getEnquiryType = (enquiryId: string) => {
    const enquiry = enquiryData[enquiryId];
    if (!enquiry) return "Unknown";
    
    if ("guests" in enquiry) {
      return "Conference";
    } else if ("roomCount" in enquiry) {
      return "Accommodation";
    }
    return "Other";
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold">My Bids</h1>
          <p className="text-muted-foreground">Track and manage your submitted bids</p>
        </div>
        <div className="mt-4 md:mt-0 flex space-x-3">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <ListFilter className="mr-2 h-4 w-4" />
                Filter
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuLabel>Filter by Status</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setFilter("all")}>
                All Bids
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter("pending")}>
                Pending
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter("accepted")}>
                Accepted
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter("rejected")}>
                Rejected
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter("negotiating")}>
                Negotiating
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      <Card>
        <CardHeader className="pb-4">
          <CardTitle>Submitted Bids</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Bid Details</TableHead>
                <TableHead>Enquiry</TableHead>
                <TableHead>Client Information</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Venue</TableHead>
                <TableHead>Submission Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredBids.map((bid) => {
                const enquiry = enquiryData[bid.enquiryId] || null;
                return (
                  <TableRow key={bid.id}>
                    <TableCell>
                      <div>
                        <p className="font-medium">{bid.id}</p>
                        <p className="text-xs text-muted-foreground">Last updated: {bid.lastUpdated}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium">{enquiry ? enquiry.title : "Unknown Enquiry"}</p>
                        <p className="text-xs text-muted-foreground">{getEnquiryType(bid.enquiryId)} • ID: {bid.enquiryId}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p>{bid.clientContact || "N/A"}</p>
                        <p className="text-xs text-muted-foreground">
                          {bid.clientEmail && <span className="block">{bid.clientEmail}</span>}
                          {bid.clientPhone && <span>{bid.clientPhone}</span>}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>{bid.price}</TableCell>
                    <TableCell>{bid.venue}</TableCell>
                    <TableCell>{bid.submittedAt}</TableCell>
                    <TableCell>{getStatusBadge(bid.status)}</TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Open menu</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem asChild>
                            <Link to={`/supplier/dashboard/bids/${bid.id}`}>
                              View Bid Details
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem asChild>
                            <Link to={`/supplier/dashboard/enquiries/${bid.enquiryId}`}>
                              View Original Enquiry
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem disabled={bid.status === "accepted"}>
                            Edit Bid
                          </DropdownMenuItem>
                          {bid.status === "pending" && (
                            <>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                Withdraw Bid
                              </DropdownMenuItem>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                );
              })}
              {filteredBids.length === 0 && (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-6">
                    <p className="text-muted-foreground">No bids found matching the selected filter.</p>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      <div className="mt-4">
        <Pagination>
          <PaginationContent>
            <PaginationItem>
              <PaginationPrevious href="#" />
            </PaginationItem>
            <PaginationItem>
              <PaginationLink href="#" isActive>1</PaginationLink>
            </PaginationItem>
            <PaginationItem>
              <PaginationLink href="#">2</PaginationLink>
            </PaginationItem>
            <PaginationItem>
              <PaginationNext href="#" />
            </PaginationItem>
          </PaginationContent>
        </Pagination>
      </div>
    </div>
  );
};

export default BidsList;
