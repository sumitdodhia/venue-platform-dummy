
import React from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DiningPackage } from "@/types/restaurantSupplier";
import { useDiningPackages } from "@/hooks/useDiningPackages";
import DiningPackageForm from "./packages/DiningPackageForm";
import PackagesList from "./packages/PackagesList";

interface DiningPackagesFormProps {
  packages: DiningPackage[];
  onSavePackages: (packages: DiningPackage[]) => void;
}

const DiningPackagesForm = ({ packages = [], onSavePackages }: DiningPackagesFormProps) => {
  const {
    diningPackage,
    setDiningPackage,
    includesText,
    setIncludesText,
    editIndex,
    packages: activePackages,
    handleAddIncludesItem,
    handleRemoveIncludesItem,
    handleAddPackage,
    handleEditPackage,
    handleRemovePackage,
    resetForm
  } = useDiningPackages(packages);

  const handleSave = () => {
    onSavePackages(activePackages);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>{editIndex !== null ? 'Edit Dining Package' : 'Add Dining Package'}</CardTitle>
        </CardHeader>
        
        <DiningPackageForm
          diningPackage={diningPackage}
          onDiningPackageChange={setDiningPackage}
          includesText={includesText}
          onIncludesTextChange={setIncludesText}
          onAddIncludesItem={handleAddIncludesItem}
          onRemoveIncludesItem={handleRemoveIncludesItem}
        />
        
        <CardFooter className="flex justify-between">
          <Button variant="ghost" onClick={resetForm}>Cancel</Button>
          <Button onClick={handleAddPackage}>
            {editIndex !== null ? 'Update Package' : 'Add Package'}
          </Button>
        </CardFooter>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Dining Packages ({activePackages.length})</CardTitle>
        </CardHeader>
        
        <PackagesList 
          packages={activePackages} 
          onEdit={handleEditPackage} 
          onRemove={handleRemovePackage} 
        />
        
        <CardFooter>
          <Button className="w-full" onClick={handleSave}>
            Save Packages
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default DiningPackagesForm;
