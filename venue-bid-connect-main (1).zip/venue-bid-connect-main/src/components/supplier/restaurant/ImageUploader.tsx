
import React, { useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { X, Upload } from "lucide-react";

interface ImageUploaderProps {
  photos: string[];
  setPhotos: React.Dispatch<React.SetStateAction<string[]>>;
  title: string;
  description: string;
  maxPhotos?: number;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({
  photos,
  setPhotos,
  title,
  description,
  maxPhotos = 10,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || photos.length >= maxPhotos) return;

    const newPhotos = [...photos];
    
    Array.from(files).forEach(file => {
      if (newPhotos.length < maxPhotos) {
        const reader = new FileReader();
        reader.onload = () => {
          if (typeof reader.result === 'string') {
            newPhotos.push(reader.result);
            setPhotos([...newPhotos]);
          }
        };
        reader.readAsDataURL(file);
      }
    });
    
    // Reset the input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleRemoveImage = (index: number) => {
    const newPhotos = [...photos];
    newPhotos.splice(index, 1);
    setPhotos(newPhotos);
  };

  return (
    <Card>
      <CardContent className="pt-6">
        <h3 className="text-lg font-medium mb-2">{title}</h3>
        <p className="text-sm text-muted-foreground mb-4">{description}</p>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {photos.map((photo, index) => (
            <div key={index} className="relative group aspect-square">
              <img 
                src={photo} 
                alt={`Uploaded image ${index + 1}`} 
                className="w-full h-full object-cover rounded-md"
              />
              <button
                type="button"
                onClick={() => handleRemoveImage(index)}
                className="absolute top-1 right-1 bg-black/70 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                aria-label="Remove image"
              >
                <X className="h-4 w-4" />
              </button>
              {index === 0 && (
                <span className="absolute bottom-1 left-1 bg-primary text-white text-xs px-2 py-1 rounded">
                  Main Image
                </span>
              )}
            </div>
          ))}
          
          {photos.length < maxPhotos && (
            <Button
              type="button"
              variant="outline"
              className="h-auto aspect-square flex flex-col items-center justify-center p-6 border-dashed"
              onClick={() => fileInputRef.current?.click()}
            >
              <Upload className="h-8 w-8 mb-2 text-muted-foreground" />
              <span className="text-xs text-center text-muted-foreground">
                Upload Image
              </span>
            </Button>
          )}
        </div>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          multiple
          onChange={handleFileChange}
          className="hidden"
          disabled={photos.length >= maxPhotos}
        />
        
        <p className="text-xs text-muted-foreground mt-2">
          {photos.length} of {maxPhotos} images uploaded
        </p>
      </CardContent>
    </Card>
  );
};

export default ImageUploader;
