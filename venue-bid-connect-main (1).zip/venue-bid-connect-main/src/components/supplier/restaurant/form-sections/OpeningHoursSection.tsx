
import React from "react";
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { UseFormReturn } from "react-hook-form";
import { RestaurantFormValues } from "../form-utils/RestaurantFormSchema";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

interface OpeningHoursSectionProps {
  form: UseFormReturn<RestaurantFormValues>;
}

const OpeningHoursSection: React.FC<OpeningHoursSectionProps> = ({ form }) => {
  const weekdays = [
    "monday",
    "tuesday",
    "wednesday",
    "thursday",
    "friday",
    "saturday",
    "sunday",
  ] as const;

  // Function to generate time options (24-hour format)
  const generateTimeOptions = () => {
    const options = [];
    for (let i = 0; i < 24; i++) {
      for (let j = 0; j < 60; j += 30) {
        const hour = i < 10 ? `0${i}` : `${i}`;
        const minute = j < 10 ? `0${j}` : `${j}`;
        options.push(`${hour}:${minute}`);
      }
    }
    return options;
  };

  const timeOptions = generateTimeOptions();

  const handleClosedToggle = (day: keyof RestaurantFormValues["openingHours"], isClosed: boolean) => {
    // If toggling to closed, reset times to default
    if (isClosed) {
      form.setValue(`openingHours.${day}.opening`, "", { shouldValidate: false });
      form.setValue(`openingHours.${day}.closing`, "", { shouldValidate: false });
    } else {
      // Default opening and closing times when toggling from closed to open
      form.setValue(`openingHours.${day}.opening`, "09:00", { shouldValidate: false });
      form.setValue(`openingHours.${day}.closing`, "22:00", { shouldValidate: false });
    }
    form.setValue(`openingHours.${day}.isClosed`, isClosed, { shouldValidate: true });
  };

  return (
    <Card>
      <CardContent className="pt-6">
        <h3 className="text-lg font-medium mb-4">Opening Hours</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Select opening and closing hours or mark as closed
        </p>

        <div className="space-y-2">
          {weekdays.map((day) => (
            <div key={day} className="grid grid-cols-1 md:grid-cols-4 items-center gap-4 border-b pb-2 last:border-b-0 last:pb-0">
              <FormLabel className="capitalize md:text-base">
                {day}
              </FormLabel>

              <div className="flex items-center space-x-2">
                <FormField
                  control={form.control}
                  name={`openingHours.${day}.isClosed`}
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={(checked) => {
                            handleClosedToggle(day, checked);
                          }}
                        />
                      </FormControl>
                      <Label>Closed</Label>
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name={`openingHours.${day}.opening`}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm md:sr-only">Opening</FormLabel>
                    <FormControl>
                      <Input
                        type="time"
                        placeholder="Opening"
                        {...field}
                        disabled={form.watch(`openingHours.${day}.isClosed`)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name={`openingHours.${day}.closing`}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm md:sr-only">Closing</FormLabel>
                    <FormControl>
                      <Input
                        type="time"
                        placeholder="Closing"
                        {...field}
                        disabled={form.watch(`openingHours.${day}.isClosed`)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default OpeningHoursSection;
