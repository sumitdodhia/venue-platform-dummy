
import React from "react";
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { UseFormReturn } from "react-hook-form";
import FacilityInput from "../FacilityInput";

interface BasicDetailsSectionProps {
  form: UseFormReturn<any>;
  facilities: string[];
  onChange: (facilities: string[]) => void;
}

const BasicDetailsSection: React.FC<BasicDetailsSectionProps> = ({
  form,
  facilities,
  onChange,
}) => {
  return (
    <div className="space-y-6">
      <FormField
        control={form.control}
        name="name"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Restaurant Name</FormLabel>
            <FormControl>
              <Input placeholder="Restaurant Name" {...field} />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={form.control}
        name="description"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Description</FormLabel>
            <FormControl>
              <Textarea
                placeholder="Describe your restaurant..."
                className="h-32"
                {...field}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <FormField
          control={form.control}
          name="cuisineType"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Cuisine Type</FormLabel>
              <Select
                onValueChange={field.onChange}
                value={field.value}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select cuisine" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="italian">Italian</SelectItem>
                  <SelectItem value="asian">Asian</SelectItem>
                  <SelectItem value="mediterranean">
                    Mediterranean
                  </SelectItem>
                  <SelectItem value="indian">Indian</SelectItem>
                  <SelectItem value="american">American</SelectItem>
                  <SelectItem value="mexican">Mexican</SelectItem>
                  <SelectItem value="french">French</SelectItem>
                  <SelectItem value="continental">Continental</SelectItem>
                  <SelectItem value="international">
                    International
                  </SelectItem>
                  <SelectItem value="fusion">Fusion</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="priceRange"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Price Range</FormLabel>
              <Select
                onValueChange={(value) => field.onChange(parseInt(value))}
                value={field.value?.toString()}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select price range" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="1">$ (Budget)</SelectItem>
                  <SelectItem value="2">$$ (Moderate)</SelectItem>
                  <SelectItem value="3">$$$ (Expensive)</SelectItem>
                  <SelectItem value="4">$$$$ (Fine Dining)</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="capacity"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Total Capacity</FormLabel>
              <FormControl>
                <Input
                  type="number"
                  min="1"
                  {...field}
                  onChange={(e) =>
                    field.onChange(parseInt(e.target.value))
                  }
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="minimumNotice"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Minimum Notice (hours)</FormLabel>
              <FormControl>
                <Input
                  type="number"
                  min="0"
                  {...field}
                  onChange={(e) =>
                    field.onChange(parseInt(e.target.value))
                  }
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <FormField
          control={form.control}
          name="rating"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Google Rating</FormLabel>
              <FormControl>
                <Input
                  type="number"
                  min="0"
                  max="5"
                  step="0.1"
                  placeholder="4.5"
                  {...field}
                  onChange={(e) =>
                    field.onChange(e.target.value ? parseFloat(e.target.value) : undefined)
                  }
                />
              </FormControl>
              <FormDescription className="text-xs">
                Rating from 0 to 5
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="ratingCount"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Number of Ratings</FormLabel>
              <FormControl>
                <Input
                  type="number"
                  min="0"
                  placeholder="125"
                  {...field}
                  onChange={(e) =>
                    field.onChange(e.target.value ? parseInt(e.target.value) : undefined)
                  }
                />
              </FormControl>
              <FormDescription className="text-xs">
                Total count of Google reviews
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>

      <div className="space-y-2">
        <FormLabel>Facilities & Amenities</FormLabel>
        <FacilityInput
          facilities={facilities}
          onChange={onChange}
          suggestedFacilities={[
            "Wi-Fi",
            "Outdoor Seating",
            "Private Dining",
            "Bar",
            "Wheelchair Access",
            "Parking",
            "Live Music",
            "Kids Area",
            "Vegan Options",
            "Gluten-Free Options",
            "Wine List",
            "Cocktail Menu",
          ]}
        />
      </div>
    </div>
  );
};

export default BasicDetailsSection;
