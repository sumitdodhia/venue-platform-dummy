
import { z } from "zod";

// We'll change our validation pattern since we're now using proper time inputs
const openingHourSchema = z.object({
  opening: z.string().min(1, "Opening time is required"),
  closing: z.string().min(1, "Closing time is required"),
  isClosed: z.boolean().default(false),
});

export const restaurantSchema = z.object({
  name: z.string().min(1, "Restaurant name is required"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  cuisineType: z.string().min(1, "Cuisine type is required"),
  priceRange: z.number().int().min(1).max(4),
  capacity: z.number().min(1, "Capacity must be at least 1"),
  minimumNotice: z.number().min(0, "Minimum notice cannot be negative"),
  rating: z.number().min(0).max(5).optional(),
  ratingCount: z.number().min(0).optional(),
  location: z.object({
    city: z.string().min(1, "City is required"),
    country: z.string().min(1, "Country is required"),
    googleMapUrl: z.string().optional(),
  }),
  openingHours: z.object({
    monday: openingHourSchema,
    tuesday: openingHourSchema,
    wednesday: openingHourSchema,
    thursday: openingHourSchema,
    friday: openingHourSchema,
    saturday: openingHourSchema,
    sunday: openingHourSchema,
  }),
  menuPdf: z.string().optional(),
});

export type RestaurantFormValues = z.infer<typeof restaurantSchema>;
