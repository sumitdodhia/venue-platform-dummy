
import React from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { RestaurantDetails, PartialRestaurantDetails } from "@/types/restaurantSupplier";
import RestaurantDetailsForm from "./RestaurantDetailsForm";
import DiningSectionsForm from "./DiningSectionsForm";
import DiningPackagesForm from "./DiningPackagesForm";
import RestaurantReviewSection from "./RestaurantReviewSection";

interface RestaurantSetupWorkflowProps {
  restaurant: PartialRestaurantDetails | null;
  activeTab: string;
  onTabChange: (tab: string) => void;
  onSaveDetails: (details: PartialRestaurantDetails) => void;
  onSaveSections: (sections: RestaurantDetails["sections"]) => void;
  onSavePackages: (packages: RestaurantDetails["packages"]) => void;
  onPublish: () => void;
}

const RestaurantSetupWorkflow: React.FC<RestaurantSetupWorkflowProps> = ({
  restaurant,
  activeTab,
  onTabChange,
  onSaveDetails,
  onSaveSections,
  onSavePackages,
  onPublish,
}) => {
  return (
    <Tabs value={activeTab} onValueChange={onTabChange} className="space-y-6">
      <TabsList className="grid w-full grid-cols-4">
        <TabsTrigger value="details">1. Basic Details</TabsTrigger>
        <TabsTrigger value="sections">2. Dining Sections</TabsTrigger>
        <TabsTrigger value="packages">3. Dining Packages</TabsTrigger>
        <TabsTrigger value="review">4. Review & Publish</TabsTrigger>
      </TabsList>
      
      <TabsContent value="details" className="space-y-6">
        <RestaurantDetailsForm 
          onSave={onSaveDetails} 
          initialData={restaurant || {}}
        />
      </TabsContent>
      
      <TabsContent value="sections" className="space-y-6">
        <DiningSectionsForm 
          sections={restaurant?.sections || []}
          onSaveSections={onSaveSections}
        />
        
        <div className="flex justify-between">
          <Button variant="outline" onClick={() => onTabChange("details")}>
            Back
          </Button>
          <Button onClick={() => onTabChange("packages")}>
            Skip to Packages
          </Button>
        </div>
      </TabsContent>
      
      <TabsContent value="packages" className="space-y-6">
        <DiningPackagesForm 
          packages={restaurant?.packages || []}
          onSavePackages={onSavePackages}
        />
        
        <div className="flex justify-between">
          <Button variant="outline" onClick={() => onTabChange("sections")}>
            Back
          </Button>
          <Button onClick={() => onTabChange("review")}>
            Continue to Review
          </Button>
        </div>
      </TabsContent>
      
      <TabsContent value="review" className="space-y-6">
        <RestaurantReviewSection restaurant={restaurant} />
        
        <div className="flex justify-between">
          <Button variant="outline" onClick={() => onTabChange("packages")}>
            Back
          </Button>
          <Button onClick={onPublish}>
            Publish Restaurant
          </Button>
        </div>
      </TabsContent>
    </Tabs>
  );
};

export default RestaurantSetupWorkflow;
