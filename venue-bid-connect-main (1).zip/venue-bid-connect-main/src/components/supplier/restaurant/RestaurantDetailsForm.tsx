
import React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form } from "@/components/ui/form";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PartialRestaurantDetails } from "@/types/restaurantSupplier";
import LocationInputs from "./LocationInputs";
import ImageUploader from "./ImageUploader";
import MenuUploader from "./MenuUploader";
import BasicDetailsSection from "./form-sections/BasicDetailsSection";
import OpeningHoursSection from "./form-sections/OpeningHoursSection";
import { restaurantSchema, RestaurantFormValues } from "./form-utils/RestaurantFormSchema";

interface RestaurantDetailsFormProps {
  onSave: (data: PartialRestaurantDetails) => void;
  initialData?: PartialRestaurantDetails;
}

const RestaurantDetailsForm: React.FC<RestaurantDetailsFormProps> = ({
  onSave,
  initialData = {},
}) => {
  const [facilities, setFacilities] = React.useState<string[]>(
    initialData?.facilities || []
  );
  const [photos, setPhotos] = React.useState<string[]>(initialData?.photos || []);
  const [menuPdf, setMenuPdf] = React.useState<string | undefined>(
    initialData?.menuPdf
  );

  // Initialize default opening hours with the new format
  const getDefaultOpeningHours = () => {
    const openingHoursData = initialData?.openingHours || {};
    const days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"];
    
    const defaultOpeningHours: { [key: string]: { opening: string; closing: string; isClosed: boolean } } = {};
    
    days.forEach(day => {
      const existingValue = openingHoursData[day as keyof typeof openingHoursData];
      
      if (existingValue === "Closed") {
        defaultOpeningHours[day] = { opening: "", closing: "", isClosed: true };
      } else if (existingValue) {
        const [opening, closing] = existingValue.split("-");
        defaultOpeningHours[day] = { 
          opening: opening || "09:00", 
          closing: closing || "22:00", 
          isClosed: false 
        };
      } else {
        // Set default hours for each day
        const isWeekend = day === "saturday" || day === "sunday";
        defaultOpeningHours[day] = { 
          opening: "09:00", 
          closing: isWeekend ? "23:00" : "22:00", 
          isClosed: false 
        };
      }
    });
    
    return defaultOpeningHours;
  };

  // Convert initialData to form format with the updated structure
  const defaultValues: Partial<RestaurantFormValues> = {
    name: initialData?.name || "",
    description: initialData?.description || "",
    cuisineType: initialData?.cuisineType || "",
    priceRange: initialData?.priceRange || 2,
    capacity: initialData?.capacity || 50,
    minimumNotice: initialData?.minimumNotice || 2,
    rating: initialData?.rating,
    ratingCount: initialData?.ratingCount,
    location: {
      city: initialData?.location?.city || "",
      country: initialData?.location?.country || "",
      googleMapUrl: initialData?.location?.googleMapUrl || "",
    },
    openingHours: getDefaultOpeningHours(),
    menuPdf: initialData?.menuPdf,
  };

  const form = useForm<RestaurantFormValues>({
    resolver: zodResolver(restaurantSchema),
    defaultValues,
  });

  const handleSubmit = (values: RestaurantFormValues) => {
    // Transform the opening hours back to the format expected by the API if needed
    const formattedOpeningHours: { [key: string]: string } = {};
    
    Object.entries(values.openingHours).forEach(([day, hours]) => {
      if (hours.isClosed) {
        formattedOpeningHours[day] = "Closed";
      } else {
        formattedOpeningHours[day] = `${hours.opening}-${hours.closing}`;
      }
    });

    onSave({
      ...values,
      facilities,
      photos,
      menuPdf,
      id: initialData?.id || `restaurant-${Date.now()}`,
      priceRange: values.priceRange as 1 | 2 | 3 | 4,
      openingHours: formattedOpeningHours,
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
        <Card>
          <CardContent className="pt-6">
            <BasicDetailsSection 
              form={form} 
              facilities={facilities} 
              onChange={setFacilities} 
            />
          </CardContent>
        </Card>

        <LocationInputs
          form={form}
          fieldName="location"
          title="Restaurant Location"
        />

        <OpeningHoursSection form={form} />

        <ImageUploader
          photos={photos}
          setPhotos={setPhotos}
          title="Restaurant Photos"
          description="Upload photos of your restaurant. First image will be used as the main image."
          maxPhotos={10}
        />

        <MenuUploader 
          menuPdf={menuPdf}
          setMenuPdf={setMenuPdf}
          title="Restaurant Menu"
          description="Upload your restaurant menu as a PDF file for customers to view."
        />

        <div className="flex justify-end">
          <Button type="submit" size="lg">
            Save & Continue
          </Button>
        </div>
      </form>
    </Form>
  );
};

export default RestaurantDetailsForm;
