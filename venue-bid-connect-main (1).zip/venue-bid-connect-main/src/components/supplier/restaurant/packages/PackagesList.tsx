
import React from "react";
import { CardContent } from "@/components/ui/card";
import DiningPackageCard from "./DiningPackageCard";
import { DiningPackage } from "@/types/restaurantSupplier";

interface PackagesListProps {
  packages: DiningPackage[];
  onEdit: (index: number) => void;
  onRemove: (index: number) => void;
}

const PackagesList = ({ packages, onEdit, onRemove }: PackagesListProps) => {
  if (packages.length === 0) {
    return (
      <CardContent>
        <div className="text-center py-6 text-muted-foreground">
          No dining packages added yet. Add your first package above.
        </div>
      </CardContent>
    );
  }
  
  return (
    <CardContent>
      <div className="space-y-4">
        {packages.map((pkg, idx) => (
          <DiningPackageCard
            key={pkg.id}
            pkg={pkg}
            index={idx}
            onEdit={onEdit}
            onRemove={onRemove}
          />
        ))}
      </div>
    </CardContent>
  );
};

export default PackagesList;
