
import React, { useState } from "react";
import { CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { DiningPackage } from "@/types/restaurantSupplier";

interface DiningPackageFormProps {
  diningPackage: Partial<DiningPackage>;
  onDiningPackageChange: (package_: Partial<DiningPackage>) => void;
  includesText: string;
  onIncludesTextChange: (text: string) => void;
  onAddIncludesItem: () => void;
  onRemoveIncludesItem: (index: number) => void;
}

const DiningPackageForm = ({
  diningPackage,
  onDiningPackageChange,
  includesText,
  onIncludesTextChange,
  onAddIncludesItem,
  onRemoveIncludesItem
}: DiningPackageFormProps) => {
  const handleChange = (field: string, value: any) => {
    onDiningPackageChange({ ...diningPackage, [field]: value });
  };
  
  return (
    <CardContent className="space-y-4">
      <div>
        <Label htmlFor="packageName">Package Name</Label>
        <Input
          id="packageName"
          value={diningPackage.name || ""}
          onChange={(e) => handleChange('name', e.target.value)}
          placeholder="e.g. Business Lunch, Date Night Special"
        />
      </div>
      
      <div>
        <Label htmlFor="packageDescription">Description</Label>
        <Textarea
          id="packageDescription"
          value={diningPackage.description || ""}
          onChange={(e) => handleChange('description', e.target.value)}
          placeholder="Describe what's included in this package..."
          className="min-h-24"
        />
      </div>
      
      <div>
        <Label htmlFor="pricePerPerson">Price Per Person ($)</Label>
        <Input
          id="pricePerPerson"
          type="number"
          min="0"
          step="0.01"
          value={diningPackage.pricePerPerson || ""}
          onChange={(e) => handleChange('pricePerPerson', parseFloat(e.target.value) || 0)}
          placeholder="Price per person"
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="minGuests">Minimum Guests</Label>
          <Input
            id="minGuests"
            type="number"
            min="1"
            value={diningPackage.minGuests || ""}
            onChange={(e) => handleChange('minGuests', parseInt(e.target.value) || undefined)}
            placeholder="Optional"
          />
        </div>
        
        <div>
          <Label htmlFor="maxGuests">Maximum Guests</Label>
          <Input
            id="maxGuests"
            type="number"
            min="1"
            value={diningPackage.maxGuests || ""}
            onChange={(e) => handleChange('maxGuests', parseInt(e.target.value) || undefined)}
            placeholder="Optional"
          />
        </div>
      </div>
      
      <div>
        <Label>Includes</Label>
        <div className="flex gap-2 mb-2">
          <Input
            value={includesText}
            onChange={(e) => onIncludesTextChange(e.target.value)}
            placeholder="e.g. Appetizer, Main Course, Dessert"
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                onAddIncludesItem();
              }
            }}
          />
          <Button type="button" onClick={onAddIncludesItem}>Add</Button>
        </div>
        
        {(diningPackage.includes || []).length > 0 && (
          <div className="mt-2 flex flex-wrap gap-2">
            {diningPackage.includes?.map((item, idx) => (
              <div key={idx} className="bg-primary/10 rounded-md px-2 py-1 flex items-center gap-1">
                <span className="text-sm">{item}</span>
                <button
                  type="button"
                  onClick={() => onRemoveIncludesItem(idx)}
                  className="text-xs text-destructive hover:text-destructive/80 ml-1"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </CardContent>
  );
};

export default DiningPackageForm;
