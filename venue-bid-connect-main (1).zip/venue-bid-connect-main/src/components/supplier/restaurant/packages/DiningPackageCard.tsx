
import React from "react";
import { Button } from "@/components/ui/button";
import { DiningPackage } from "@/types/restaurantSupplier";

interface DiningPackageCardProps {
  pkg: DiningPackage;
  onEdit: (index: number) => void;
  onRemove: (index: number) => void;
  index: number;
}

const DiningPackageCard = ({ pkg, onEdit, onRemove, index }: DiningPackageCardProps) => {
  return (
    <div className="p-4 border rounded-md">
      <div className="flex justify-between items-start">
        <div>
          <h4 className="font-medium">{pkg.name}</h4>
          <p className="text-sm text-muted-foreground line-clamp-2">{pkg.description}</p>
          <div className="mt-2 flex flex-wrap gap-2">
            <span className="text-xs bg-primary/10 rounded px-2 py-1">
              ${pkg.pricePerPerson} per person
            </span>
            {pkg.minGuests && (
              <span className="text-xs bg-primary/10 rounded px-2 py-1">
                Min: {pkg.minGuests} guests
              </span>
            )}
            {pkg.maxGuests && (
              <span className="text-xs bg-primary/10 rounded px-2 py-1">
                Max: {pkg.maxGuests} guests
              </span>
            )}
          </div>
          {pkg.includes && pkg.includes.length > 0 && (
            <div className="mt-2">
              <p className="text-xs font-medium">Includes:</p>
              <p className="text-xs text-muted-foreground">
                {pkg.includes.join(", ")}
              </p>
            </div>
          )}
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" size="sm" onClick={() => onEdit(index)}>Edit</Button>
          <Button variant="destructive" size="sm" onClick={() => onRemove(index)}>Remove</Button>
        </div>
      </div>
    </div>
  );
};

export default DiningPackageCard;
