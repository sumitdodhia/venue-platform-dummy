
import React from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DiningSection } from "@/types/restaurantSupplier";
import useDiningSections from "@/hooks/useDiningSections";
import SectionForm from "./sections/SectionForm";
import SectionsList from "./sections/SectionsList";

interface DiningSectionsFormProps {
  sections: DiningSection[];
  onSaveSections: (sections: DiningSection[]) => void;
}

const DiningSectionsForm = ({ sections = [], onSaveSections }: DiningSectionsFormProps) => {
  const {
    diningSection,
    setDiningSection,
    photoUrls,
    fileInputRef,
    editIndex,
    sections: activeSections,
    handleFileChange,
    handleRemovePhoto,
    handleAddPhotos,
    handleAddSection,
    handleEditSection,
    handleRemoveSection,
    resetForm
  } = useDiningSections(sections);

  const handleSave = () => {
    onSaveSections(activeSections);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>{editIndex !== null ? 'Edit Dining Section' : 'Add Dining Section'}</CardTitle>
        </CardHeader>
        <SectionForm
          diningSection={diningSection}
          onDiningSectionChange={setDiningSection}
          photoUrls={photoUrls}
          fileInputRef={fileInputRef}
          onPhotoAdd={handleAddPhotos}
          onPhotoRemove={handleRemovePhoto}
          onFileChange={handleFileChange}
        />
        <CardFooter className="flex justify-between">
          <Button variant="ghost" onClick={resetForm}>Cancel</Button>
          <Button onClick={handleAddSection}>
            {editIndex !== null ? 'Update Section' : 'Add Section'}
          </Button>
        </CardFooter>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Dining Sections ({activeSections.length})</CardTitle>
        </CardHeader>
        
        <SectionsList 
          sections={activeSections} 
          onEdit={handleEditSection} 
          onRemove={handleRemoveSection} 
        />
        
        <CardFooter>
          <Button className="w-full" onClick={handleSave}>
            Save Sections
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default DiningSectionsForm;
