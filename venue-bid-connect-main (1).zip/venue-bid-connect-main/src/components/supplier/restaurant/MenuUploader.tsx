
import React, { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Upload, X, FileText } from "lucide-react";

interface MenuUploaderProps {
  menuPdf: string | undefined;
  setMenuPdf: React.Dispatch<React.SetStateAction<string | undefined>>;
  title?: string;
  description?: string;
}

const MenuUploader: React.FC<MenuUploaderProps> = ({
  menuPdf,
  setMenuPdf,
  title = "Restaurant Menu",
  description = "Upload your restaurant menu as a PDF file.",
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check if file is PDF
    if (file.type !== "application/pdf") {
      alert("Please upload a PDF file");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        setMenuPdf(reader.result);
        setFileName(file.name);
      }
    };
    reader.readAsDataURL(file);

    // Reset the input
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleRemoveFile = () => {
    setMenuPdf(undefined);
    setFileName(null);
  };

  return (
    <Card>
      <CardContent className="pt-6">
        <h3 className="text-lg font-medium mb-2">{title}</h3>
        <p className="text-sm text-muted-foreground mb-4">{description}</p>

        {menuPdf ? (
          <div className="flex items-center justify-between p-4 border rounded-md bg-muted/50">
            <div className="flex items-center gap-2">
              <FileText className="h-8 w-8 text-primary" />
              <div>
                <p className="font-medium">{fileName || "Menu.pdf"}</p>
                <p className="text-xs text-muted-foreground">
                  Click to preview menu
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => window.open(menuPdf, "_blank")}
              >
                Preview
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleRemoveFile}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ) : (
          <Button
            type="button"
            variant="outline"
            className="w-full h-32 flex flex-col items-center justify-center border-dashed"
            onClick={() => fileInputRef.current?.click()}
          >
            <Upload className="h-8 w-8 mb-2 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">
              Click to upload PDF menu
            </span>
            <span className="text-xs text-muted-foreground mt-1">
              Maximum size: 5MB
            </span>
          </Button>
        )}

        <input
          ref={fileInputRef}
          type="file"
          accept="application/pdf"
          onChange={handleFileChange}
          className="hidden"
        />
      </CardContent>
    </Card>
  );
};

export default MenuUploader;
