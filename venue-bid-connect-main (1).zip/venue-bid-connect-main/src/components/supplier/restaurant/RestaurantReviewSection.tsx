
import React from "react";
import { PartialRestaurantDetails } from "@/types/restaurantSupplier";

interface RestaurantReviewSectionProps {
  restaurant: PartialRestaurantDetails | null;
}

const RestaurantReviewSection: React.FC<RestaurantReviewSectionProps> = ({ restaurant }) => {
  if (!restaurant) {
    return <div className="bg-muted p-6 rounded-md">No restaurant data available</div>;
  }

  return (
    <div className="bg-muted p-6 rounded-md">
      <h2 className="text-xl font-semibold mb-4">Restaurant Summary</h2>
      
      <div className="space-y-4">
        <div>
          <h3 className="font-medium">Basic Details</h3>
          <p><strong>Name:</strong> {restaurant.name}</p>
          <p><strong>Cuisine:</strong> {restaurant.cuisineType}</p>
          <p><strong>Capacity:</strong> {restaurant.capacity} guests</p>
          <p><strong>Location:</strong> {restaurant.location?.city}, {restaurant.location?.country}</p>
        </div>
        
        <div>
          <h3 className="font-medium">Dining Sections</h3>
          {restaurant.sections && restaurant.sections.length > 0 ? (
            <p>{restaurant.sections.length} sections configured</p>
          ) : (
            <p className="text-muted-foreground">No dining sections added</p>
          )}
        </div>
        
        <div>
          <h3 className="font-medium">Dining Packages</h3>
          {restaurant.packages && restaurant.packages.length > 0 ? (
            <p>{restaurant.packages.length} packages configured</p>
          ) : (
            <p className="text-muted-foreground">No dining packages added</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default RestaurantReviewSection;
