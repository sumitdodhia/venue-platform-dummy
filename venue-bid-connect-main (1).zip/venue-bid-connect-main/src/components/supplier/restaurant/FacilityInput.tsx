
import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { X, Plus } from "lucide-react";

interface FacilityInputProps {
  facilities: string[];
  onChange: React.Dispatch<React.SetStateAction<string[]>>;
  suggestedFacilities?: string[];
}

const FacilityInput: React.FC<FacilityInputProps> = ({ 
  facilities, 
  onChange,
  suggestedFacilities = []
}) => {
  const [inputValue, setInputValue] = useState("");
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      addFacility();
    }
  };

  const addFacility = () => {
    const value = inputValue.trim();
    if (value && !facilities.includes(value)) {
      onChange([...facilities, value]);
    }
    setInputValue("");
  };

  const removeFacility = (facility: string) => {
    onChange(facilities.filter(f => f !== facility));
  };

  const addSuggested = (facility: string) => {
    if (!facilities.includes(facility)) {
      onChange([...facilities, facility]);
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        {facilities.map((facility, index) => (
          <Badge key={index} variant="secondary" className="flex items-center gap-1">
            {facility}
            <button 
              type="button" 
              onClick={() => removeFacility(facility)}
              className="ml-1 rounded-full hover:bg-muted p-0.5"
            >
              <X className="h-3 w-3" />
              <span className="sr-only">Remove {facility}</span>
            </button>
          </Badge>
        ))}
      </div>
      
      <div className="flex gap-2">
        <Input
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Type facility and press enter or comma"
          className="flex-1"
        />
      </div>

      {suggestedFacilities && suggestedFacilities.length > 0 && (
        <div className="mt-3">
          <p className="text-xs font-medium mb-2">Suggested facilities:</p>
          <div className="flex flex-wrap gap-1">
            {suggestedFacilities
              .filter(s => !facilities.includes(s))
              .map((facility, index) => (
                <Badge 
                  key={index} 
                  variant="outline" 
                  className="cursor-pointer hover:bg-muted flex items-center gap-1"
                  onClick={() => addSuggested(facility)}
                >
                  <Plus className="h-3 w-3" />
                  {facility}
                </Badge>
              ))}
          </div>
        </div>
      )}
      
      <p className="text-xs text-muted-foreground">
        Type facility name and press Enter or comma to add
      </p>
    </div>
  );
};

export default FacilityInput;
