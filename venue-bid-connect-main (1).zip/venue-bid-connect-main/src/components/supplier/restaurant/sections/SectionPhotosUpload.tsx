
import React from "react";
import { Button } from "@/components/ui/button";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { Plus, X, ImageIcon } from "lucide-react";
import { Label } from "@/components/ui/label";

interface SectionPhotosUploadProps {
  photoUrls: string[];
  onAddPhotos: () => void;
  onRemovePhoto: (index: number) => void;
  fileInputRef: React.RefObject<HTMLInputElement>;
}

const SectionPhotosUpload = ({ 
  photoUrls, 
  onAddPhotos, 
  onRemovePhoto, 
  fileInputRef 
}: SectionPhotosUploadProps) => {
  return (
    <div className="space-y-2">
      <Label>Section Photos (Up to 5)</Label>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
        {photoUrls.map((url, idx) => (
          <div key={idx} className="relative group aspect-square">
            <AspectRatio ratio={1}>
              <img 
                src={url} 
                alt={`Section photo ${idx + 1}`}
                className="rounded-md object-cover w-full h-full"
              />
            </AspectRatio>
            <button
              type="button"
              onClick={() => onRemovePhoto(idx)}
              className="absolute top-1 right-1 bg-black/70 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
              aria-label="Remove image"
            >
              <X className="h-4 w-4" />
            </button>
            {idx === 0 && (
              <span className="absolute bottom-1 left-1 bg-primary text-primary-foreground text-xs px-2 py-1 rounded">
                Main Photo
              </span>
            )}
          </div>
        ))}
        
        {photoUrls.length < 5 && (
          <Button
            type="button"
            variant="outline"
            className="h-auto aspect-square flex flex-col items-center justify-center border-dashed"
            onClick={onAddPhotos}
          >
            <Plus className="h-6 w-6 mb-1" />
            <span className="text-xs">Add Photo</span>
          </Button>
        )}
        
        {photoUrls.length === 0 && (
          <div className="col-span-full text-center py-8 border border-dashed rounded-md">
            <ImageIcon className="mx-auto h-8 w-8 text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">No photos added yet</p>
          </div>
        )}
      </div>
      <p className="text-xs text-muted-foreground">
        {photoUrls.length} of 5 photos selected. First photo will be displayed as the main photo.
      </p>
    </div>
  );
};

export default SectionPhotosUpload;
