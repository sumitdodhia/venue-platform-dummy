
import React from "react";
import { CardContent } from "@/components/ui/card";
import { DiningSection } from "@/types/restaurantSupplier";
import SectionCard from "./SectionCard";

interface SectionsListProps {
  sections: DiningSection[];
  onEdit: (index: number) => void;
  onRemove: (index: number) => void;
}

const SectionsList = ({ sections, onEdit, onRemove }: SectionsListProps) => {
  if (sections.length === 0) {
    return (
      <CardContent>
        <div className="text-center py-6 text-muted-foreground">
          No dining sections added yet. Add your first section above.
        </div>
      </CardContent>
    );
  }
  
  return (
    <CardContent>
      <div className="space-y-4">
        {sections.map((section, idx) => (
          <SectionCard
            key={section.id}
            section={section}
            index={idx}
            onEdit={onEdit}
            onRemove={onRemove}
          />
        ))}
      </div>
    </CardContent>
  );
};

export default SectionsList;
