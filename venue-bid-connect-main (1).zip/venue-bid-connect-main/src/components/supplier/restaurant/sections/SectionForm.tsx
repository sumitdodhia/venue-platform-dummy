
import React from "react";
import { CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { DiningSection } from "@/types/restaurantSupplier";
import SectionPhotosUpload from "./SectionPhotosUpload";

interface SectionFormProps {
  diningSection: Partial<DiningSection>;
  onDiningSectionChange: (section: Partial<DiningSection>) => void;
  photoUrls: string[];
  fileInputRef: React.RefObject<HTMLInputElement>;
  onPhotoAdd: () => void;
  onPhotoRemove: (index: number) => void;
  onFileChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const SectionForm = ({ 
  diningSection, 
  onDiningSectionChange, 
  photoUrls,
  fileInputRef,
  onPhotoAdd,
  onPhotoRemove,
  onFileChange
}: SectionFormProps) => {
  return (
    <CardContent className="space-y-4">
      <div>
        <Label htmlFor="sectionName">Section Name</Label>
        <Input
          id="sectionName"
          value={diningSection.name || ""}
          onChange={(e) => onDiningSectionChange({ ...diningSection, name: e.target.value })}
          placeholder="Main Dining Area, Patio, etc."
        />
      </div>
      
      <div>
        <Label htmlFor="sectionDescription">Description</Label>
        <Textarea
          id="sectionDescription"
          value={diningSection.description || ""}
          onChange={(e) => onDiningSectionChange({ ...diningSection, description: e.target.value })}
          placeholder="Describe this dining section..."
          className="min-h-24"
        />
      </div>
      
      <div>
        <Label htmlFor="sectionCapacity">Capacity</Label>
        <Input
          id="sectionCapacity"
          type="number"
          min="1"
          value={diningSection.capacity || ""}
          onChange={(e) => onDiningSectionChange({ 
            ...diningSection, 
            capacity: parseInt(e.target.value) || 0 
          })}
          placeholder="How many guests can this section accommodate?"
        />
      </div>
      
      <div className="flex flex-col gap-2">
        <div className="flex items-center space-x-2">
          <Checkbox 
            id="isPrivate" 
            checked={diningSection.isPrivate || false}
            onCheckedChange={(checked) => 
              onDiningSectionChange({ ...diningSection, isPrivate: !!checked })
            }
          />
          <Label htmlFor="isPrivate">Private Dining Space</Label>
        </div>
        
        <div className="flex items-center space-x-2">
          <Checkbox 
            id="isOutdoor" 
            checked={diningSection.isOutdoor || false}
            onCheckedChange={(checked) => 
              onDiningSectionChange({ ...diningSection, isOutdoor: !!checked })
            }
          />
          <Label htmlFor="isOutdoor">Outdoor Space</Label>
        </div>
      </div>
      
      <SectionPhotosUpload
        photoUrls={photoUrls}
        onAddPhotos={onPhotoAdd}
        onRemovePhoto={onPhotoRemove}
        fileInputRef={fileInputRef}
      />
      
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={onFileChange}
        className="hidden"
      />
    </CardContent>
  );
};

export default SectionForm;
