
import React from "react";
import { Button } from "@/components/ui/button";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { Images } from "lucide-react";
import { DiningSection } from "@/types/restaurantSupplier";

interface SectionCardProps {
  section: DiningSection;
  onEdit: (index: number) => void;
  onRemove: (index: number) => void;
  index: number;
}

const SectionCard = ({ section, onEdit, onRemove, index }: SectionCardProps) => {
  // Count photos if available
  const photosCount = section.photos?.length || 0;
  const hasPhoto = section.photo || (section.photos && section.photos.length > 0);
  const displayPhoto = section.photos?.[0] || section.photo;
  
  return (
    <div className="p-4 border rounded-md hover:border-primary/50 transition-colors">
      <div className="flex flex-col md:flex-row gap-4">
        {hasPhoto && (
          <div className="md:w-1/4">
            <AspectRatio ratio={4/3}>
              <img 
                src={displayPhoto} 
                alt={section.name} 
                className="rounded-md object-cover h-full w-full"
              />
            </AspectRatio>
          </div>
        )}
        <div className={hasPhoto ? "md:w-2/3 flex-1" : "w-full"}>
          <div className="flex justify-between items-start">
            <div>
              <h4 className="font-medium">{section.name}</h4>
              <p className="text-sm text-muted-foreground line-clamp-2">{section.description}</p>
              <div className="mt-2 flex flex-wrap gap-2">
                <span className="text-xs bg-primary/10 rounded px-2 py-1">
                  Capacity: {section.capacity}
                </span>
                {section.isPrivate && (
                  <span className="text-xs bg-primary/10 rounded px-2 py-1">Private</span>
                )}
                {section.isOutdoor && (
                  <span className="text-xs bg-primary/10 rounded px-2 py-1">Outdoor</span>
                )}
                {photosCount > 0 && (
                  <span className="text-xs bg-primary/10 rounded px-2 py-1 flex items-center">
                    <Images className="h-3 w-3 mr-1" />
                    {photosCount} {photosCount === 1 ? 'photo' : 'photos'}
                  </span>
                )}
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" onClick={() => onEdit(index)}>Edit</Button>
              <Button variant="destructive" size="sm" onClick={() => onRemove(index)}>Remove</Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SectionCard;
