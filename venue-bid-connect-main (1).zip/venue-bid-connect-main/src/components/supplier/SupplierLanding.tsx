
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const SupplierLanding = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 py-16 md:py-24">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h1 className="text-4xl font-bold mb-4">
                Grow Your Venue Business with FindToTable
              </h1>
              <p className="text-lg mb-4">Your Customer. Your Revenue. Your Way.</p>
              <p className="mb-6 text-lg opacity-90">
                Join thousands of hotels, restaurants, and event venues connecting with corporate clients through our platform.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/supplier/register">
                  <Button size="lg" variant="secondary">
                    Get Started
                  </Button>
                </Link>
                <Link to="/login">
                  <Button size="lg" variant="outline" className="bg-primary/10">
                    Supplier Login
                  </Button>
                </Link>
              </div>
            </div>
            <div className="rounded-lg overflow-hidden shadow-xl">
              <img 
                src="https://images.unsplash.com/photo-1519167758481-83f550bb49b3" 
                alt="Supplier Dashboard" 
                className="w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Why Join FindToTable as a Supplier?</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Access Corporate Clients",
                description: "Connect with high-value corporate clients looking for venues just like yours.",
                icon: "🏢"
              },
              {
                title: "Control Your Availability",
                description: "Set your own availability and pricing based on your business needs.",
                icon: "📅"
              },
              {
                title: "Simplified Bidding",
                description: "Easily respond to enquiries with our streamlined bidding system.",
                icon: "📝"
              },
            ].map((item, index) => (
              <div key={index} className="border rounded-lg p-6 hover:shadow-md transition-shadow">
                <div className="text-4xl mb-4">{item.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-muted-foreground">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="bg-muted py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">How It Works For Suppliers</h2>
          
          <div className="grid md:grid-cols-4 gap-8">
            {[
              {
                step: "1",
                title: "Create Your Profile",
                description: "Set up your venue profile with photos, amenities, and services."
              },
              {
                step: "2",
                title: "List Your Space",
                description: "Add your spaces with capacity, features, and availability."
              },
              {
                step: "3",
                title: "Receive Enquiries",
                description: "Get notified of relevant booking requests from corporate clients."
              },
              {
                step: "4",
                title: "Submit Bids",
                description: "Respond with your best offer and win more business."
              }
            ].map((item, index) => (
              <div key={index} className="flex flex-col items-center text-center">
                <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xl font-bold mb-4">
                  {item.step}
                </div>
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-muted-foreground">{item.description}</p>
              </div>
            ))}
          </div>
          
          <div className="mt-12 text-center">
            <Link to="/supplier/register">
              <Button size="lg">Join as a Supplier</Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">What Suppliers Say</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                quote: "We've seen a 30% increase in corporate bookings since joining FindToTable. The platform makes it easy to connect with quality clients.",
                name: "Sarah Johnson",
                role: "Events Manager, Grand Hotel"
              },
              {
                quote: "The bidding system allows us to be competitive while still maintaining our pricing standards. It's been a game-changer for our business.",
                name: "Michael Chen",
                role: "Owner, Urban Event Space"
              },
              {
                quote: "As a restaurant with private dining rooms, FindToTable has helped us fill our space during slower periods. The ROI has been excellent.",
                name: "Lisa Rodriguez",
                role: "Director, Fine Dining Restaurant"
              }
            ].map((item, index) => (
              <div key={index} className="border rounded-lg p-6 hover:shadow-md transition-shadow">
                <p className="italic mb-4">"{item.quote}"</p>
                <div>
                  <p className="font-semibold">{item.name}</p>
                  <p className="text-sm text-muted-foreground">{item.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-primary text-primary-foreground py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Grow Your Venue Business?</h2>
          <p className="text-lg mb-2">Your Customer. Your Revenue. Your Way.</p>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Join our network of successful venue suppliers and start receiving quality enquiries from corporate clients.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/supplier/register">
              <Button size="lg" variant="secondary">
                Register Your Venue
              </Button>
            </Link>
            <Link to="/login">
              <Button size="lg" variant="outline" className="bg-primary/10">
                Request a Demo
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default SupplierLanding;
