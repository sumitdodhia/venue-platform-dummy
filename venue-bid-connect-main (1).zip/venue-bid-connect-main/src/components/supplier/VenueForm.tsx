
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

import { Form } from "@/components/ui/form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

import VenueFormHeader from "./VenueFormHeader";
import VenueFormFields, { venueFormSchema, VenueFormValues } from "./VenueFormFields";
import VenueFormActions from "./VenueFormActions";

interface VenueFormProps {
  venueType?: string;
}

const VenueForm = ({ venueType }: VenueFormProps) => {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Use useEffect for navigation instead of redirecting during render
  useEffect(() => {
    // Redirect to appropriate venue setup page based on venue type
    if (venueType === "hotel") {
      navigate("/supplier/dashboard/room-setup");
    } else if (venueType === "conference") {
      navigate("/supplier/dashboard/venues/conference-setup");
    }
  }, [venueType, navigate]);

  // If it's being redirected, return null while the navigation happens
  if (venueType === "hotel" || venueType === "conference") {
    return null;
  }

  const form = useForm<VenueFormValues>({
    resolver: zodResolver(venueFormSchema),
    defaultValues: {
      name: "",
      type: venueType || "",
      capacity: undefined,
      location: "",
      description: "",
    },
  });

  const onSubmit = async (values: VenueFormValues) => {
    setIsSubmitting(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast.success("Venue added successfully");
      navigate("/supplier/dashboard/venues");
    } catch (error) {
      toast.error("Failed to add venue. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div>
      <VenueFormHeader venueType={venueType} />

      <Card className="max-w-2xl">
        <CardHeader>
          <CardTitle>Venue Details</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <VenueFormFields form={form} />
              <VenueFormActions isSubmitting={isSubmitting} />
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
};

export default VenueForm;
