
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

interface VenueFormActionsProps {
  isSubmitting: boolean;
}

const VenueFormActions = ({ isSubmitting }: VenueFormActionsProps) => {
  const navigate = useNavigate();
  
  return (
    <div className="flex gap-3 justify-end">
      <Button
        type="button"
        variant="outline"
        onClick={() => navigate("/supplier/dashboard/venues")}
      >
        Cancel
      </Button>
      <Button type="submit" disabled={isSubmitting}>
        {isSubmitting ? "Adding Venue..." : "Add Venue"}
      </Button>
    </div>
  );
};

export default VenueFormActions;
