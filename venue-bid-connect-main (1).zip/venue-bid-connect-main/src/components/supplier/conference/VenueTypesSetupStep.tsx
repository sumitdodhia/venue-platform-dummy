
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ConferenceVenueDetails, VenueType } from "@/types/conferenceSupplier";
import VenueTypesList from "./VenueTypesList";

interface VenueTypesSetupStepProps {
  venueTypes: VenueType[];
  venueDetails: ConferenceVenueDetails;
  onAddVenue: (venue: VenueType) => void;
  onEditVenue: (venue: VenueType) => void;
  onDeleteVenue: (id: string) => void;
  onBack: () => void;
  onContinue: () => void;
}

const VenueTypesSetupStep = ({
  venueTypes,
  venueDetails,
  onAddVenue,
  onEditVenue,
  onDeleteVenue,
  onBack,
  onContinue
}: VenueTypesSetupStepProps) => {
  const isValid = venueTypes.length > 0;
  
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold">Venue Types</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Add the different spaces available at your venue
          </p>
        </div>
        <Button onClick={onBack}>
          Edit Venue Details
        </Button>
      </div>
      
      {!isValid && (
        <Alert variant="destructive">
          <AlertDescription>
            Please add at least one venue type to continue.
          </AlertDescription>
        </Alert>
      )}
      
      <VenueTypesList 
        venueTypes={venueTypes}
        onAddVenue={onAddVenue}
        onEditVenue={onEditVenue}
        onDeleteVenue={onDeleteVenue}
      />
      
      <div className="pt-6 border-t flex justify-end gap-4">
        <Button 
          variant="outline" 
          onClick={onBack}
        >
          Back
        </Button>
        <Button 
          onClick={onContinue}
          disabled={!isValid}
        >
          Save & Continue
        </Button>
      </div>
    </div>
  );
};

export default VenueTypesSetupStep;
