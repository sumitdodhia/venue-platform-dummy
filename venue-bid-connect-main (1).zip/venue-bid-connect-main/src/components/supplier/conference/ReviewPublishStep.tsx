
import { Button } from "@/components/ui/button";
import { ConferenceVenueDetails, VenueType } from "@/types/conferenceSupplier";
import { Check } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface ReviewPublishStepProps {
  venueDetails: ConferenceVenueDetails;
  venueTypes: VenueType[];
  onBack: () => void;
  onPublish: () => void;
  isPublishing: boolean;
}

const ReviewPublishStep = ({
  venueDetails,
  venueTypes,
  onBack,
  onPublish,
  isPublishing
}: ReviewPublishStepProps) => {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold">Review & Publish</h2>
      
      <div className="bg-muted/40 p-6 rounded-lg">
        <h3 className="font-semibold text-lg mb-2">Venue Details</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Name</p>
            <p className="font-medium">{venueDetails.name}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Location</p>
            <p className="font-medium">{venueDetails.area}, {venueDetails.country}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Total Capacity</p>
            <p className="font-medium">{venueDetails.totalCapacity}</p>
          </div>
        </div>
        
        {venueDetails.facilities && venueDetails.facilities.length > 0 && (
          <>
            <h3 className="font-semibold text-lg mt-6 mb-2">Facilities & Services</h3>
            <div className="flex flex-wrap gap-2 mb-4">
              {venueDetails.facilities.map((facility, index) => (
                <Badge key={index} variant="secondary">{facility}</Badge>
              ))}
            </div>
          </>
        )}
        
        <h3 className="font-semibold text-lg mt-6 mb-2">Venue Types</h3>
        <div className="space-y-3">
          {venueTypes.map(venue => (
            <div key={venue.id} className="bg-background p-4 rounded-md">
              <div className="flex justify-between items-center">
                <h4 className="font-medium">{venue.name}</h4>
                <p className="font-semibold">${venue.priceFrom}/day</p>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                {venue.type} - Max Capacity: {venue.maxCapacity}
              </p>
            </div>
          ))}
        </div>
        
        <h3 className="font-semibold text-lg mt-6 mb-2">Chargeable Amenities</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {venueDetails.facilitiesOffered.map((facility, index) => (
            <div key={index} className="bg-background p-2 rounded-md">
              <p className="font-medium">{facility.name}</p>
              {facility.isCharged ? (
                <p className="text-sm text-amber-600">
                  {facility.rate && `$${facility.rate}`} {facility.chargeType}
                </p>
              ) : (
                <p className="text-sm text-emerald-600">Included</p>
              )}
            </div>
          ))}
        </div>
      </div>
      
      <p className="text-muted-foreground">
        Your venue has been set up successfully with {venueTypes.length} space {venueTypes.length === 1 ? 'type' : 'types'}.
        Click "Publish Venue" to make it live on the marketplace.
      </p>
      
      <div className="pt-6 flex justify-end gap-4">
        <Button variant="outline" onClick={onBack}>
          Back to Venue Types
        </Button>
        <Button 
          onClick={onPublish} 
          disabled={isPublishing}
          className="gap-2"
        >
          {isPublishing ? "Publishing..." : "Publish Venue"}
          {isPublishing && <Check className="h-4 w-4 animate-pulse" />}
        </Button>
      </div>
    </div>
  );
};

export default ReviewPublishStep;
