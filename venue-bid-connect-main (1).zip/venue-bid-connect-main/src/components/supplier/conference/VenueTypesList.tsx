
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { VenueType } from "@/types/conferenceSupplier";
import VenueTypeForm from "./VenueTypeForm";
import { Plus } from "lucide-react";

interface VenueTypesListProps {
  venueTypes: VenueType[];
  onAddVenue: (venue: VenueType) => void;
  onEditVenue: (venue: VenueType) => void;
  onDeleteVenue: (id: string) => void;
}

const VenueTypesList = ({ 
  venueTypes, 
  onAddVenue, 
  onEditVenue, 
  onDeleteVenue
}: VenueTypesListProps) => {
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const handleAddClick = () => {
    setIsAdding(true);
    setEditingId(null);
  };

  const handleEditClick = (id: string) => {
    setEditingId(id);
    setIsAdding(false);
  };

  const handleCancelAdd = () => {
    setIsAdding(false);
  };

  const handleCancelEdit = () => {
    setEditingId(null);
  };

  const handleAddSubmit = (venue: VenueType) => {
    onAddVenue(venue);
    setIsAdding(false);
  };

  const handleEditSubmit = (venue: VenueType) => {
    onEditVenue(venue);
    setEditingId(null);
  };

  return (
    <div className="space-y-6">
      {venueTypes.map((venue) => (
        <div key={venue.id}>
          {editingId === venue.id ? (
            <VenueTypeForm
              initialValues={venue}
              onSubmit={handleEditSubmit}
              onCancel={handleCancelEdit}
              isEditing
            />
          ) : (
            <Card>
              <CardHeader className="flex flex-row items-start justify-between space-y-0">
                <div>
                  <CardTitle className="text-xl">{venue.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">
                    {venue.type} · Max Capacity: {venue.maxCapacity}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-bold">${venue.priceFrom}</p>
                  <p className="text-sm text-muted-foreground">starting from</p>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm line-clamp-2">{venue.description}</p>
                
                {venue.photos.length > 0 && (
                  <div className="mt-4 flex overflow-x-auto gap-2 pb-2">
                    {venue.photos.map((photo, index) => (
                      <img 
                        key={index}
                        src={photo} 
                        alt={`${venue.name} - Photo ${index + 1}`} 
                        className="h-20 w-28 rounded object-cover flex-shrink-0"
                      />
                    ))}
                  </div>
                )}
              </CardContent>
              <CardFooter className="flex justify-end gap-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => onDeleteVenue(venue.id)}
                >
                  Delete
                </Button>
                <Button 
                  variant="default" 
                  size="sm"
                  onClick={() => handleEditClick(venue.id)}
                >
                  Edit
                </Button>
              </CardFooter>
            </Card>
          )}
        </div>
      ))}

      {isAdding ? (
        <VenueTypeForm
          onSubmit={handleAddSubmit}
          onCancel={handleCancelAdd}
        />
      ) : (
        <Button 
          onClick={handleAddClick}
          className="w-full py-8"
          variant="outline"
        >
          <Plus className="mr-2 h-5 w-5" />
          Add Venue Type
        </Button>
      )}
    </div>
  );
};

export default VenueTypesList;
