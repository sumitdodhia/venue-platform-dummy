
import { useState } from "react";
import { v4 as uuidv4 } from 'uuid';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { VenueType } from "@/types/conferenceSupplier";
import ImageUploader from "../rooms/ImageUploader";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface VenueTypeFormProps {
  initialValues?: VenueType;
  onSubmit: (venue: VenueType) => void;
  onCancel: () => void;
  isEditing?: boolean;
}

const defaultValues: VenueType = {
  id: '',
  name: '',
  type: '',
  description: '',
  photos: [],
  maxCapacity: 50,
  priceFrom: 0
};

// List of available venue types for conferences
const venueTypeOptions = [
  "Boardroom",
  "Theater Style",
  "U-Shape",
  "Classroom",
  "Banquet",
  "Reception",
  "Hollow Square",
  "Conference Room",
  "Auditorium",
  "Breakout Room",
  "Exhibition Space",
  "Meeting Room",
  "Training Room",
  "Workshop Space",
  "Seminar Room",
  "Lecture Hall",
  "Ballroom",
  "Convention Center",
  "Flexible Space",
  "Other"
];

const VenueTypeForm = ({ 
  initialValues = defaultValues,
  onSubmit, 
  onCancel,
  isEditing = false
}: VenueTypeFormProps) => {
  const [form, setForm] = useState<VenueType>({
    id: initialValues.id || uuidv4(),
    name: initialValues.name,
    type: initialValues.type,
    description: initialValues.description,
    photos: initialValues.photos,
    maxCapacity: initialValues.maxCapacity,
    priceFrom: initialValues.priceFrom
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({
      ...prev,
      [name]: value ? Number(value) : 0
    }));
  };

  const handlePhotosChange = (photos: string[]) => {
    setForm(prev => ({
      ...prev,
      photos
    }));
  };

  const handleTypeChange = (value: string) => {
    setForm(prev => ({
      ...prev,
      type: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(form);
  };

  return (
    <Card className="p-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        <h3 className="text-lg font-semibold">
          {isEditing ? "Edit Venue Type" : "Add New Venue Type"}
        </h3>

        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Venue Name *</Label>
              <Input
                id="name"
                name="name"
                value={form.name}
                onChange={handleInputChange}
                placeholder="e.g., Executive Boardroom"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="type">Type of Venue *</Label>
              <Select
                value={form.type}
                onValueChange={handleTypeChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select venue type" />
                </SelectTrigger>
                <SelectContent>
                  {venueTypeOptions.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              name="description"
              value={form.description}
              onChange={handleInputChange}
              rows={3}
              placeholder="Describe this venue type"
            />
          </div>

          <div className="space-y-2">
            <Label>Venue Photos (up to 5)</Label>
            <ImageUploader
              images={form.photos}
              onChange={handlePhotosChange}
              maxImages={5}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="maxCapacity">Maximum Capacity *</Label>
              <Input
                id="maxCapacity"
                name="maxCapacity"
                type="number"
                min="1"
                value={form.maxCapacity || ''}
                onChange={handleNumberChange}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="priceFrom">Price Starting From (USD) *</Label>
              <Input
                id="priceFrom"
                name="priceFrom"
                type="number"
                min="0"
                step="0.01"
                value={form.priceFrom || ''}
                onChange={handleNumberChange}
                required
              />
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button type="submit">
            {isEditing ? "Update Venue" : "Add Venue"}
          </Button>
        </div>
      </form>
    </Card>
  );
};

export default VenueTypeForm;
