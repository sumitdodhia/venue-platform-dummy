
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { ConferenceVenueDetails } from "@/types/conferenceSupplier";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import FacilitiesInput from "./FacilitiesInput";
import LocationInputs from "../rooms/LocationInputs";
import ImageUploader from "../rooms/ImageUploader";
import FacilityInput from "../rooms/FacilityInput";

interface VenueDetailsFormProps {
  initialValues: ConferenceVenueDetails;
  onSubmit: (values: ConferenceVenueDetails) => void;
}

const VenueDetailsForm = ({ initialValues, onSubmit }: VenueDetailsFormProps) => {
  const [formValues, setFormValues] = useState<ConferenceVenueDetails>(initialValues);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormValues(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleNumberInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormValues(prev => ({
      ...prev,
      [name]: value ? Number(value) : 0
    }));
  };

  const handleCountryChange = (value: string) => {
    setFormValues(prev => ({
      ...prev,
      country: value
    }));
  };

  const handleFacilitiesChange = (facilitiesOffered: any[]) => {
    setFormValues(prev => ({
      ...prev,
      facilitiesOffered
    }));
  };

  const handleGeneralFacilitiesChange = (facilities: string[]) => {
    setFormValues(prev => ({
      ...prev,
      facilities
    }));
  };

  const handlePhotosChange = (photos: string[]) => {
    setFormValues(prev => ({
      ...prev,
      photos
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formValues);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="space-y-6">
        <div className="grid gap-6">
          <div className="space-y-2">
            <Label htmlFor="name">Property Name *</Label>
            <Input
              id="name"
              name="name"
              value={formValues.name}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Property Photos (up to 5)</Label>
            <ImageUploader
              images={formValues.photos}
              onChange={handlePhotosChange}
              maxImages={5}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="totalCapacity">Total Capacity</Label>
              <Input
                id="totalCapacity"
                name="totalCapacity"
                type="number"
                min="0"
                value={formValues.totalCapacity || ""}
                onChange={handleNumberInput}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="googleLocation">Google Maps URL</Label>
              <Input
                id="googleLocation"
                name="googleLocation"
                value={formValues.googleLocation}
                onChange={handleInputChange}
                placeholder="Paste Google Maps URL"
              />
            </div>
          </div>

          <LocationInputs 
            area={formValues.area}
            country={formValues.country}
            onInputChange={handleInputChange}
            onCountryChange={handleCountryChange}
          />

          <div className="space-y-2">
            <Label htmlFor="about">About the Property (max 500 characters)</Label>
            <Textarea
              id="about"
              name="about"
              value={formValues.about}
              onChange={handleInputChange}
              maxLength={500}
              rows={4}
              placeholder="Brief description of your property"
            />
            <p className="text-xs text-muted-foreground">
              {formValues.about.length}/500 characters
            </p>
          </div>

          <div className="space-y-2">
            <Label>Facilities & Services</Label>
            <FacilityInput
              facilities={formValues.facilities || []}
              onChange={handleGeneralFacilitiesChange}
            />
            <p className="text-xs text-muted-foreground">
              Add general facilities available on the property (WiFi, Parking, etc.)
            </p>
          </div>

          <div className="space-y-2">
            <Label>Chargeable Amenities</Label>
            <FacilitiesInput
              facilities={formValues.facilitiesOffered}
              onChange={handleFacilitiesChange}
            />
            <p className="text-xs text-muted-foreground">
              Add amenities that may have additional charges or are included in packages
            </p>
          </div>
        </div>
      </div>

      <div className="pt-6 border-t flex justify-end">
        <Button type="submit">
          Continue to Venue Type Setup
        </Button>
      </div>
    </form>
  );
};

export default VenueDetailsForm;
