
import VenueDetailsForm from "./VenueDetailsForm";
import { ConferenceVenueDetails } from "@/types/conferenceSupplier";

interface VenueSetupStepProps {
  venueDetails: ConferenceVenueDetails;
  onSave: (details: ConferenceVenueDetails) => void;
}

const VenueSetupStep = ({ venueDetails, onSave }: VenueSetupStepProps) => {
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-6">Property Details</h2>
      <p className="text-muted-foreground mb-6">
        First, let's set up your property information. In the next step, you'll add specific venue types within this property.
      </p>
      <VenueDetailsForm 
        initialValues={venueDetails} 
        onSubmit={onSave} 
      />
    </div>
  );
};

export default VenueSetupStep;
