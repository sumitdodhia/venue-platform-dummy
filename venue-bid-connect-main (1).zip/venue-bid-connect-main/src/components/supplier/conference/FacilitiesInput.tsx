
import { useState } from "react";
import { X, Plus, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FacilityItem } from "@/types/conferenceSupplier";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";

interface FacilitiesInputProps {
  facilities: FacilityItem[];
  onChange: (facilities: FacilityItem[]) => void;
}

const chargeTypes = [
  { value: "Inclusive", label: "Inclusive" },
  { value: "Per Person", label: "Per Person" },
  { value: "Per Event", label: "Per Event" },
  { value: "Subject to Enquiry", label: "Subject to Enquiry" },
];

const FacilitiesInput = ({ facilities, onChange }: FacilitiesInputProps) => {
  const [newFacility, setNewFacility] = useState("");

  const handleAddFacility = () => {
    if (newFacility.trim() === "") return;
    
    onChange([
      ...facilities,
      { 
        name: newFacility.trim(), 
        isCharged: false,
        chargeType: "Inclusive" // Default charge type
      }
    ]);
    setNewFacility("");
  };

  const handleRemoveFacility = (index: number) => {
    const newFacilities = [...facilities];
    newFacilities.splice(index, 1);
    onChange(newFacilities);
  };

  const handleChargeTypeChange = (index: number, type: "Inclusive" | "Per Person" | "Per Event" | "Subject to Enquiry") => {
    const newFacilities = [...facilities];
    const isChargeable = type !== "Inclusive";
    
    newFacilities[index] = {
      ...newFacilities[index],
      chargeType: type,
      isCharged: isChargeable,
      // Reset rate if switching to non-chargeable type
      ...(isChargeable ? {} : { rate: undefined })
    };
    onChange(newFacilities);
  };

  const handleRateChange = (index: number, rate: number) => {
    const newFacilities = [...facilities];
    newFacilities[index] = {
      ...newFacilities[index],
      rate
    };
    onChange(newFacilities);
  };

  const isRateEditable = (chargeType?: string): boolean => {
    return chargeType !== "Inclusive" && chargeType !== undefined;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-end gap-2">
        <div className="flex-1">
          <Input
            value={newFacility}
            onChange={(e) => setNewFacility(e.target.value)}
            placeholder="Add an amenity (e.g., WiFi, Projector, Catering)"
            className="w-full"
          />
        </div>
        <Button 
          type="button" 
          variant="outline" 
          size="sm" 
          onClick={handleAddFacility}
          disabled={!newFacility.trim()}
        >
          <Plus className="h-4 w-4 mr-1" /> Add
        </Button>
      </div>

      {facilities.length > 0 ? (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Amenity</TableHead>
              <TableHead>Pricing Type</TableHead>
              <TableHead>Rate (USD)</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {facilities.map((facility, index) => (
              <TableRow key={index}>
                <TableCell className="font-medium">{facility.name}</TableCell>
                <TableCell>
                  <Select
                    value={facility.chargeType || "Inclusive"}
                    onValueChange={(val) => handleChargeTypeChange(index, val as "Inclusive" | "Per Person" | "Per Event" | "Subject to Enquiry")}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select pricing type" />
                    </SelectTrigger>
                    <SelectContent>
                      {chargeTypes.map(type => (
                        <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </TableCell>
                <TableCell>
                  <div className="relative">
                    <Input
                      type="number"
                      min="0"
                      step="0.01"
                      placeholder="0.00"
                      value={facility.rate || ""}
                      onChange={(e) => handleRateChange(index, parseFloat(e.target.value))}
                      disabled={!isRateEditable(facility.chargeType)}
                      className="pl-8 w-full"
                    />
                    <span className="absolute left-2 top-1/2 transform -translate-y-1/2 text-muted-foreground">
                      <DollarSign className="h-4 w-4" />
                    </span>
                  </div>
                </TableCell>
                <TableCell>
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="sm"
                    className="h-8 w-8 p-0" 
                    onClick={() => handleRemoveFacility(index)}
                  >
                    <X className="h-4 w-4" />
                    <span className="sr-only">Remove</span>
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      ) : (
        <div className="text-center p-4 border border-dashed rounded-md text-muted-foreground">
          No amenities added yet. Use the input above to add amenities.
        </div>
      )}
    </div>
  );
};

export default FacilitiesInput;
