
import { useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { X, Upload, Image } from "lucide-react";

interface ImageUploaderProps {
  images: string[];
  onChange: (images: string[]) => void;
  maxImages: number;
}

const ImageUploader = ({ images, onChange, maxImages }: ImageUploaderProps) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  // In a real implementation, this would upload the file to a server
  // For now, we'll just create a data URL for demo purposes
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || images.length >= maxImages) return;

    const newImages = [...images];
    
    Array.from(files).forEach(file => {
      if (newImages.length < maxImages) {
        const reader = new FileReader();
        reader.onload = () => {
          if (typeof reader.result === 'string') {
            newImages.push(reader.result);
            onChange([...newImages]);
          }
        };
        reader.readAsDataURL(file);
      }
    });
    
    // Reset the input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleRemoveImage = (index: number) => {
    const newImages = [...images];
    newImages.splice(index, 1);
    onChange(newImages);
  };

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
        {images.map((image, index) => (
          <Card key={index} className="relative overflow-hidden group aspect-square">
            <img 
              src={image} 
              alt={`Uploaded image ${index + 1}`} 
              className="w-full h-full object-cover"
            />
            <button
              type="button"
              onClick={() => handleRemoveImage(index)}
              className="absolute top-1 right-1 bg-black/70 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
              aria-label="Remove image"
            >
              <X className="h-4 w-4" />
            </button>
          </Card>
        ))}
        
        {images.length < maxImages && (
          <Button
            type="button"
            variant="outline"
            className="h-auto aspect-square flex flex-col items-center justify-center p-6 border-dashed"
            onClick={() => fileInputRef.current?.click()}
          >
            <Upload className="h-8 w-8 mb-2 text-muted-foreground" />
            <span className="text-xs text-center text-muted-foreground">
              Upload Image
            </span>
          </Button>
        )}
      </div>

      {images.length >= maxImages && (
        <p className="text-xs text-amber-600">
          Maximum {maxImages} images allowed. Remove an image to upload a new one.
        </p>
      )}
      
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={handleFileChange}
        className="hidden"
        disabled={images.length >= maxImages}
      />
      
      <p className="text-xs text-muted-foreground">
        {images.length} of {maxImages} images uploaded
      </p>
    </div>
  );
};

export default ImageUploader;
