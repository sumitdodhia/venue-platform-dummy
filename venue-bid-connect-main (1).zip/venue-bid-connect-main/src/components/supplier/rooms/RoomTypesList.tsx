
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { RoomType } from "@/types/roomSupplier";
import RoomTypeForm from "./RoomTypeForm";
import { Plus } from "lucide-react";

interface RoomTypesListProps {
  roomTypes: RoomType[];
  onAddRoom: (room: RoomType) => void;
  onEditRoom: (room: RoomType) => void;
  onDeleteRoom: (id: string) => void;
  remainingRooms?: number;
}

const RoomTypesList = ({ 
  roomTypes, 
  onAddRoom, 
  onEditRoom, 
  onDeleteRoom,
  remainingRooms = undefined
}: RoomTypesListProps) => {
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const handleAddClick = () => {
    setIsAdding(true);
    setEditingId(null);
  };

  const handleEditClick = (id: string) => {
    setEditingId(id);
    setIsAdding(false);
  };

  const handleCancelAdd = () => {
    setIsAdding(false);
  };

  const handleCancelEdit = () => {
    setEditingId(null);
  };

  const handleAddSubmit = (room: RoomType) => {
    onAddRoom(room);
    setIsAdding(false);
  };

  const handleEditSubmit = (room: RoomType) => {
    onEditRoom(room);
    setEditingId(null);
  };

  return (
    <div className="space-y-6">
      {roomTypes.map((room) => (
        <div key={room.id}>
          {editingId === room.id ? (
            <RoomTypeForm
              initialValues={room}
              onSubmit={handleEditSubmit}
              onCancel={handleCancelEdit}
              isEditing
            />
          ) : (
            <Card>
              <CardHeader className="flex flex-row items-start justify-between space-y-0">
                <div>
                  <CardTitle className="text-xl">{room.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">
                    {room.type} · Max {room.maxPax} guests · {room.numberOfRooms} {room.numberOfRooms === 1 ? 'room' : 'rooms'}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-bold">${room.priceFrom}</p>
                  <p className="text-sm text-muted-foreground">starting from</p>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm line-clamp-2">{room.description}</p>
                
                {room.photos.length > 0 && (
                  <div className="mt-4 flex overflow-x-auto gap-2 pb-2">
                    {room.photos.map((photo, index) => (
                      <img 
                        key={index}
                        src={photo} 
                        alt={`${room.name} - Photo ${index + 1}`} 
                        className="h-20 w-28 rounded object-cover flex-shrink-0"
                      />
                    ))}
                  </div>
                )}
              </CardContent>
              <CardFooter className="flex justify-end gap-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => onDeleteRoom(room.id)}
                >
                  Delete
                </Button>
                <Button 
                  variant="default" 
                  size="sm"
                  onClick={() => handleEditClick(room.id)}
                >
                  Edit
                </Button>
              </CardFooter>
            </Card>
          )}
        </div>
      ))}

      {isAdding ? (
        <RoomTypeForm
          onSubmit={handleAddSubmit}
          onCancel={handleCancelAdd}
        />
      ) : (
        <Button 
          onClick={handleAddClick}
          className="w-full py-8"
          variant="outline"
          disabled={remainingRooms !== undefined && remainingRooms <= 0}
        >
          <Plus className="mr-2 h-5 w-5" />
          {remainingRooms !== undefined && remainingRooms <= 0 
            ? "No more rooms available to add" 
            : "Add Room Type"}
        </Button>
      )}
      
      {remainingRooms !== undefined && remainingRooms > 0 && !isAdding && (
        <p className="text-sm text-muted-foreground text-center">
          You can add up to {remainingRooms} more {remainingRooms === 1 ? 'room' : 'rooms'}
        </p>
      )}
    </div>
  );
};

export default RoomTypesList;
