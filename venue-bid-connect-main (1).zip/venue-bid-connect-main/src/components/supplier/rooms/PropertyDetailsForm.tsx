
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { PropertyDetails } from "@/types/roomSupplier";
import FacilityInput from "./FacilityInput";
import PropertyBasicDetails from "./PropertyBasicDetails";
import LocationInputs from "./LocationInputs";
import BasisOptions from "./BasisOptions";
import RatingInputs from "./RatingInputs";

interface PropertyDetailsFormProps {
  initialValues: PropertyDetails;
  onSubmit: (values: PropertyDetails) => void;
}

const PropertyDetailsForm = ({ initialValues, onSubmit }: PropertyDetailsFormProps) => {
  const [formValues, setFormValues] = useState<PropertyDetails>(initialValues);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormValues(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleNumberInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormValues(prev => ({
      ...prev,
      [name]: value ? Number(value) : 0
    }));
  };

  const handleBasisChange = (id: string) => {
    setFormValues(prev => {
      const updatedBasis = prev.basisOffered.includes(id)
        ? prev.basisOffered.filter(item => item !== id)
        : [...prev.basisOffered, id];
      
      return {
        ...prev,
        basisOffered: updatedBasis
      };
    });
  };

  const handleCountryChange = (value: string) => {
    setFormValues(prev => ({
      ...prev,
      country: value
    }));
  };

  const handleFacilitiesChange = (facilities: string[]) => {
    setFormValues(prev => ({
      ...prev,
      facilities
    }));
  };

  const handlePhotosChange = (photos: string[]) => {
    setFormValues(prev => ({
      ...prev,
      photos
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formValues);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="space-y-6">
        <h2 className="text-2xl font-semibold">Property Details</h2>
        
        <div className="grid gap-6">
          <PropertyBasicDetails 
            name={formValues.name}
            photos={formValues.photos}
            totalRooms={formValues.totalRooms}
            googleLocation={formValues.googleLocation}
            about={formValues.about}
            onInputChange={handleInputChange}
            onNumberInput={handleNumberInput}
            onPhotosChange={handlePhotosChange}
          />

          <LocationInputs 
            area={formValues.area}
            country={formValues.country}
            onInputChange={handleInputChange}
            onCountryChange={handleCountryChange}
          />

          <div className="space-y-2">
            <Label>Facilities & Services</Label>
            <FacilityInput
              facilities={formValues.facilities}
              onChange={handleFacilitiesChange}
            />
          </div>

          <div className="space-y-2">
            <Label>Basis Offered</Label>
            <BasisOptions 
              selectedOptions={formValues.basisOffered} 
              onChange={handleBasisChange}
            />
          </div>

          <RatingInputs 
            googleRating={formValues.rating}
            totalReviews={formValues.ratingCount}
            onChange={handleNumberInput}
          />
        </div>
      </div>

      <div className="pt-6 border-t flex justify-end">
        <Button type="submit">
          Continue to Room Setup
        </Button>
      </div>
    </form>
  );
};

export default PropertyDetailsForm;
