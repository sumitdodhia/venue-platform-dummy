
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";

interface BasisOptionsProps {
  selectedOptions: string[];
  onChange: (id: string) => void;
}

export const basisOptions = [
  { id: "self-catered", label: "Self-Catered" },
  { id: "bed-only", label: "Bed Only" },
  { id: "bed-breakfast", label: "Bed & Breakfast" },
  { id: "half-board", label: "Half Board" },
  { id: "full-board", label: "Full Board" },
  { id: "all-inclusive", label: "All Inclusive" },
];

const BasisOptions = ({ selectedOptions, onChange }: BasisOptionsProps) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
      {basisOptions.map((option) => (
        <div key={option.id} className="flex items-center space-x-2">
          <Checkbox 
            id={option.id} 
            checked={selectedOptions.includes(option.id)}
            onCheckedChange={() => onChange(option.id)}
          />
          <Label htmlFor={option.id} className="font-normal">
            {option.label}
          </Label>
        </div>
      ))}
    </div>
  );
};

export default BasisOptions;
