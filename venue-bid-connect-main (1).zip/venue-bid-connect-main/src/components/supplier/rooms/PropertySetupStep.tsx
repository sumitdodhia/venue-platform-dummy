
import PropertyDetailsForm from "./PropertyDetailsForm";
import { Button } from "@/components/ui/button";
import { PropertyDetails } from "@/types/roomSupplier";

interface PropertySetupStepProps {
  propertyDetails: PropertyDetails;
  onSave: (details: PropertyDetails) => void;
}

const PropertySetupStep = ({ propertyDetails, onSave }: PropertySetupStepProps) => {
  return (
    <PropertyDetailsForm 
      initialValues={propertyDetails} 
      onSubmit={onSave} 
    />
  );
};

export default PropertySetupStep;
