
import { Button } from "@/components/ui/button";
import { PropertyDetails, RoomType } from "@/types/roomSupplier";
import { Check } from "lucide-react";

interface ReviewPublishStepProps {
  propertyDetails: PropertyDetails;
  roomTypes: RoomType[];
  onBack: () => void;
  onPublish: () => void;
  isPublishing: boolean;
}

const ReviewPublishStep = ({
  propertyDetails,
  roomTypes,
  onBack,
  onPublish,
  isPublishing
}: ReviewPublishStepProps) => {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold">Review & Publish</h2>
      
      <div className="bg-muted/40 p-6 rounded-lg">
        <h3 className="font-semibold text-lg mb-2">Property Details</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Name</p>
            <p className="font-medium">{propertyDetails.name}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Location</p>
            <p className="font-medium">{propertyDetails.area}, {propertyDetails.country}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Total Rooms</p>
            <p className="font-medium">{propertyDetails.totalRooms}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Google Rating</p>
            <p className="font-medium">{propertyDetails.rating} ({propertyDetails.ratingCount} reviews)</p>
          </div>
        </div>
        
        <h3 className="font-semibold text-lg mt-6 mb-2">Room Types</h3>
        <div className="space-y-3">
          {roomTypes.map(room => (
            <div key={room.id} className="bg-background p-4 rounded-md">
              <div className="flex justify-between items-center">
                <h4 className="font-medium">{room.name}</h4>
                <p className="font-semibold">${room.priceFrom}/night</p>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                {room.type} - Max {room.maxPax} guests
              </p>
            </div>
          ))}
        </div>
      </div>
      
      <p className="text-muted-foreground">
        Your property has been set up successfully with {roomTypes.length} room types.
        Click "Publish Property" to make it live on the marketplace.
      </p>
      
      <div className="pt-6 flex justify-end gap-4">
        <Button variant="outline" onClick={onBack}>
          Back to Rooms
        </Button>
        <Button 
          onClick={onPublish} 
          disabled={isPublishing}
          className="gap-2"
        >
          {isPublishing ? "Publishing..." : "Publish Property"}
          {isPublishing && <Check className="h-4 w-4 animate-pulse" />}
        </Button>
      </div>
    </div>
  );
};

export default ReviewPublishStep;
