
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { RoomType } from "@/types/roomSupplier";
import RoomTypesList from "./RoomTypesList";
import { useRoomValidation } from "@/hooks/useRoomValidation";

interface RoomTypesSetupStepProps {
  roomTypes: RoomType[];
  propertyDetails: any;
  onAddRoom: (room: RoomType) => void;
  onEditRoom: (room: RoomType) => void;
  onDeleteRoom: (id: string) => void;
  onBack: () => void;
  onContinue: () => void;
}

const RoomTypesSetupStep = ({
  roomTypes,
  propertyDetails,
  onAddRoom,
  onEditRoom,
  onDeleteRoom,
  onBack,
  onContinue
}: RoomTypesSetupStepProps) => {
  const { 
    isValid, 
    validationMessage, 
    totalRoomsFromTypes, 
    remainingRooms 
  } = useRoomValidation(propertyDetails, roomTypes);

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold">Room Types</h2>
          {propertyDetails.totalRooms > 0 && (
            <p className="text-sm text-muted-foreground mt-1">
              {totalRoomsFromTypes} of {propertyDetails.totalRooms} rooms allocated 
              ({remainingRooms} remaining)
            </p>
          )}
        </div>
        <Button onClick={onBack}>
          Edit Property Details
        </Button>
      </div>
      
      {!isValid && validationMessage && (
        <Alert variant="destructive">
          <AlertDescription>
            {validationMessage}
          </AlertDescription>
        </Alert>
      )}
      
      <RoomTypesList 
        roomTypes={roomTypes}
        onAddRoom={onAddRoom}
        onEditRoom={onEditRoom}
        onDeleteRoom={onDeleteRoom}
        remainingRooms={remainingRooms}
      />
      
      <div className="pt-6 border-t flex justify-end gap-4">
        <Button 
          variant="outline" 
          onClick={onBack}
        >
          Back
        </Button>
        <Button 
          onClick={onContinue}
          disabled={roomTypes.length === 0 || !isValid}
        >
          Save & Continue
        </Button>
      </div>
    </div>
  );
};

export default RoomTypesSetupStep;
