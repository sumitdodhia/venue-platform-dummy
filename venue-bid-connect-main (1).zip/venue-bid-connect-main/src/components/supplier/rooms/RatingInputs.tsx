
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface RatingInputsProps {
  googleRating: number | undefined;
  totalReviews: number | undefined;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const RatingInputs = ({ googleRating, totalReviews, onChange }: RatingInputsProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="space-y-2">
        <Label htmlFor="rating">Google Rating (0-5)</Label>
        <Input
          id="rating"
          name="rating"
          type="number"
          min="0"
          max="5"
          step="0.1"
          value={googleRating || ""}
          onChange={onChange}
          placeholder="e.g., 4.5"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="ratingCount">Total Reviews</Label>
        <Input
          id="ratingCount"
          name="ratingCount"
          type="number"
          min="0"
          value={totalReviews || ""}
          onChange={onChange}
          placeholder="e.g., 123"
        />
      </div>
    </div>
  );
};

export default RatingInputs;
