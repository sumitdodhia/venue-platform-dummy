
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import ImageUploader from "./ImageUploader";

interface PropertyBasicDetailsProps {
  name: string;
  photos: string[];
  totalRooms: number | undefined;
  googleLocation: string;
  about: string;
  onInputChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  onNumberInput: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onPhotosChange: (photos: string[]) => void;
}

const PropertyBasicDetails = ({
  name,
  photos,
  totalRooms,
  googleLocation,
  about,
  onInputChange,
  onNumberInput,
  onPhotosChange
}: PropertyBasicDetailsProps) => {
  return (
    <>
      <div className="space-y-2">
        <Label htmlFor="name">Property Name *</Label>
        <Input
          id="name"
          name="name"
          value={name}
          onChange={onInputChange}
          required
        />
      </div>

      <div className="space-y-2">
        <Label>Property Photos (up to 5)</Label>
        <ImageUploader
          images={photos}
          onChange={onPhotosChange}
          maxImages={5}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="totalRooms">Total Number of Rooms</Label>
          <Input
            id="totalRooms"
            name="totalRooms"
            type="number"
            min="0"
            value={totalRooms || ""}
            onChange={onNumberInput}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="googleLocation">Google Maps URL</Label>
          <Input
            id="googleLocation"
            name="googleLocation"
            value={googleLocation}
            onChange={onInputChange}
            placeholder="Paste Google Maps URL"
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="about">About the Venue (max 500 characters)</Label>
        <Textarea
          id="about"
          name="about"
          value={about}
          onChange={onInputChange}
          maxLength={500}
          rows={4}
          placeholder="Brief description of your property"
        />
        <p className="text-xs text-muted-foreground">
          {about.length}/500 characters
        </p>
      </div>
    </>
  );
};

export default PropertyBasicDetails;
