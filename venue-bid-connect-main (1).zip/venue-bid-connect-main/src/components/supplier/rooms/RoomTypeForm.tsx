
import { useState } from "react";
import { v4 as uuidv4 } from 'uuid';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { RoomType } from "@/types/roomSupplier";
import ImageUploader from "./ImageUploader";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface RoomTypeFormProps {
  initialValues?: RoomType;
  onSubmit: (room: RoomType) => void;
  onCancel: () => void;
  isEditing?: boolean;
}

const defaultValues: RoomType = {
  id: '',
  name: '',
  type: '',
  description: '',
  photos: [],
  maxPax: 2,
  priceFrom: 0,
  numberOfRooms: 1
};

// List of available room types to choose from
const roomTypeOptions = [
  "Single Room",
  "Double Room",
  "Twin Room",
  "Triple Room",
  "Quad Room",
  "Family Room",
  "Deluxe Room",
  "Superior Room",
  "Executive Room",
  "Club Room",
  "Premier Room",
  "Junior Suite",
  "Executive Suite",
  "Presidential Suite",
  "Royal Suite",
  "Penthouse Suite",
  "Cottage",
  "Cabin",
  "Chalet",
  "Tent",
  "Banda",
  "Villa",
  "Treehouse",
  "Safari Suite",
  "Accessible Room",
  "Interconnecting Room",
  "Studio Room",
  "Apartment",
  "Loft",
  "Dormitory",
  "Other"
];

const RoomTypeForm = ({ 
  initialValues = defaultValues,
  onSubmit, 
  onCancel,
  isEditing = false
}: RoomTypeFormProps) => {
  const [form, setForm] = useState<RoomType>({
    id: initialValues.id || uuidv4(),
    name: initialValues.name,
    type: initialValues.type,
    description: initialValues.description,
    photos: initialValues.photos,
    maxPax: initialValues.maxPax,
    priceFrom: initialValues.priceFrom,
    numberOfRooms: initialValues.numberOfRooms || 1
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({
      ...prev,
      [name]: value ? Number(value) : 0
    }));
  };

  const handlePhotosChange = (photos: string[]) => {
    setForm(prev => ({
      ...prev,
      photos
    }));
  };

  const handleTypeChange = (value: string) => {
    setForm(prev => ({
      ...prev,
      type: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(form);
  };

  return (
    <Card className="p-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        <h3 className="text-lg font-semibold">
          {isEditing ? "Edit Room Type" : "Add New Room Type"}
        </h3>

        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Room Name *</Label>
              <Input
                id="name"
                name="name"
                value={form.name}
                onChange={handleInputChange}
                placeholder="e.g., Executive Suite"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="type">Type of Room *</Label>
              <Select
                value={form.type}
                onValueChange={handleTypeChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select room type" />
                </SelectTrigger>
                <SelectContent>
                  {roomTypeOptions.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              name="description"
              value={form.description}
              onChange={handleInputChange}
              rows={3}
              placeholder="Describe this room type"
            />
          </div>

          <div className="space-y-2">
            <Label>Room Photos (up to 5)</Label>
            <ImageUploader
              images={form.photos}
              onChange={handlePhotosChange}
              maxImages={5}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="maxPax">Maximum Number of Guests *</Label>
              <Input
                id="maxPax"
                name="maxPax"
                type="number"
                min="1"
                value={form.maxPax || ''}
                onChange={handleNumberChange}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="numberOfRooms">Number of Rooms *</Label>
              <Input
                id="numberOfRooms"
                name="numberOfRooms"
                type="number"
                min="1"
                value={form.numberOfRooms || ''}
                onChange={handleNumberChange}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="priceFrom">Price Starting From (USD) *</Label>
              <Input
                id="priceFrom"
                name="priceFrom"
                type="number"
                min="0"
                step="0.01"
                value={form.priceFrom || ''}
                onChange={handleNumberChange}
                required
              />
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button type="submit">
            {isEditing ? "Update Room" : "Add Room"}
          </Button>
        </div>
      </form>
    </Card>
  );
};

export default RoomTypeForm;
