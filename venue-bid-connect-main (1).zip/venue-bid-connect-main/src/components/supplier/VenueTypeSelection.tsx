
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Building, Hotel, Utensils } from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

type VenueType = "conference" | "hotel" | "restaurant";

interface VenueTypeOption {
  id: VenueType;
  title: string;
  description: string;
  icon: React.ReactNode;
  setupPath: string;
}

const venueOptions: VenueTypeOption[] = [
  {
    id: "conference",
    title: "Conference/Event Venue",
    description: "Meeting rooms, boardrooms and conference halls",
    icon: <Building className="w-12 h-12 text-primary" />,
    setupPath: "/supplier/venues/conference-setup"
  },
  {
    id: "hotel",
    title: "Hotel",
    description: "Accommodations, rooms and suites",
    icon: <Hotel className="w-12 h-12 text-primary" />,
    setupPath: "/supplier/venues/rooms-setup"
  },
  {
    id: "restaurant",
    title: "Restaurant",
    description: "Dining spaces, private rooms and catering",
    icon: <Utensils className="w-12 h-12 text-primary" />,
    setupPath: "/supplier/venues/restaurant-setup"
  }
];

const VenueTypeSelection = () => {
  const [selectedType, setSelectedType] = useState<VenueType | null>(null);
  const navigate = useNavigate();
  
  const handleSelection = (venueType: VenueType) => {
    setSelectedType(venueType);
  };
  
  const handleContinue = () => {
    if (selectedType) {
      const selectedOption = venueOptions.find(opt => opt.id === selectedType);
      if (selectedOption) {
        navigate(selectedOption.setupPath);
      }
    }
  };
  
  return (
    <div className="container py-8 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Select Venue Type</h1>
      <p className="text-muted-foreground mb-8">
        Choose the type of venue you want to add to continue with the appropriate form.
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {venueOptions.map((option) => (
          <Card 
            key={option.id}
            className={`cursor-pointer transition-all hover:shadow-md ${
              selectedType === option.id ? "border-primary ring-2 ring-primary/20" : ""
            }`}
            onClick={() => handleSelection(option.id)}
          >
            <CardHeader className="pb-2">
              <div className="mb-3">{option.icon}</div>
              <CardTitle>{option.title}</CardTitle>
              <CardDescription>{option.description}</CardDescription>
            </CardHeader>
          </Card>
        ))}
      </div>
      
      <div className="mt-8 flex justify-end">
        <Button 
          onClick={handleContinue} 
          disabled={!selectedType}
          size="lg"
        >
          Continue
        </Button>
      </div>
    </div>
  );
};

export default VenueTypeSelection;
