
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { Building, Mail, Users, LineChart, Check, Bell } from "lucide-react";
import { useAuth } from "@/context/AuthContext";

const SupplierDashboard = () => {
  const { profile } = useAuth();

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold mb-1">Welcome, {profile?.first_name || 'Supplier'}</h1>
          <p className="text-muted-foreground">Manage your venues and enquiries</p>
        </div>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-sm font-medium">Active Venues</CardTitle>
            <Building className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">0</div>
            <p className="text-xs text-muted-foreground mt-1">Published venues</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-sm font-medium">Open Enquiries</CardTitle>
            <Mail className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">0</div>
            <p className="text-xs text-muted-foreground mt-1">Awaiting response</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-sm font-medium">Active Bids</CardTitle>
            <LineChart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">0</div>
            <p className="text-xs text-muted-foreground mt-1">Awaiting client decision</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-sm font-medium">Confirmed Bookings</CardTitle>
            <Check className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">0</div>
            <p className="text-xs text-muted-foreground mt-1">Last 30 days</p>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Recent Enquiries */}
        <div className="md:col-span-2">
          <h2 className="text-xl font-semibold mb-4">Recent Enquiries</h2>
          <Card>
            <CardContent className="p-6 text-center">
              <Mail className="h-12 w-12 mx-auto mb-3 text-muted-foreground/60" />
              <p className="text-muted-foreground">No recent enquiries available.</p>
              <p className="text-sm text-muted-foreground mt-2">New enquiries from clients will appear here.</p>
            </CardContent>
            <CardFooter className="border-t bg-muted/50">
              <Link to="/supplier/enquiries" className="text-sm text-primary hover:underline w-full text-center">
                View all enquiries
              </Link>
            </CardFooter>
          </Card>
        </div>
        
        {/* Notifications */}
        <div>
          <h2 className="text-xl font-semibold mb-4">Notifications</h2>
          <Card>
            <CardContent className="p-6 text-center">
              <Bell className="h-12 w-12 mx-auto mb-3 text-muted-foreground/60" />
              <p className="text-muted-foreground">No new notifications.</p>
              <p className="text-sm text-muted-foreground mt-2">Important updates will appear here.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default SupplierDashboard;
