
import { Link, Outlet, useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Building, 
  Gavel, 
  Home, 
  Inbox, 
  LogOut,
  Mail, 
  Menu,
  Settings, 
  CreditCard,
  User
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState, useEffect } from "react";
import { SidebarProvider } from "@/components/ui/sidebar";

const SupplierDashboardLayout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, profile, signOut } = useAuth();
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  
  const handleLogout = async () => {
    try {
      await signOut();
      navigate("/");
    } catch (error) {
      toast.error("Failed to log out. Please try again.");
    }
  };

  // Helper function to check if a route is active
  const isActive = (path: string) => {
    return location.pathname === path || location.pathname.startsWith(`${path}/`);
  };
  
  // Get user initials for avatar fallback
  const getInitials = () => {
    if (!profile) return "?";
    
    const firstInitial = profile.first_name?.charAt(0) || '';
    const lastInitial = profile.last_name?.charAt(0) || '';
    
    return (firstInitial + lastInitial).toUpperCase() || user?.email?.charAt(0).toUpperCase() || '?';
  };
  
  const displayName = profile 
    ? `${profile.first_name || ''} ${profile.last_name || ''}`.trim() 
    : user?.email?.split('@')[0] || 'User';
  
  const companyName = profile?.company_name || 'My Company';
  const userEmail = user?.email || '';
  
  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      <nav className="flex-1 space-y-1 p-4">
        <Link 
          to="/supplier"
          className={cn(
            "flex items-center px-3 py-2 text-sm rounded-md transition-colors hover:bg-accent",
            isActive("/supplier") && !isActive("/supplier/enquiries") && !isActive("/supplier/bids") && "bg-accent font-medium"
          )}
        >
          <Home className="mr-2 h-4 w-4" />
          Dashboard
        </Link>
        <Link 
          to="/supplier/venues"
          className={cn(
            "flex items-center px-3 py-2 text-sm rounded-md transition-colors hover:bg-accent",
            isActive("/supplier/venues") && "bg-accent font-medium"
          )}
        >
          <Building className="mr-2 h-4 w-4" />
          My Venues
        </Link>
        
        {/* Enquiries Section with Subcategories */}
        <div className="pt-2 mt-2 border-t">
          <h3 className="px-3 text-xs font-semibold text-muted-foreground mb-2">
            Enquiries & Bids
          </h3>
          <Link 
            to="/supplier/enquiries/bidding"
            className={cn(
              "flex items-center px-3 py-2 text-sm rounded-md transition-colors hover:bg-accent",
              isActive("/supplier/enquiries/bidding") && "bg-accent font-medium"
            )}
          >
            <Gavel className="mr-2 h-4 w-4" />
            Bidding Enquiries
          </Link>
          <Link 
            to="/supplier/enquiries/direct"
            className={cn(
              "flex items-center px-3 py-2 text-sm rounded-md transition-colors hover:bg-accent",
              isActive("/supplier/enquiries/direct") && "bg-accent font-medium"
            )}
          >
            <Mail className="mr-2 h-4 w-4" />
            Direct Enquiries
          </Link>
          <Link 
            to="/supplier/bids"
            className={cn(
              "flex items-center px-3 py-2 text-sm rounded-md transition-colors hover:bg-accent",
              isActive("/supplier/bids") && "bg-accent font-medium"
            )}
          >
            <Inbox className="mr-2 h-4 w-4" />
            My Bids
          </Link>
        </div>
        
        <Link 
          to="/supplier/subscription"
          className={cn(
            "flex items-center px-3 py-2 text-sm rounded-md transition-colors hover:bg-accent",
            isActive("/supplier/subscription") && "bg-accent font-medium"
          )}
        >
          <CreditCard className="mr-2 h-4 w-4" />
          Subscription
        </Link>
        
        <div className="pt-4 mt-4 border-t">
          <h3 className="px-3 text-xs font-semibold text-muted-foreground mb-2">
            Account
          </h3>
          <Link 
            to="/supplier/profile"
            className={cn(
              "flex items-center px-3 py-2 text-sm rounded-md transition-colors hover:bg-accent",
              isActive("/supplier/profile") && "bg-accent font-medium"
            )}
          >
            <User className="mr-2 h-4 w-4" />
            Company Profile
          </Link>
          <Link 
            to="/supplier/settings"
            className={cn(
              "flex items-center px-3 py-2 text-sm rounded-md transition-colors hover:bg-accent",
              isActive("/supplier/settings") && "bg-accent font-medium"
            )}
          >
            <Settings className="mr-2 h-4 w-4" />
            Settings
          </Link>
          <Button 
            variant="ghost" 
            size="sm" 
            className="w-full justify-start px-3 py-2 h-auto text-sm font-normal text-red-500 hover:text-red-600 hover:bg-red-50"
            onClick={handleLogout}
          >
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </Button>
        </div>
      </nav>
    </div>
  );

  return (
    <SidebarProvider>
      <div className="min-h-screen flex flex-col w-full">
        {/* Dashboard Header */}
        <header className="sticky top-0 z-30 w-full bg-white border-b shadow-sm">
          <div className="container mx-auto px-4 h-16 flex items-center justify-between">
            <div className="flex items-center">
              <Link to="/supplier" className="font-bold text-xl text-primary">
                FindToTable
              </Link>
              <span className="ml-2 hidden md:block text-sm text-muted-foreground">Supplier Dashboard</span>
              
              {/* Mobile menu trigger */}
              {isMobile && (
                <Sheet>
                  <SheetTrigger asChild>
                    <Button variant="ghost" size="icon" className="md:hidden ml-2">
                      <Menu className="h-5 w-5" />
                      <span className="sr-only">Toggle menu</span>
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="w-[240px] sm:w-[300px] p-0">
                    <div className="px-4 py-6 border-b">
                      <div className="flex items-center mb-4">
                        <Avatar className="h-10 w-10 mr-3">
                          <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${getInitials()}`} />
                          <AvatarFallback>{getInitials()}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-sm font-medium">{displayName}</p>
                          <p className="text-xs text-muted-foreground truncate max-w-[180px]">{userEmail}</p>
                        </div>
                      </div>
                      <div className="text-xs font-semibold uppercase text-muted-foreground mb-1">
                        Company
                      </div>
                      <div className="text-sm">{companyName}</div>
                    </div>
                    <SidebarContent />
                  </SheetContent>
                </Sheet>
              )}
            </div>
            
            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm" asChild className="hidden md:flex">
                <Link to="/marketplace">View Marketplace</Link>
              </Button>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="relative flex items-center gap-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${getInitials()}`} />
                      <AvatarFallback>{getInitials()}</AvatarFallback>
                    </Avatar>
                    <span className="hidden md:inline-block">{displayName}</span>
                    <span className="absolute top-0 right-0 md:right-7 h-2 w-2 bg-green-500 rounded-full" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <div className="px-2 pt-2 pb-2">
                    <div className="text-sm font-medium">{displayName}</div>
                    <div className="text-xs text-muted-foreground truncate">{userEmail}</div>
                  </div>
                  <DropdownMenuSeparator />
                  <div className="px-2 py-1.5">
                    <div className="text-xs font-semibold uppercase text-muted-foreground">
                      Company
                    </div>
                    <div className="text-sm">{companyName}</div>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link to="/supplier/profile" className="cursor-pointer">Company Profile</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/supplier/settings" className="cursor-pointer">Settings</Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="text-red-500 focus:text-red-500 cursor-pointer">
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>
        
        {/* Dashboard Content */}
        <div className="flex-1 flex w-full">
          {/* Fixed Sidebar */}
          <div className="hidden md:block w-64 border-r bg-muted/30">
            <SidebarContent />
          </div>
          
          {/* Main Content */}
          <div className="flex-1 p-4 md:p-6 overflow-auto bg-background">
            <Outlet />
          </div>
        </div>
      </div>
    </SidebarProvider>
  );
};

export default SupplierDashboardLayout;
