
import React from "react";
import { TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Building2, UtensilsCrossed, Hotel } from "lucide-react";

export type EnquiryCategory = "rooms" | "conference" | "restaurants";

interface EnquiryCategoryTabsProps {
  category: EnquiryCategory;
  onCategoryChange: (value: string) => void;
}

const EnquiryCategoryTabs = ({ category, onCategoryChange }: EnquiryCategoryTabsProps) => {
  return (
    <TabsList className="grid grid-cols-1 md:grid-cols-3 gap-1">
      <TabsTrigger 
        value="rooms" 
        className="flex items-center gap-2"
        onClick={() => onCategoryChange("rooms")}
      >
        <Hotel className="h-4 w-4" />
        <span>Rooms</span>
      </TabsTrigger>
      <TabsTrigger 
        value="conference" 
        className="flex items-center gap-2"
        onClick={() => onCategoryChange("conference")}
      >
        <Building2 className="h-4 w-4" />
        <span>Conference</span>
      </TabsTrigger>
      <TabsTrigger 
        value="restaurants" 
        className="flex items-center gap-2"
        onClick={() => onCategoryChange("restaurants")}
      >
        <UtensilsCrossed className="h-4 w-4" />
        <span>Restaurants</span>
      </TabsTrigger>
    </TabsList>
  );
};

export default EnquiryCategoryTabs;
