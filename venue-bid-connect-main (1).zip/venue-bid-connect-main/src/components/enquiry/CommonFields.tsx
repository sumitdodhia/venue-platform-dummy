
import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";

interface CommonFieldsProps {
  form: any;
}

const CommonFields = ({ form }: CommonFieldsProps) => {
  return (
    <div className="border rounded-lg p-4 space-y-4">
      <h3 className="text-md font-semibold">Contact Information</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="title">Enquiry Title</Label>
          <Input
            id="title"
            placeholder="Brief description of your requirements"
            required
            {...form.register("title", { required: true })}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="company">Company Name</Label>
          <Input
            id="company"
            placeholder="Your company name (optional)"
            {...form.register("company")}
          />
        </div>
      </div>
    </div>
  );
};

export default CommonFields;
