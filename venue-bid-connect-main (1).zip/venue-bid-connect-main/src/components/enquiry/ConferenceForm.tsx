
import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useForm } from "react-hook-form";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import CommonFields from "./CommonFields";
import FormActions from "./FormActions";
import AdditionalFields from "./AdditionalFields";

export interface ConferenceFormProps {
  onSubmitSuccess: () => void;
}

const ConferenceForm: React.FC<ConferenceFormProps> = ({ onSubmitSuccess }) => {
  const form = useForm({
    defaultValues: {
      title: "",
      company: "",
      eventDate: "",
      eventEndDate: "",
      guests: 50,
      eventType: "meeting",
      layout: "theater",
      equipmentNeeded: [],
      city: "",
      country: "",
    },
  });

  const handleSubmit = (data: any) => {
    console.log("Conference enquiry submitted:", data);
    onSubmitSuccess();
  };

  return (
    <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
      <CommonFields form={form} />

      <div className="border rounded-lg p-4 space-y-4">
        <h3 className="text-md font-semibold mb-4">Event Details</h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="eventDate">Event Start Date</Label>
            <Input
              id="eventDate"
              type="date"
              required
              {...form.register("eventDate", { required: true })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="eventEndDate">Event End Date</Label>
            <Input
              id="eventEndDate"
              type="date"
              {...form.register("eventEndDate")}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="guests">Number of Attendees</Label>
            <Input
              id="guests"
              type="number"
              min="1"
              required
              {...form.register("guests", {
                required: true,
                valueAsNumber: true,
                min: 1,
              })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="eventType">Event Type</Label>
            <Select
              defaultValue="meeting"
              onValueChange={(value) => form.setValue("eventType", value)}
            >
              <SelectTrigger id="eventType">
                <SelectValue placeholder="Select event type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="meeting">Meeting</SelectItem>
                <SelectItem value="conference">Conference</SelectItem>
                <SelectItem value="workshop">Workshop</SelectItem>
                <SelectItem value="training">Training Session</SelectItem>
                <SelectItem value="social">Social Event</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="layout">Preferred Layout</Label>
            <Select
              defaultValue="theater"
              onValueChange={(value) => form.setValue("layout", value)}
            >
              <SelectTrigger id="layout">
                <SelectValue placeholder="Select layout" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="theater">Theater</SelectItem>
                <SelectItem value="classroom">Classroom</SelectItem>
                <SelectItem value="boardroom">Boardroom</SelectItem>
                <SelectItem value="ushape">U-Shape</SelectItem>
                <SelectItem value="banquet">Banquet</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2 mt-4">
          <Label>Equipment Needed</Label>
          <div className="grid grid-cols-2 gap-2">
            <div className="flex items-center space-x-2">
              <Checkbox id="projector" />
              <label htmlFor="projector" className="text-sm">Projector</label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox id="microphone" />
              <label htmlFor="microphone" className="text-sm">Microphone</label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox id="videoConf" />
              <label htmlFor="videoConf" className="text-sm">Video Conference</label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox id="wifi" />
              <label htmlFor="wifi" className="text-sm">WiFi</label>
            </div>
          </div>
        </div>
      </div>

      <AdditionalFields />
      <FormActions onCancel={() => form.reset()} />
    </form>
  );
};

export default ConferenceForm;
