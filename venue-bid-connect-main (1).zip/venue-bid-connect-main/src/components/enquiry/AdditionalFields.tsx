
import React from "react";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";

const AdditionalFields = () => {
  return (
    <>
      <div className="space-y-2 mt-6">
        <Label htmlFor="special-requests">Special Requests</Label>
        <Textarea
          id="special-requests"
          placeholder="Any additional requirements or information"
          className="min-h-[100px]"
        />
      </div>

      <div className="space-y-2 mt-6">
        <Label htmlFor="budget-range">Overall Budget Range</Label>
        <div className="flex gap-4">
          <Input id="budget-min" type="number" min="0" placeholder="Min $" className="w-full" />
          <Input id="budget-max" type="number" min="0" placeholder="Max $" className="w-full" />
        </div>
      </div>
    </>
  );
};

export default AdditionalFields;
