
import { EnquiryType } from '@/components/supplier/bid/types';
import { Venue } from '@/types/venue';

export interface EnquiryFormData {
  // Common fields
  title: string;
  company: string;
  contactName: string;
  email: string;
  phone: string;
  budget: string;
  requirements: string;
  deadline: string;
  
  // Conference specific fields
  date?: string;
  guests?: number;
  layout?: string;
  equipment?: string[];
  venueType?: string;
  
  // Room specific fields
  checkInDate?: string;
  checkOutDate?: string;
  roomCount?: number;
  roomType?: string;
  mealPlan?: string;
  city?: string;
  country?: string;
  
  // Restaurant specific fields
  reservationDate?: string;
  reservationTime?: string;
  partySize?: number;
  diningSection?: string;
  cuisinePreference?: string;
  diningPackage?: string;
}

export interface EnquirySubmitResponse {
  success: boolean;
  enquiryId?: string;
  error?: string;
}

export interface EnquiryCategory {
  id: string;
  name: string;
  description: string;
  icon: string;
}

export interface EnquiryVenueData {
  venue?: Venue;
  enquiries?: EnquiryType[];
}
