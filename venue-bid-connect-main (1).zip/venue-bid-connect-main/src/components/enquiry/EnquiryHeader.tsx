
import React from "react";

const EnquiryHeader = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold">New Bid Request</h1>
      <p className="text-muted-foreground">
        Create a new enquiry and receive competitive bids from suppliers
      </p>
    </div>
  );
};

export default EnquiryHeader;
