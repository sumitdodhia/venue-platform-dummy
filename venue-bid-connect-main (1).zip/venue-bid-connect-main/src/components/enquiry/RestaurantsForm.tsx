
import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import CommonFields from "./CommonFields";
import FormActions from "./FormActions";
import AdditionalFields from "./AdditionalFields";

export interface RestaurantsFormProps {
  onSubmitSuccess: () => void;
}

const RestaurantsForm: React.FC<RestaurantsFormProps> = ({ onSubmitSuccess }) => {
  const form = useForm({
    defaultValues: {
      title: "",
      company: "",
      reservationDate: "",
      reservationTime: "19:00",
      guests: 4,
      seatingType: "any",
      occasion: "dinner",
      dietaryRequirements: "",
      budgetPerPerson: "",
      city: "",
      country: "",
    },
  });

  const handleSubmit = (data: any) => {
    console.log("Restaurant enquiry submitted:", data);
    onSubmitSuccess();
  };

  return (
    <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
      <CommonFields form={form} />
      
      <div className="border rounded-lg p-4 space-y-4">
        <h3 className="text-md font-semibold mb-4">Dining Details</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="reservationDate">Reservation Date</Label>
            <Input
              id="reservationDate"
              type="date"
              required
              {...form.register("reservationDate", { required: true })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="reservationTime">Reservation Time</Label>
            <Input
              id="reservationTime"
              type="time"
              defaultValue="19:00"
              required
              {...form.register("reservationTime", { required: true })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="guests">Number of Guests</Label>
            <Input
              id="guests"
              type="number"
              min="1"
              required
              {...form.register("guests", {
                required: true,
                valueAsNumber: true,
                min: 1,
              })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="seatingType">Seating Preference</Label>
            <Select
              defaultValue="any"
              onValueChange={(value) => form.setValue("seatingType", value)}
            >
              <SelectTrigger id="seatingType">
                <SelectValue placeholder="Select seating type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="any">Any Type</SelectItem>
                <SelectItem value="indoor">Indoor</SelectItem>
                <SelectItem value="outdoor">Outdoor</SelectItem>
                <SelectItem value="private-room">Private Room</SelectItem>
                <SelectItem value="bar">Bar Area</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="occasion">Occasion</Label>
            <Select
              defaultValue="dinner"
              onValueChange={(value) => form.setValue("occasion", value)}
            >
              <SelectTrigger id="occasion">
                <SelectValue placeholder="Select occasion" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="dinner">Dinner</SelectItem>
                <SelectItem value="lunch">Lunch</SelectItem>
                <SelectItem value="business">Business Meeting</SelectItem>
                <SelectItem value="birthday">Birthday</SelectItem>
                <SelectItem value="anniversary">Anniversary</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="budgetPerPerson">Budget Per Person</Label>
            <Input
              id="budgetPerPerson"
              type="number"
              placeholder="$"
              min="1"
              {...form.register("budgetPerPerson", { valueAsNumber: true })}
            />
          </div>

          <div className="col-span-full space-y-2">
            <Label htmlFor="dietaryRequirements">Dietary Requirements</Label>
            <Textarea
              id="dietaryRequirements"
              placeholder="Please list any dietary requirements or allergies"
              className="min-h-[80px]"
              {...form.register("dietaryRequirements")}
            />
          </div>
        </div>
      </div>

      <AdditionalFields />
      <FormActions onCancel={() => form.reset()} />
    </form>
  );
};

export default RestaurantsForm;
