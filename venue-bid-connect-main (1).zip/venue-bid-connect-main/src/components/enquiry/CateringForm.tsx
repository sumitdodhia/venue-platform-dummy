
import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const CateringForm = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="space-y-2">
        <Label htmlFor="attendees-catering">Number of People</Label>
        <Input id="attendees-catering" type="number" min="1" required />
      </div>
      <div className="space-y-2">
        <Label htmlFor="meal-type">Meal Type</Label>
        <Select>
          <SelectTrigger id="meal-type" className="w-full">
            <SelectValue placeholder="Select Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="select">Select Type</SelectItem>
            <SelectItem value="breakfast">Breakfast</SelectItem>
            <SelectItem value="lunch">Lunch</SelectItem>
            <SelectItem value="dinner">Dinner</SelectItem>
            <SelectItem value="buffet">Buffet</SelectItem>
            <SelectItem value="reception">Reception</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <Label htmlFor="cuisine-preference">Cuisine Preference</Label>
        <Select>
          <SelectTrigger id="cuisine-preference" className="w-full">
            <SelectValue placeholder="Any Cuisine" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="any">Any Cuisine</SelectItem>
            <SelectItem value="international">International</SelectItem>
            <SelectItem value="local">Local</SelectItem>
            <SelectItem value="mediterranean">Mediterranean</SelectItem>
            <SelectItem value="asian">Asian</SelectItem>
            <SelectItem value="american">American</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <Label htmlFor="dietary-requirements">Dietary Requirements</Label>
        <Input id="dietary-requirements" placeholder="Vegetarian, vegan, gluten-free, etc." />
      </div>
    </div>
  );
};

export default CateringForm;
