
import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useForm } from "react-hook-form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import CommonFields from "./CommonFields";
import FormActions from "./FormActions";
import AdditionalFields from "./AdditionalFields";

export interface RoomsFormProps {
  onSubmitSuccess: () => void;
}

const RoomsForm: React.FC<RoomsFormProps> = ({ onSubmitSuccess }) => {
  const form = useForm({
    defaultValues: {
      title: "",
      company: "",
      checkInDate: "",
      checkOutDate: "",
      numRooms: 1,
      roomType: "standard",
      city: "",
      country: "",
      requirements: "",
      budget: "",
    },
  });

  const handleSubmit = (data: any) => {
    console.log("Room enquiry submitted:", data);
    onSubmitSuccess();
  };

  return (
    <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
      <CommonFields form={form} />

      <div className="border rounded-lg p-4 space-y-4">
        <h3 className="text-md font-semibold mb-4">Room Requirements</h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="checkInDate">Check-in Date</Label>
            <Input
              id="checkInDate"
              type="date"
              required
              {...form.register("checkInDate", { required: true })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="checkOutDate">Check-out Date</Label>
            <Input
              id="checkOutDate"
              type="date"
              required
              {...form.register("checkOutDate", { required: true })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="numRooms">Number of Rooms</Label>
            <Input
              id="numRooms"
              type="number"
              min="1"
              required
              {...form.register("numRooms", {
                required: true,
                valueAsNumber: true,
                min: 1,
              })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="roomType">Room Type</Label>
            <Select
              defaultValue="standard"
              onValueChange={(value) => form.setValue("roomType", value)}
            >
              <SelectTrigger id="roomType">
                <SelectValue placeholder="Select room type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="standard">Standard</SelectItem>
                <SelectItem value="deluxe">Deluxe</SelectItem>
                <SelectItem value="suite">Suite</SelectItem>
                <SelectItem value="executive">Executive</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="city">City</Label>
            <Input
              id="city"
              required
              {...form.register("city", { required: true })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="country">Country</Label>
            <Input
              id="country"
              required
              {...form.register("country", { required: true })}
            />
          </div>
        </div>
      </div>

      <AdditionalFields />
      <FormActions onCancel={() => form.reset()} />
    </form>
  );
};

export default RoomsForm;
