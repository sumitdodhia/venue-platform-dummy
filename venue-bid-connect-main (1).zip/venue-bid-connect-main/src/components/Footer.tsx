
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-gray-50 border-t">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="font-bold text-lg mb-4">FindToTable</h3>
            <p className="text-sm text-gray-600 mb-4">
              Your Customer. Your Revenue. Your Way. The premier marketplace for hotels, venues, and event spaces.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">For Users</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/marketplace" className="text-gray-600 hover:text-primary">
                  Browse Venues
                </Link>
              </li>
              <li>
                <Link to="/how-it-works" className="text-gray-600 hover:text-primary">
                  How It Works
                </Link>
              </li>
              <li>
                <Link to="/login" className="text-gray-600 hover:text-primary">
                  Sign In
                </Link>
              </li>
              <li>
                <Link to="/register" className="text-gray-600 hover:text-primary">
                  Register
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">For Suppliers</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/suppliers" className="text-gray-600 hover:text-primary">
                  List Your Venue
                </Link>
              </li>
              <li>
                <Link to="/suppliers/benefits" className="text-gray-600 hover:text-primary">
                  Benefits
                </Link>
              </li>
              <li>
                <Link to="/suppliers/pricing" className="text-gray-600 hover:text-primary">
                  Pricing
                </Link>
              </li>
              <li>
                <Link to="/suppliers/register" className="text-gray-600 hover:text-primary">
                  Become a Supplier
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Contact</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/contact" className="text-gray-600 hover:text-primary">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link to="/support" className="text-gray-600 hover:text-primary">
                  Support Center
                </Link>
              </li>
              <li>
                <Link to="/faq" className="text-gray-600 hover:text-primary">
                  FAQs
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-12 pt-6 border-t">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-gray-600">
              © {new Date().getFullYear()} FindToTable. All rights reserved.
            </p>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <Link to="/terms" className="text-xs text-gray-600 hover:text-primary">
                Terms of Service
              </Link>
              <Link to="/privacy" className="text-xs text-gray-600 hover:text-primary">
                Privacy Policy
              </Link>
              <Link to="/cookies" className="text-xs text-gray-600 hover:text-primary">
                Cookies
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
