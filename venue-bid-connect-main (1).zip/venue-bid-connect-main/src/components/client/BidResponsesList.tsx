
import { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Eye, MessageSquare } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";

// Mock data for bid responses
const mockResponses = [
  {
    id: "resp1",
    supplierName: "Grand Hotel",
    enquiryTitle: "Annual Sales Conference",
    category: "conference",
    responseDate: "2025-04-15",
    price: "$4,500",
    status: "received"
  },
  {
    id: "resp2",
    supplierName: "Luxury Resort & Spa",
    enquiryTitle: "Team Retreat",
    category: "rooms",
    responseDate: "2025-04-12",
    price: "$12,800",
    status: "accepted"
  },
  {
    id: "resp3",
    supplierName: "City View Conference Center",
    enquiryTitle: "Product Launch Event",
    category: "conference",
    responseDate: "2025-04-10",
    price: "$3,200",
    status: "declined"
  },
  {
    id: "resp4",
    supplierName: "Beachfront Hotel",
    enquiryTitle: "Executive Board Meeting",
    category: "rooms",
    responseDate: "2025-04-08",
    price: "$5,600",
    status: "received"
  },
  {
    id: "resp5",
    supplierName: "Gourmet Catering Co.",
    enquiryTitle: "Client Appreciation Dinner",
    category: "catering",
    responseDate: "2025-04-05",
    price: "$2,800",
    status: "received"
  },
];

interface BidResponsesListProps {
  status: string;
}

const BidResponsesList = ({ status }: BidResponsesListProps) => {
  const navigate = useNavigate();
  
  // Filter responses based on status
  const filteredResponses = status === "all" 
    ? mockResponses 
    : mockResponses.filter(response => response.status === status);
  
  const handleViewDetails = (responseId: string) => {
    // In a real app, navigate to the response details page
    toast.info(`Viewing details for response ${responseId}`);
  };
  
  const handleContactSupplier = (supplierName: string) => {
    // In a real app, open a messaging interface
    toast.info(`Opening messaging with ${supplierName}`);
  };
  
  return (
    <div>
      {filteredResponses.length > 0 ? (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Supplier</TableHead>
              <TableHead>Enquiry</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Price</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredResponses.map((response) => (
              <TableRow key={response.id}>
                <TableCell className="font-medium">{response.supplierName}</TableCell>
                <TableCell>{response.enquiryTitle}</TableCell>
                <TableCell>
                  <CategoryBadge category={response.category} />
                </TableCell>
                <TableCell>{response.responseDate}</TableCell>
                <TableCell>{response.price}</TableCell>
                <TableCell>
                  <StatusBadge status={response.status} />
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => handleViewDetails(response.id)}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => handleContactSupplier(response.supplierName)}
                    >
                      <MessageSquare className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      ) : (
        <div className="text-center py-8">
          <p className="text-muted-foreground">No responses found</p>
        </div>
      )}
    </div>
  );
};

const CategoryBadge = ({ category }: { category: string }) => {
  switch (category) {
    case "rooms":
      return <Badge variant="outline" className="bg-blue-50 text-blue-600 hover:bg-blue-50">Accommodation</Badge>;
    case "conference":
      return <Badge variant="outline" className="bg-green-50 text-green-600 hover:bg-green-50">Conference</Badge>;
    case "restaurants":
      return <Badge variant="outline" className="bg-amber-50 text-amber-600 hover:bg-amber-50">Restaurant</Badge>;
    case "catering":
      return <Badge variant="outline" className="bg-purple-50 text-purple-600 hover:bg-purple-50">Catering</Badge>;
    default:
      return <Badge variant="outline">{category}</Badge>;
  }
};

const StatusBadge = ({ status }: { status: string }) => {
  switch (status) {
    case "received":
      return <Badge variant="outline" className="bg-blue-50 text-blue-600 hover:bg-blue-50">New</Badge>;
    case "accepted":
      return <Badge className="bg-green-600">Accepted</Badge>;
    case "declined":
      return <Badge variant="outline" className="border-red-500 text-red-500">Declined</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

export default BidResponsesList;
