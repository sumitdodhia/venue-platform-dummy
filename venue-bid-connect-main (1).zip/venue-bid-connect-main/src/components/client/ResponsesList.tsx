
import { useState } from "react";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

interface Response {
  id: string;
  enquiryId: string;
  supplierName: string;
  venueName: string;
  price: string;
  description: string;
  status: string;
  submittedDate: string;
  catering?: string;
  menu?: string;
  availability: string;
  notes: string;
}

interface ResponsesListProps {
  responses: Response[];
}

const ResponsesList = ({ responses }: ResponsesListProps) => {
  const handleStatusChange = (responseId: string, newStatus: string) => {
    // In a real app, this would update the database
    toast.success(`Response marked as ${newStatus}`);
  };

  const handleAccept = (response: Response) => {
    toast.success(`You've accepted the offer from ${response.supplierName}`);
    // In a real app, this would update the database and notify the supplier
  };

  const handleDecline = (response: Response) => {
    toast.success(`Response from ${response.supplierName} has been declined`);
    // In a real app, this would update the database and notify the supplier
  };

  const handleContactSupplier = (response: Response) => {
    toast.success(`Opening chat with ${response.supplierName}`);
    // In a real app, this would open a chat interface or send an email
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "new":
        return <Badge variant="secondary">New</Badge>;
      case "reviewed":
        return <Badge variant="outline">Reviewed</Badge>;
      case "accepted":
        return <Badge className="bg-green-500">Accepted</Badge>;
      case "declined":
        return <Badge variant="destructive">Declined</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {responses.length > 0 ? (
        <div className="space-y-4">
          {responses.map((response) => (
            <Card key={response.id} className="relative">
              <div className="absolute top-4 right-4">
                {getStatusBadge(response.status)}
              </div>
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="md:col-span-1">
                    <h3 className="font-semibold text-lg">{response.venueName}</h3>
                    <p className="text-sm text-muted-foreground mb-2">{response.supplierName}</p>
                    <p className="text-lg font-medium text-primary">{response.price}</p>
                    <p className="text-xs text-muted-foreground mt-1">Submitted on {response.submittedDate}</p>
                  </div>
                  
                  <div className="md:col-span-2">
                    <h4 className="font-medium mb-2">Description</h4>
                    <p className="text-sm mb-4">{response.description}</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2">
                      {response.catering && (
                        <div>
                          <h4 className="text-sm font-medium">Catering</h4>
                          <p className="text-sm">{response.catering}</p>
                        </div>
                      )}
                      {response.menu && (
                        <div>
                          <h4 className="text-sm font-medium">Menu</h4>
                          <p className="text-sm">{response.menu}</p>
                        </div>
                      )}
                      <div>
                        <h4 className="text-sm font-medium">Availability</h4>
                        <p className="text-sm">{response.availability}</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium">Additional Notes</h4>
                        <p className="text-sm">{response.notes}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end gap-2 pt-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => handleContactSupplier(response)}
                >
                  Contact Supplier
                </Button>
                {response.status === 'new' && (
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handleStatusChange(response.id, 'reviewed')}
                  >
                    Mark as Reviewed
                  </Button>
                )}
                {response.status !== 'accepted' && response.status !== 'declined' && (
                  <>
                    <Button 
                      variant="default" 
                      size="sm"
                      onClick={() => handleAccept(response)}
                    >
                      Accept
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleDecline(response)}
                    >
                      Decline
                    </Button>
                  </>
                )}
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-8">
          <p className="text-muted-foreground">
            No responses match the selected filter
          </p>
        </div>
      )}
    </div>
  );
};

export default ResponsesList;
