
import { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Eye, Copy } from "lucide-react";
import { DateRange } from "react-day-picker";
import { toast } from "sonner";

// Mock data for history
const mockHistory = [
  {
    id: "bid1",
    title: "Annual Sales Conference",
    category: "conference",
    date: "2025-03-15",
    responses: 4,
    status: "completed"
  },
  {
    id: "bid2",
    title: "Team Retreat",
    category: "rooms",
    date: "2025-02-20",
    responses: 7,
    status: "completed"
  },
  {
    id: "bid3",
    title: "Product Launch Event",
    category: "conference",
    date: "2025-02-10",
    responses: 3,
    status: "expired"
  },
  {
    id: "bid4",
    title: "Executive Board Meeting",
    category: "rooms",
    date: "2025-01-15",
    responses: 5,
    status: "completed"
  },
  {
    id: "bid5",
    title: "Client Appreciation Dinner",
    category: "catering",
    date: "2025-01-05",
    responses: 2,
    status: "expired"
  },
];

interface HistoryListProps {
  searchQuery: string;
  dateRange: DateRange | undefined;
  category: string;
}

const HistoryList = ({ searchQuery, dateRange, category }: HistoryListProps) => {
  // Filter history data based on search query, date range, and category
  const filteredHistory = mockHistory
    .filter(item => 
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      searchQuery === ""
    )
    .filter(item => 
      category === "all" || item.category === category
    )
    .filter(item => {
      if (!dateRange?.from) return true;
      const itemDate = new Date(item.date);
      if (dateRange.to) {
        return itemDate >= dateRange.from && itemDate <= dateRange.to;
      }
      return itemDate >= dateRange.from;
    });
  
  const handleViewDetails = (bidId: string) => {
    // In a real app, navigate to the bid details page
    toast.info(`Viewing details for bid ${bidId}`);
  };
  
  const handleDuplicate = (bidId: string, title: string) => {
    // In a real app, create a new bid based on the existing one
    toast(`Duplicating bid: ${title}`, {
      description: "Creating a new bid request with the same details"
    });
  };
  
  return (
    <div>
      {filteredHistory.length > 0 ? (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Responses</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredHistory.map((item) => (
              <TableRow key={item.id}>
                <TableCell className="font-medium">{item.title}</TableCell>
                <TableCell>
                  <CategoryBadge category={item.category} />
                </TableCell>
                <TableCell>{item.date}</TableCell>
                <TableCell>{item.responses}</TableCell>
                <TableCell>
                  <StatusBadge status={item.status} />
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => handleViewDetails(item.id)}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => handleDuplicate(item.id, item.title)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      ) : (
        <div className="text-center py-8">
          <p className="text-muted-foreground">No history found</p>
        </div>
      )}
    </div>
  );
};

const CategoryBadge = ({ category }: { category: string }) => {
  switch (category) {
    case "rooms":
      return <Badge variant="outline" className="bg-blue-50 text-blue-600 hover:bg-blue-50">Accommodation</Badge>;
    case "conference":
      return <Badge variant="outline" className="bg-green-50 text-green-600 hover:bg-green-50">Conference</Badge>;
    case "restaurants":
      return <Badge variant="outline" className="bg-amber-50 text-amber-600 hover:bg-amber-50">Restaurant</Badge>;
    case "catering":
      return <Badge variant="outline" className="bg-purple-50 text-purple-600 hover:bg-purple-50">Catering</Badge>;
    default:
      return <Badge variant="outline">{category}</Badge>;
  }
};

const StatusBadge = ({ status }: { status: string }) => {
  switch (status) {
    case "active":
      return <Badge className="bg-blue-600">Active</Badge>;
    case "completed":
      return <Badge className="bg-green-600">Completed</Badge>;
    case "expired":
      return <Badge variant="outline" className="border-amber-500 text-amber-500">Expired</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

export default HistoryList;
