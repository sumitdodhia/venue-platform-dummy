
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, MessageSquare } from "lucide-react";
import ResponsesList from "./ResponsesList";
import { getEnquiry } from "@/services/enquiryService";
import { toast } from "sonner";

// Mock responses data for now
const mockResponses = [
  {
    id: "RESP-001",
    enquiryId: "ENQ-001",
    supplierName: "Grand Plaza Hotel",
    venueName: "Executive Conference Center",
    price: "$5,800",
    description: "Our Executive Conference Center is perfect for your needs. The package includes full AV setup, Wi-Fi, and a dedicated event coordinator.",
    status: "new",
    submittedDate: "2025-05-12",
    catering: "Full-day catering package with breakfast, lunch, and afternoon breaks",
    availability: "Available on your requested date",
    notes: "We can also offer a discounted room block if any attendees need overnight accommodations."
  },
  {
    id: "RESP-002",
    enquiryId: "ENQ-001",
    supplierName: "Business Center Downtown",
    venueName: "Panorama Conference Room",
    price: "$6,200",
    description: "Our top-floor conference room offers panoramic city views and state-of-the-art technology for your meeting needs.",
    status: "new",
    submittedDate: "2025-05-14",
    catering: "Premium catering options with customizable menu",
    availability: "Available on your requested date",
    notes: "We offer free parking for all attendees, which is rare in our downtown location."
  }
];

interface EnquiryDetailsProps {
  enquiryId?: string;
}

const EnquiryDetails = ({ enquiryId }: EnquiryDetailsProps) => {
  const [enquiry, setEnquiry] = useState<any>(null);
  const [responses, setResponses] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  
  useEffect(() => {
    const fetchEnquiryDetails = async () => {
      if (!enquiryId) {
        setError("No enquiry ID provided");
        setLoading(false);
        return;
      }
      
      try {
        setLoading(true);
        const result = await getEnquiry(enquiryId);
        
        if (result.success && result.data) {
          setEnquiry(result.data);
          
          // For now, use mock responses filtered by enquiry ID
          // In a real app, you would fetch responses from the API
          setResponses(mockResponses.filter(r => r.enquiryId === enquiryId));
        } else {
          setError(result.error || "Failed to fetch enquiry details");
          toast.error(result.error || "Failed to fetch enquiry details");
        }
      } catch (err: any) {
        setError(err.message || "An unexpected error occurred");
        toast.error(err.message || "An unexpected error occurred");
      } finally {
        setLoading(false);
      }
    };
    
    fetchEnquiryDetails();
  }, [enquiryId]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <p className="text-muted-foreground">Loading enquiry details...</p>
      </div>
    );
  }

  if (error || !enquiry) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <p className="text-muted-foreground mb-4">{error || "Enquiry not found"}</p>
        <Button onClick={() => navigate("/dashboard/enquiries")}>
          Back to Enquiries
        </Button>
      </div>
    );
  }

  // Transform the data from the database format to the display format
  const transformedEnquiry = {
    id: enquiry.id,
    title: enquiry.title,
    category: enquiry.category,
    description: enquiry.requirements || "No description provided",
    submittedDate: new Date(enquiry.created_at).toISOString().split('T')[0],
    dueDate: enquiry.deadline,
    status: enquiry.status,
    bidCount: responses.length,
    venue: {
      type: enquiry.category === "conference" ? "Conference Room" : 
            enquiry.category === "rooms" ? "Hotel Rooms" : 
            "Restaurant",
      capacity: enquiry.conference_enquiries?.[0]?.guests || 
               enquiry.room_enquiries?.[0]?.room_count || 
               "Not specified",
      date: enquiry.conference_enquiries?.[0]?.date || 
            (enquiry.room_enquiries?.[0]?.check_in_date + " to " + enquiry.room_enquiries?.[0]?.check_out_date) ||
            "Not specified",
      duration: enquiry.category === "conference" ? "Full day" : undefined,
      time: enquiry.category === "restaurants" ? "7:00 PM - 10:00 PM" : undefined,
      location: enquiry.room_enquiries?.[0]?.city + ", " + enquiry.room_enquiries?.[0]?.country || "Not specified",
      cuisinePreference: enquiry.category === "restaurants" ? "User preference" : undefined,
      budget: enquiry.budget || "Not specified"
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "new":
      case "active":
        return <Badge className="bg-green-500">Active</Badge>;
      case "closed":
        return <Badge variant="outline">Closed</Badge>;
      case "awarded":
        return <Badge className="bg-blue-500">Awarded</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => navigate("/dashboard/enquiries")}
          className="flex items-center gap-1"
        >
          <ArrowLeft className="h-4 w-4" /> Back
        </Button>
        <h1 className="text-2xl font-bold">{transformedEnquiry.title}</h1>
        {getStatusBadge(transformedEnquiry.status)}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Enquiry details */}
        <div className="md:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Enquiry Details</CardTitle>
              <CardDescription>
                Submitted on {transformedEnquiry.submittedDate}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-sm text-muted-foreground mb-2">DESCRIPTION</h3>
                  <p>{transformedEnquiry.description}</p>
                </div>
                
                <div>
                  <h3 className="font-semibold text-sm text-muted-foreground mb-2">VENUE REQUIREMENTS</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="font-medium">Type:</span>
                      <span>{transformedEnquiry.venue.type}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Capacity:</span>
                      <span>{transformedEnquiry.venue.capacity}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Date:</span>
                      <span>{transformedEnquiry.venue.date}</span>
                    </div>
                    {transformedEnquiry.venue.duration && (
                      <div className="flex justify-between">
                        <span className="font-medium">Duration:</span>
                        <span>{transformedEnquiry.venue.duration}</span>
                      </div>
                    )}
                    {transformedEnquiry.venue.time && (
                      <div className="flex justify-between">
                        <span className="font-medium">Time:</span>
                        <span>{transformedEnquiry.venue.time}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="font-medium">Location:</span>
                      <span>{transformedEnquiry.venue.location}</span>
                    </div>
                    {transformedEnquiry.venue.cuisinePreference && (
                      <div className="flex justify-between">
                        <span className="font-medium">Cuisine:</span>
                        <span>{transformedEnquiry.venue.cuisinePreference}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="font-medium">Budget:</span>
                      <span>{transformedEnquiry.venue.budget}</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-semibold text-sm text-muted-foreground mb-2">STATUS</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="font-medium">Bid Deadline:</span>
                      <span>{transformedEnquiry.dueDate}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Responses:</span>
                      <span>{transformedEnquiry.bidCount}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Responses section */}
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <MessageSquare className="h-5 w-5" /> Responses
                    <Badge variant="outline">{responses.length}</Badge>
                  </CardTitle>
                  <CardDescription>
                    Review and compare responses from venues
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {responses.length > 0 ? (
                <Tabs defaultValue="all">
                  <TabsList className="mb-4">
                    <TabsTrigger value="all">All</TabsTrigger>
                    <TabsTrigger value="new">New</TabsTrigger>
                    <TabsTrigger value="reviewed">Reviewed</TabsTrigger>
                    <TabsTrigger value="accepted">Accepted</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="all">
                    <ResponsesList responses={responses} />
                  </TabsContent>
                  
                  <TabsContent value="new">
                    <ResponsesList responses={responses.filter(r => r.status === 'new')} />
                  </TabsContent>
                  
                  <TabsContent value="reviewed">
                    <ResponsesList responses={responses.filter(r => r.status === 'reviewed')} />
                  </TabsContent>
                  
                  <TabsContent value="accepted">
                    <ResponsesList responses={responses.filter(r => r.status === 'accepted')} />
                  </TabsContent>
                </Tabs>
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">No responses received yet</p>
                  <p className="text-sm mt-2">Venues have until {transformedEnquiry.dueDate} to submit their offers</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default EnquiryDetails;
