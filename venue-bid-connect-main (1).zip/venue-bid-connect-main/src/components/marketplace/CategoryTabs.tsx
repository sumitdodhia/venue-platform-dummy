
import React from "react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { UtensilsCrossed, Hotel, Building2 } from "lucide-react";

export type CategoryType = "restaurants" | "rooms" | "conference";

interface CategoryTabsProps {
  activeCategory: CategoryType;
  onCategoryChange: (value: string) => void;
}

const CategoryTabs = ({ activeCategory, onCategoryChange }: CategoryTabsProps) => {
  return (
    <div className="flex justify-center mb-6">
      <TabsList className="grid grid-cols-1 md:grid-cols-3 gap-1 p-1 h-auto">
        <TabsTrigger value="restaurants" className="py-3 flex flex-col items-center gap-1.5">
          <UtensilsCrossed className="h-5 w-5" />
          <span>Restaurants</span>
        </TabsTrigger>
        <TabsTrigger value="rooms" className="py-3 flex flex-col items-center gap-1.5">
          <Hotel className="h-5 w-5" />
          <span>Rooms</span>
        </TabsTrigger>
        <TabsTrigger value="conference" className="py-3 flex flex-col items-center gap-1.5">
          <Building2 className="h-5 w-5" />
          <span>Conference</span>
        </TabsTrigger>
      </TabsList>
    </div>
  );
};

export default CategoryTabs;
