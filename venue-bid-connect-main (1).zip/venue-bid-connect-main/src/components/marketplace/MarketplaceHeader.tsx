
import React from "react";

interface MarketplaceHeaderProps {
  title: string;
  description: string;
}

const MarketplaceHeader = ({ title, description }: MarketplaceHeaderProps) => {
  return (
    <div className="max-w-3xl mx-auto mb-8 text-center">
      <h1 className="text-4xl font-bold mb-3 text-primary">{title}</h1>
      <p className="text-lg text-muted-foreground">{description}</p>
    </div>
  );
};

export default MarketplaceHeader;
