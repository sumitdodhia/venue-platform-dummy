
import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { TabsContent, Tabs } from "@/components/ui/tabs";
import EnquiryCategoryTabs, { EnquiryCategory } from "@/components/enquiry/EnquiryCategoryTabs";
import RoomsForm from "@/components/enquiry/RoomsForm";
import ConferenceForm from "@/components/enquiry/ConferenceForm";
import RestaurantsForm from "@/components/enquiry/RestaurantsForm";

interface InlineEnquiryFormProps {
  isOpen: boolean;
  onClose: () => void;
}

const InlineEnquiryForm = ({ isOpen, onClose }: InlineEnquiryFormProps) => {
  const [category, setCategory] = useState<EnquiryCategory>("rooms");

  const handleSubmitSuccess = () => {
    onClose();
  };

  const handleCategoryChange = (value: string) => {
    setCategory(value as EnquiryCategory);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Submit New Bid Request</DialogTitle>
          <DialogDescription>
            Submit your requirements and get competitive bids from verified suppliers
          </DialogDescription>
        </DialogHeader>

        <div className="mt-6">
          <Tabs value={category} className="space-y-6" onValueChange={handleCategoryChange}>
            <EnquiryCategoryTabs 
              category={category}
              onCategoryChange={handleCategoryChange}
            />
            
            <TabsContent value="rooms">
              <RoomsForm onSubmitSuccess={handleSubmitSuccess} />
            </TabsContent>
            
            <TabsContent value="conference">
              <ConferenceForm onSubmitSuccess={handleSubmitSuccess} />
            </TabsContent>
            
            <TabsContent value="restaurants">
              <RestaurantsForm onSubmitSuccess={handleSubmitSuccess} />
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default InlineEnquiryForm;
