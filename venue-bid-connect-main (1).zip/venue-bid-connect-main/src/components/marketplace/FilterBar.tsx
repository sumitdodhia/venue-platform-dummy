
import { FilterOptions, FilterValues } from "./filters/types";
import { CategoryType } from "./CategoryTabs";
import FilterLayout from "./filters/FilterLayout";

interface FilterBarProps {
  category: CategoryType;
  onFilterChange?: (filters: FilterValues) => void;
}

const FilterBar = ({ category, onFilterChange }: FilterBarProps) => {
  return <FilterLayout category={category} onFilterChange={onFilterChange} />;
};

export default FilterBar;
