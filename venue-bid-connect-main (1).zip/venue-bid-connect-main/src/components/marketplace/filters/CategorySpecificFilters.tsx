
import { CategoryType } from "../CategoryTabs";
import { CheckboxChangeHandler } from "./types";
import RoomsFilters from "./category-filters/RoomsFilters";
import ConferenceFilters from "./category-filters/ConferenceFilters";
import RestaurantFilters from "./category-filters/RestaurantFilters";

interface CategorySpecificFiltersProps {
  category: CategoryType;
  // Rooms filters
  roomType: string;
  setRoomType: (value: string) => void;
  mealPlan: string;
  setMealPlan: (value: string) => void;
  amenities: Record<string, boolean>;
  handleCheckboxChange: CheckboxChangeHandler;
  
  // Conference filters
  seatingLayout: string;
  setSeatingLayout: (value: string) => void;
  equipment: Record<string, boolean>;
  handleEquipmentChange: CheckboxChangeHandler;
  eventType: string;
  setEventType: (value: string) => void;
  startDate: Date | undefined;
  setStartDate: (date: Date | undefined) => void;
  endDate: Date | undefined;
  setEndDate: (date: Date | undefined) => void;
  
  // Restaurant filters
  cuisine: string;
  setCuisine: (value: string) => void;
  seatingType: string;
  setSeatingType: (value: string) => void;
  specialFeatures: Record<string, boolean>;
  handleSpecialFeaturesChange: CheckboxChangeHandler;
  
  // These props are still in the interface but will not be used
  setup: string;
  setSetup: (value: string) => void;
  cateringDuration: string;
  setCateringDuration: (value: string) => void;
  cateringAmenities: Record<string, boolean>;
  handleCateringAmenitiesChange: CheckboxChangeHandler;
}

const CategorySpecificFilters = ({
  category,
  roomType,
  setRoomType,
  mealPlan,
  setMealPlan,
  amenities,
  handleCheckboxChange,
  seatingLayout,
  setSeatingLayout,
  equipment,
  handleEquipmentChange,
  eventType,
  setEventType,
  startDate,
  setStartDate,
  endDate,
  setEndDate,
  cuisine,
  setCuisine,
  seatingType,
  setSeatingType,
  specialFeatures,
  handleSpecialFeaturesChange
}: CategorySpecificFiltersProps) => {
  switch (category) {
    case 'rooms':
      return (
        <RoomsFilters
          roomType={roomType}
          setRoomType={setRoomType}
          mealPlan={mealPlan}
          setMealPlan={setMealPlan}
          amenities={amenities}
          handleCheckboxChange={handleCheckboxChange}
        />
      );
    case 'conference':
      return (
        <ConferenceFilters
          seatingLayout={seatingLayout}
          setSeatingLayout={setSeatingLayout}
          equipment={equipment}
          handleEquipmentChange={handleEquipmentChange}
          eventType={eventType}
          setEventType={setEventType}
          startDate={startDate}
          setStartDate={setStartDate}
          endDate={endDate}
          setEndDate={setEndDate}
        />
      );
    case 'restaurants':
      return (
        <RestaurantFilters
          cuisine={cuisine}
          setCuisine={setCuisine}
          seatingType={seatingType}
          setSeatingType={setSeatingType}
          specialFeatures={specialFeatures}
          handleSpecialFeaturesChange={handleSpecialFeaturesChange}
        />
      );
    default:
      return null;
  }
};

export default CategorySpecificFilters;
