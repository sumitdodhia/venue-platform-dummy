
import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface MainFiltersProps {
  activeCategory: string;
  location: string;
  setLocation: (location: string) => void;
  checkInDate?: Date;
  setCheckInDate?: (date: Date) => void;
  checkOutDate?: Date;
  setCheckOutDate?: (date: Date) => void;
  capacity: number;
  setCapacity: (capacity: number) => void;
  priceRange: string;
  setPriceRange: (range: string) => void;
  minRooms: number;
  setMinRooms: (minRooms: number) => void;
  onFilterChange?: (filters: any) => void;
}

const MainFilters: React.FC<MainFiltersProps> = ({
  activeCategory,
  location,
  setLocation,
  checkInDate,
  setCheckInDate,
  checkOutDate,
  setCheckOutDate,
  capacity,
  setCapacity,
  priceRange,
  setPriceRange,
  minRooms,
  setMinRooms,
  onFilterChange
}) => {
  const handlePriceRangeChange = (range: string) => {
    setPriceRange(range);
    // Apply other filtering logic if needed
  };

  return (
    <div className="space-y-5">
      <div className="space-y-1">
        <Label className="text-xs opacity-70">Location</Label>
        <Input
          type="text"
          placeholder="City, address or venue"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
        />
      </div>

      {activeCategory === "rooms" && (
        <>
          <div className="space-y-1">
            <Label className="text-xs opacity-70">Check-in Date</Label>
            <Input
              type="date"
              value={checkInDate ? checkInDate.toISOString().split('T')[0] : ''}
              onChange={(e) => setCheckInDate && setCheckInDate(new Date(e.target.value))}
            />
          </div>

          <div className="space-y-1">
            <Label className="text-xs opacity-70">Check-out Date</Label>
            <Input
              type="date"
              value={checkOutDate ? checkOutDate.toISOString().split('T')[0] : ''}
              onChange={(e) => setCheckOutDate && setCheckOutDate(new Date(e.target.value))}
            />
          </div>

          <div className="space-y-1">
            <Label className="text-xs opacity-70">Minimum Rooms</Label>
            <Input
              type="number"
              min="1"
              value={minRooms}
              onChange={(e) => setMinRooms(Number(e.target.value))}
            />
          </div>
        </>
      )}

      <div className="space-y-1">
        <Label className="text-xs opacity-70">Capacity</Label>
        <Input
          type="number"
          min="1"
          value={capacity}
          onChange={(e) => setCapacity(Number(e.target.value))}
        />
      </div>
      
      <div className="space-y-1">
        <Label className="text-xs opacity-70">Price Range</Label>
        <Select
          value={priceRange}
          onValueChange={handlePriceRangeChange}
        >
          <SelectTrigger className="w-full">
            <SelectValue placeholder="Select price range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="economy">Economy</SelectItem>
            <SelectItem value="standard">Standard</SelectItem>
            <SelectItem value="premium">Premium</SelectItem>
            <SelectItem value="luxury">Luxury</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};

export default MainFilters;
