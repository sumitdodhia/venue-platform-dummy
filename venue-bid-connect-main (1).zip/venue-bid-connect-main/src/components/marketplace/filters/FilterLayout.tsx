import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Filter } from "lucide-react";
import { CategoryType } from "../CategoryTabs";
import { FilterValues } from "./types";
import MainFilters from "./MainFilters";
import CategorySpecificFilters from "./CategorySpecificFilters";

interface FilterLayoutProps {
  category: CategoryType;
  onFilterChange?: (filters: FilterValues) => void;
}

const FilterLayout = ({ category, onFilterChange }: FilterLayoutProps) => {
  const [location, setLocation] = useState("");
  const [checkInDate, setCheckInDate] = useState<Date>();
  const [checkOutDate, setCheckOutDate] = useState<Date>();
  const [capacity, setCapacity] = useState(2);
  const [priceRange, setPriceRange] = useState("");
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);
  const [minRooms, setMinRooms] = useState<number>(1);
  
  // Category-specific filter states
  const [roomType, setRoomType] = useState("any");
  const [mealPlan, setMealPlan] = useState("");
  const [amenities, setAmenities] = useState<Record<string, boolean>>({
    wifi: false,
    parking: false,
    pool: false,
  });
  
  // Conference-specific filter states
  const [seatingLayout, setSeatingLayout] = useState("");
  const [equipment, setEquipment] = useState<Record<string, boolean>>({
    projector: false,
    microphone: false,
    stage: false,
  });
  const [eventType, setEventType] = useState("full-day");
  const [startDate, setStartDate] = useState<Date>();
  const [endDate, setEndDate] = useState<Date>();
  
  // Restaurant-specific filter states
  const [cuisine, setCuisine] = useState("");
  const [seatingType, setSeatingType] = useState("");
  const [specialFeatures, setSpecialFeatures] = useState<Record<string, boolean>>({
    privateRoom: false,
    view: false,
    bar: false,
  });
  
  // Catering-specific filter states
  const [setup, setSetup] = useState("");
  const [cateringDuration, setCateringDuration] = useState("");
  const [cateringAmenities, setCateringAmenities] = useState<Record<string, boolean>>({
    whiteboard: false,
    videoConf: false,
    refreshments: false,
  });
  
  // Handle checkbox changes for amenities
  const handleCheckboxChange = (
    e: React.ChangeEvent<HTMLInputElement>, 
    setState: React.Dispatch<React.SetStateAction<Record<string, boolean>>>
  ) => {
    const { id, checked } = e.target;
    setState(prev => ({
      ...prev,
      [id]: checked
    }));
  };

  // Apply filters
  const handleApplyFilters = () => {
    // Create filter values object
    const filterValues: FilterValues = {
      location,
      capacity,
      priceRange
    };
    
    // Add date filters
    if (category === 'conference') {
      if (eventType === 'multi-day') {
        filterValues.startDate = startDate;
        filterValues.endDate = endDate;
        filterValues.eventType = eventType;
      } else {
        filterValues.eventDate = startDate;
        filterValues.eventType = eventType;
      }
    } else if (category === 'rooms') {
      filterValues.checkInDate = checkInDate;
      filterValues.checkOutDate = checkOutDate;
      filterValues.minRooms = minRooms;
    }
    
    // Add category-specific filters
    if (category === 'rooms') {
      if (roomType !== "any") {
        filterValues.roomType = roomType;
      }
      
      filterValues.mealPlan = mealPlan;
      filterValues.amenities = Object.keys(amenities).filter(key => amenities[key]);
    } else if (category === 'conference') {
      filterValues.seatingLayout = seatingLayout;
      filterValues.equipment = Object.keys(equipment).filter(key => equipment[key]);
    } else if (category === 'restaurants') {
      filterValues.cuisine = cuisine;
      filterValues.seatingType = seatingType;
      filterValues.specialFeatures = Object.keys(specialFeatures).filter(key => specialFeatures[key]);
    } else if (category === 'catering') {
      filterValues.setup = setup;
      filterValues.duration = cateringDuration;
      filterValues.amenities = Object.keys(cateringAmenities).filter(key => cateringAmenities[key]);
    }
    
    // Call the onFilterChange callback if provided
    if (onFilterChange) {
      onFilterChange(filterValues);
    }
  };
  
  return (
    <Card className="bg-white rounded-lg shadow-sm border p-0 overflow-hidden">
      <div className="flex flex-col lg:flex-row">
        {/* Sidebar Filters */}
        <div className="lg:w-64 border-r p-4 bg-gray-50">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium flex items-center gap-2">
              <Filter className="h-4 w-4" />
              Search & Filters
            </h3>
            <Button 
              variant="link" 
              className="lg:hidden text-sm p-0 h-auto"
              onClick={() => setIsFiltersOpen(!isFiltersOpen)}
            >
              {isFiltersOpen ? "Hide" : "Show"} Filters
            </Button>
          </div>
          
          <div className={`space-y-5 ${isFiltersOpen ? 'block' : 'hidden lg:block'}`}>
            <MainFilters 
              activeCategory={category}
              location={location}
              setLocation={setLocation}
              checkInDate={checkInDate}
              setCheckInDate={setCheckInDate}
              checkOutDate={checkOutDate}
              setCheckOutDate={setCheckOutDate}
              capacity={capacity}
              setCapacity={setCapacity}
              priceRange={priceRange}
              setPriceRange={setPriceRange}
              minRooms={minRooms}
              setMinRooms={setMinRooms}
              onFilterChange={value => {
                if (onFilterChange) onFilterChange(value as any);
              }}
            />

            <CategorySpecificFilters
              category={category}
              roomType={roomType}
              setRoomType={setRoomType}
              mealPlan={mealPlan}
              setMealPlan={setMealPlan}
              amenities={amenities}
              handleCheckboxChange={(e) => handleCheckboxChange(e, setAmenities)}
              seatingLayout={seatingLayout}
              setSeatingLayout={setSeatingLayout}
              equipment={equipment}
              handleEquipmentChange={(e) => handleCheckboxChange(e, setEquipment)}
              eventType={eventType}
              setEventType={setEventType}
              startDate={startDate}
              setStartDate={setStartDate}
              endDate={endDate}
              setEndDate={setEndDate}
              cuisine={cuisine}
              setCuisine={setCuisine}
              seatingType={seatingType}
              setSeatingType={setSeatingType}
              specialFeatures={specialFeatures}
              handleSpecialFeaturesChange={(e) => handleCheckboxChange(e, setSpecialFeatures)}
              setup={setup}
              setSetup={setSetup}
              cateringDuration={cateringDuration}
              setCateringDuration={setCateringDuration}
              cateringAmenities={cateringAmenities}
              handleCateringAmenitiesChange={(e) => handleCheckboxChange(e, setCateringAmenities)}
            />
            
            <Button 
              className="w-full mt-6"
              onClick={handleApplyFilters}
            >
              Apply Filters
            </Button>
          </div>
        </div>
        
        {/* Main content area - This will be empty as the content is rendered in Marketplace.tsx */}
        <div className="flex-1 p-0"></div>
      </div>
    </Card>
  );
};

export default FilterLayout;
