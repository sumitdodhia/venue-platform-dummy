
import { Venue, RoomVenue, ConferenceVenue, RestaurantVenue } from "@/types/venue";
import { CategoryType } from "../CategoryTabs";
import React, { ChangeEventHandler, ChangeEvent } from "react";

export interface FilterOptions {
  category: 'rooms' | 'conference' | 'restaurants';
  priceRange: [number, number];
  rating: number;
  location: string;
  // Category specific filters
  capacity?: number;
  dates?: {
    start: Date | null;
    end: Date | null;
  };
  cuisineType?: string;
  roomType?: string;
}

export interface FilterBarProps {
  activeCategory: 'rooms' | 'conference' | 'restaurants';
  onFilterChange: (filters: FilterOptions) => void;
}

// Updated CheckboxChangeHandler type to be compatible with ChangeEventHandler
export type CheckboxChangeHandler = ChangeEventHandler<HTMLInputElement>;

// Add the missing FilterValues type
export interface FilterValues {
  location?: string;
  capacity?: number;
  priceRange?: string;
  minRooms?: number;
  checkInDate?: Date;
  checkOutDate?: Date;
  roomType?: string;
  mealPlan?: string;
  amenities?: string[];
  seatingLayout?: string;
  equipment?: string[];
  eventType?: string;
  eventDate?: Date;
  startDate?: Date;
  endDate?: Date;
  cuisine?: string;
  seatingType?: string;
  specialFeatures?: string[];
  setup?: string;
  duration?: string;
}

// Add the missing roomTypeOptions
export const roomTypeOptions = [
  "",
  "Single",
  "Double",
  "Twin",
  "Suite",
  "Executive",
  "Family"
];
