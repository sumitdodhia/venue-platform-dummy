
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckboxChangeHandler, roomTypeOptions } from "../types";

interface RoomsFiltersProps {
  roomType: string;
  setRoomType: (value: string) => void;
  mealPlan: string;
  setMealPlan: (value: string) => void;
  amenities: Record<string, boolean>;
  handleCheckboxChange: CheckboxChangeHandler;
}

const RoomsFilters = ({
  roomType,
  setRoomType,
  mealPlan,
  setMealPlan,
  amenities,
  handleCheckboxChange
}: RoomsFiltersProps) => {
  return (
    <div className="space-y-4">
      <div>
        <Label>Room Type</Label>
        <Select 
          value={roomType}
          onValueChange={setRoomType}
        >
          <SelectTrigger className="mt-2">
            <SelectValue placeholder="Any Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="any">Any Type</SelectItem>
            {roomTypeOptions.filter(type => type !== "").map((type) => (
              <SelectItem key={type} value={type}>
                {type}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label>Meal Plan</Label>
        <select 
          className="w-full mt-2 rounded-md border border-input bg-background px-3 py-2 text-sm"
          value={mealPlan}
          onChange={(e) => setMealPlan(e.target.value)}
        >
          <option value="">Any Plan</option>
          <option value="room-only">Room Only</option>
          <option value="bb">Bed & Breakfast</option>
          <option value="half-board">Half Board</option>
          <option value="full-board">Full Board</option>
        </select>
      </div>
      <div>
        <Label>Amenities</Label>
        <div className="mt-2 space-y-2">
          <div className="flex items-center">
            <input 
              type="checkbox" 
              id="wifi" 
              className="mr-2"
              checked={amenities.wifi}
              onChange={handleCheckboxChange}
            />
            <label htmlFor="wifi" className="text-sm">WiFi</label>
          </div>
          <div className="flex items-center">
            <input 
              type="checkbox" 
              id="parking" 
              className="mr-2"
              checked={amenities.parking}
              onChange={handleCheckboxChange}
            />
            <label htmlFor="parking" className="text-sm">Parking</label>
          </div>
          <div className="flex items-center">
            <input 
              type="checkbox" 
              id="pool" 
              className="mr-2"
              checked={amenities.pool}
              onChange={handleCheckboxChange}
            />
            <label htmlFor="pool" className="text-sm">Pool</label>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RoomsFilters;
