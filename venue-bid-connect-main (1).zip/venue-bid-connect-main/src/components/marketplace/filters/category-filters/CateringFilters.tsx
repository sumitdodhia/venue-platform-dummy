
import { Label } from "@/components/ui/label";
import { CheckboxChangeHandler } from "../types";

interface CateringFiltersProps {
  setup: string;
  setSetup: (value: string) => void;
  cateringDuration: string;
  setCateringDuration: (value: string) => void;
  cateringAmenities: Record<string, boolean>;
  handleCateringAmenitiesChange: CheckboxChangeHandler;
}

const CateringFilters = ({
  setup,
  setSetup,
  cateringDuration,
  setCateringDuration,
  cateringAmenities,
  handleCateringAmenitiesChange
}: CateringFiltersProps) => {
  return (
    <div className="space-y-4">
      <div>
        <Label>Setup</Label>
        <select 
          className="w-full mt-2 rounded-md border border-input bg-background px-3 py-2 text-sm"
          value={setup}
          onChange={(e) => setSetup(e.target.value)}
        >
          <option value="">Any Setup</option>
          <option value="boardroom">Boardroom</option>
          <option value="u-shape">U-Shape</option>
          <option value="classroom">Classroom</option>
        </select>
      </div>
      <div>
        <Label>Duration</Label>
        <select 
          className="w-full mt-2 rounded-md border border-input bg-background px-3 py-2 text-sm"
          value={cateringDuration}
          onChange={(e) => setCateringDuration(e.target.value)}
        >
          <option value="">Any Duration</option>
          <option value="hourly">Hourly</option>
          <option value="half-day">Half Day</option>
          <option value="full-day">Full Day</option>
        </select>
      </div>
      <div>
        <Label>Amenities</Label>
        <div className="mt-2 space-y-2">
          <div className="flex items-center">
            <input 
              type="checkbox" 
              id="whiteboard" 
              className="mr-2"
              checked={cateringAmenities.whiteboard}
              onChange={handleCateringAmenitiesChange}
            />
            <label htmlFor="whiteboard" className="text-sm">Whiteboard</label>
          </div>
          <div className="flex items-center">
            <input 
              type="checkbox" 
              id="videoConf" 
              className="mr-2"
              checked={cateringAmenities.videoConf}
              onChange={handleCateringAmenitiesChange}
            />
            <label htmlFor="videoConf" className="text-sm">Video Conferencing</label>
          </div>
          <div className="flex items-center">
            <input 
              type="checkbox" 
              id="refreshments" 
              className="mr-2"
              checked={cateringAmenities.refreshments}
              onChange={handleCateringAmenitiesChange}
            />
            <label htmlFor="refreshments" className="text-sm">Refreshments</label>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CateringFilters;
