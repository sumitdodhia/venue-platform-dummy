
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { format } from "date-fns";
import { CalendarIcon } from "lucide-react";
import { CheckboxChangeHandler } from "../types";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

interface ConferenceFiltersProps {
  seatingLayout: string;
  setSeatingLayout: (value: string) => void;
  equipment: Record<string, boolean>;
  handleEquipmentChange: CheckboxChangeHandler;
  eventType: string;
  setEventType: (value: string) => void;
  startDate: Date | undefined;
  setStartDate: (date: Date | undefined) => void;
  endDate: Date | undefined;
  setEndDate: (date: Date | undefined) => void;
}

const ConferenceFilters = ({
  seatingLayout,
  setSeatingLayout,
  equipment,
  handleEquipmentChange,
  eventType,
  setEventType,
  startDate,
  setStartDate,
  endDate,
  setEndDate
}: ConferenceFiltersProps) => {
  return (
    <div className="space-y-4">
      <div>
        <Label>Event Duration</Label>
        <RadioGroup 
          value={eventType} 
          onValueChange={setEventType} 
          className="mt-2 space-y-1"
        >
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="half-day-am" id="half-day-am" />
            <Label htmlFor="half-day-am" className="text-sm font-normal">Half Day (AM)</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="half-day-pm" id="half-day-pm" />
            <Label htmlFor="half-day-pm" className="text-sm font-normal">Half Day (PM)</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="full-day" id="full-day" />
            <Label htmlFor="full-day" className="text-sm font-normal">Full Day</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="multi-day" id="multi-day" />
            <Label htmlFor="multi-day" className="text-sm font-normal">Multi Day</Label>
          </div>
        </RadioGroup>
      </div>

      {/* Date Selection */}
      {eventType === 'multi-day' ? (
        <div className="space-y-2">
          <Label>Date Range</Label>
          <div className="grid grid-cols-2 gap-2 mt-2">
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal text-sm"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {startDate ? format(startDate, "MMM d") : <span>Start Date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0 pointer-events-auto" align="start">
                <Calendar
                  mode="single"
                  selected={startDate}
                  onSelect={setStartDate}
                  initialFocus
                  className="p-3 pointer-events-auto"
                />
              </PopoverContent>
            </Popover>

            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal text-sm"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {endDate ? format(endDate, "MMM d") : <span>End Date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0 pointer-events-auto" align="start">
                <Calendar
                  mode="single"
                  selected={endDate}
                  onSelect={setEndDate}
                  disabled={date => startDate ? date < startDate : false}
                  initialFocus
                  className="p-3 pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>
      ) : (
        <div>
          <Label>Date</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className="w-full justify-start text-left font-normal mt-2"
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {startDate ? format(startDate, "PPP") : <span>Pick a date</span>}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0 pointer-events-auto" align="start">
              <Calendar
                mode="single"
                selected={startDate}
                onSelect={setStartDate}
                initialFocus
                className="p-3 pointer-events-auto"
              />
            </PopoverContent>
          </Popover>
        </div>
      )}

      {/* Seating Layout */}
      <div>
        <Label>Seating Layout</Label>
        <select 
          className="w-full mt-2 rounded-md border border-input bg-background px-3 py-2 text-sm"
          value={seatingLayout}
          onChange={(e) => setSeatingLayout(e.target.value)}
        >
          <option value="">Any Layout</option>
          <option value="theater">Theater</option>
          <option value="classroom">Classroom</option>
          <option value="banquet">Banquet</option>
          <option value="reception">Reception</option>
        </select>
      </div>
      
      {/* Equipment */}
      <div>
        <Label>Requirements (Must Have)</Label>
        <div className="mt-2 space-y-2">
          <div className="flex items-center">
            <input 
              type="checkbox" 
              id="projector" 
              className="mr-2"
              checked={equipment.projector}
              onChange={handleEquipmentChange}
            />
            <label htmlFor="projector" className="text-sm">Projector</label>
          </div>
          <div className="flex items-center">
            <input 
              type="checkbox" 
              id="microphone" 
              className="mr-2"
              checked={equipment.microphone}
              onChange={handleEquipmentChange}
            />
            <label htmlFor="microphone" className="text-sm">Microphone</label>
          </div>
          <div className="flex items-center">
            <input 
              type="checkbox" 
              id="stage" 
              className="mr-2"
              checked={equipment.stage}
              onChange={handleEquipmentChange}
            />
            <label htmlFor="stage" className="text-sm">Stage</label>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConferenceFilters;
