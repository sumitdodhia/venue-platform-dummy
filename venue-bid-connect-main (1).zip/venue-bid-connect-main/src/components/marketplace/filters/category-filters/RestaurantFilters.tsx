
import { Label } from "@/components/ui/label";
import { CheckboxChangeHandler } from "../types";

interface RestaurantFiltersProps {
  cuisine: string;
  setCuisine: (value: string) => void;
  seatingType: string;
  setSeatingType: (value: string) => void;
  specialFeatures: Record<string, boolean>;
  handleSpecialFeaturesChange: CheckboxChangeHandler;
}

const RestaurantFilters = ({
  cuisine,
  setCuisine,
  seatingType,
  setSeatingType,
  specialFeatures,
  handleSpecialFeaturesChange
}: RestaurantFiltersProps) => {
  return (
    <div className="space-y-4">
      <div>
        <Label>Cuisine</Label>
        <select 
          className="w-full mt-2 rounded-md border border-input bg-background px-3 py-2 text-sm"
          value={cuisine}
          onChange={(e) => setCuisine(e.target.value)}
        >
          <option value="">Any Cuisine</option>
          <option value="italian">Italian</option>
          <option value="japanese">Japanese</option>
          <option value="chinese">Chinese</option>
          <option value="french">French</option>
          <option value="spanish">Spanish</option>
          <option value="steakhouse">Steakhouse</option>
          <option value="continental">Continental</option>
          <option value="mediterranean">Mediterranean</option>
          <option value="indian">Indian</option>
          <option value="mexican">Mexican</option>
          <option value="thai">Thai</option>
          <option value="international">International</option>
        </select>
      </div>
      <div>
        <Label>Seating Type</Label>
        <select 
          className="w-full mt-2 rounded-md border border-input bg-background px-3 py-2 text-sm"
          value={seatingType}
          onChange={(e) => setSeatingType(e.target.value)}
        >
          <option value="">Any Type</option>
          <option value="indoor">Indoor</option>
          <option value="outdoor">Outdoor</option>
          <option value="both">Both</option>
        </select>
      </div>
      <div>
        <Label>Special Features</Label>
        <div className="mt-2 space-y-2">
          <div className="flex items-center">
            <input 
              type="checkbox" 
              id="privateRoom" 
              className="mr-2"
              checked={specialFeatures.privateRoom}
              onChange={handleSpecialFeaturesChange}
            />
            <label htmlFor="privateRoom" className="text-sm">Private Room</label>
          </div>
          <div className="flex items-center">
            <input 
              type="checkbox" 
              id="view" 
              className="mr-2"
              checked={specialFeatures.view}
              onChange={handleSpecialFeaturesChange}
            />
            <label htmlFor="view" className="text-sm">View</label>
          </div>
          <div className="flex items-center">
            <input 
              type="checkbox" 
              id="bar" 
              className="mr-2"
              checked={specialFeatures.bar}
              onChange={handleSpecialFeaturesChange}
            />
            <label htmlFor="bar" className="text-sm">Bar</label>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RestaurantFilters;
