
import { useState } from "react";
import { Tabs, TabsContent } from "@/components/ui/tabs";
import FilterBar from "./FilterBar";
import { useVenueFiltering } from "@/hooks/useVenueFiltering";
import CategoryTabs, { CategoryType } from "./CategoryTabs";
import MarketplaceHeader from "./MarketplaceHeader";
import CategoryHeading from "./CategoryHeading";
import VenueGrid from "./VenueGrid";

const Marketplace = () => {
  const [activeCategory, setActiveCategory] = useState<CategoryType>("restaurants");
  const { filteredVenues, handleFilterChange } = useVenueFiltering(activeCategory);
  
  const handleCategoryChange = (value: string) => {
    setActiveCategory(value as CategoryType);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <MarketplaceHeader 
        title="FindToTable Marketplace"
        description="Discover and book the perfect venues for your business needs"
      />
      
      <Tabs defaultValue={activeCategory} onValueChange={handleCategoryChange} className="space-y-8">
        <CategoryTabs 
          activeCategory={activeCategory} 
          onCategoryChange={handleCategoryChange} 
        />

        <CategoryHeading category={activeCategory} />
        
        <div className="lg:flex gap-6">
          {/* FilterBar will be a sidebar on large screens */}
          <div className="lg:w-1/4 lg:flex-shrink-0 mb-6 lg:mb-0">
            <FilterBar 
              category={activeCategory}
              onFilterChange={handleFilterChange} 
            />
          </div>
          
          {/* Content for each tab */}
          <div className="lg:w-3/4">
            <TabsContent value="restaurants" className="mt-0 animate-fade-in">
              <VenueGrid venues={filteredVenues} category={activeCategory} />
            </TabsContent>
            
            <TabsContent value="rooms" className="mt-0 animate-fade-in">
              <VenueGrid venues={filteredVenues} category={activeCategory} />
            </TabsContent>
            
            <TabsContent value="conference" className="mt-0 animate-fade-in">
              <VenueGrid venues={filteredVenues} category={activeCategory} />
            </TabsContent>
          </div>
        </div>
      </Tabs>
    </div>
  );
};

export default Marketplace;
