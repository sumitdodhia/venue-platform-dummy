
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { Badge } from "@/components/ui/badge";
import { Star } from "lucide-react";

interface VenueCardImageProps {
  imageUrl: string;
  title: string;
  category: string;
  rating: number;
}

const VenueCardImage = ({ imageUrl, title, category, rating }: VenueCardImageProps) => {
  const getCategoryLabel = () => {
    switch (category) {
      case 'rooms':
        return 'Room';
      case 'conference':
        return 'Conference Venue';
      case 'restaurants':
        return 'Restaurant';
      case 'catering':
        return 'Catering Service';
      default:
        return 'Venue';
    }
  };

  return (
    <div className="relative">
      <AspectRatio ratio={16/9}>
        <img 
          src={imageUrl} 
          alt={title}
          className="object-cover w-full h-full transition-transform duration-500 hover:scale-105"
        />
      </AspectRatio>
      <Badge className="absolute top-2 right-2" variant="secondary">
        {getCategoryLabel()}
      </Badge>
      {rating > 0 && (
        <div className="absolute bottom-2 left-2 bg-black/70 text-white px-2 py-1 rounded-md text-xs flex items-center">
          <Star className="h-3 w-3 mr-1 fill-yellow-400 text-yellow-400" />
          <span>{rating.toFixed(1)}</span>
        </div>
      )}
    </div>
  );
};

export default VenueCardImage;
