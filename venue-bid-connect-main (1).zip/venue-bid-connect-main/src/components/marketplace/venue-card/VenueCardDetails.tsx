
import { Badge } from "@/components/ui/badge";
import { Building, MapPin, Users } from "lucide-react";

interface VenueCardDetailsProps {
  title: string;
  location: string;
  category: string;
  totalRooms?: number;
  capacity?: number;
  basisOffered?: string[];
  tags: string[];
  facilities?: string[];
  totalReviews?: number;
  categoryIcon?: React.ReactNode;
}

const VenueCardDetails = ({ 
  title,
  location,
  category,
  totalRooms = 0,
  capacity = 0,
  basisOffered = [],
  tags,
  facilities = [],
  totalReviews = 0,
  categoryIcon
}: VenueCardDetailsProps) => {
  return (
    <div className="p-4 flex flex-col gap-2">
      <h3 className="font-semibold line-clamp-1">{title}</h3>
      
      <div className="flex items-start gap-1 text-sm text-muted-foreground">
        <MapPin className="h-3.5 w-3.5 mt-0.5 flex-shrink-0" />
        <span className="line-clamp-1">{location}</span>
      </div>
      
      {category === 'conference' && (
        <>
          {capacity > 0 && (
            <div className="flex items-start gap-1 text-sm text-muted-foreground">
              <Users className="h-3.5 w-3.5 mt-0.5 flex-shrink-0" />
              <span>Capacity: {capacity} people</span>
            </div>
          )}
          
          {facilities && facilities.length > 0 && (
            <div className="flex flex-col gap-1 mt-2">
              <span className="text-sm font-medium">Facilities:</span>
              <div className="flex flex-wrap gap-1 mt-1">
                {facilities.slice(0, 3).map((facility, index) => (
                  <Badge key={index} variant="outline" className="text-xs bg-primary/5">
                    {facility}
                  </Badge>
                ))}
                {facilities.length > 3 && (
                  <Badge variant="outline" className="text-xs bg-primary/5">
                    +{facilities.length - 3} more
                  </Badge>
                )}
              </div>
            </div>
          )}
        </>
      )}
      
      {category === 'rooms' && (
        <>
          {totalRooms > 0 && (
            <div className="flex items-start gap-1 text-sm text-muted-foreground">
              <Building className="h-3.5 w-3.5 mt-0.5 flex-shrink-0" />
              <span>{totalRooms} {totalRooms === 1 ? 'room' : 'rooms'} available</span>
            </div>
          )}

          {basisOffered && basisOffered.length > 0 && (
            <div className="text-sm text-muted-foreground line-clamp-1">
              {basisOffered.join(', ')}
            </div>
          )}
        </>
      )}
      
      {/* For restaurants and other categories */}
      {category !== 'conference' && category !== 'rooms' && tags.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-1">
          {tags.slice(0, 3).map((tag, index) => (
            <Badge key={index} variant="outline" className="text-xs bg-primary/5">
              {tag}
            </Badge>
          ))}
          {tags.length > 3 && (
            <Badge variant="outline" className="text-xs bg-primary/5">
              +{tags.length - 3} more
            </Badge>
          )}
        </div>
      )}
      
      {totalReviews > 0 && (
        <div className="text-xs text-muted-foreground mt-1">
          {totalReviews} {totalReviews === 1 ? 'review' : 'reviews'}
        </div>
      )}
    </div>
  );
};

export default VenueCardDetails;
