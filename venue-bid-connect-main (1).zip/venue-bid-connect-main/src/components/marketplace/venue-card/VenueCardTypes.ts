
import { CategoryType } from "../CategoryTabs";

export interface VenueCardProps {
  id: string;
  title: string;
  location: string;
  price: number;
  priceLabel: string;
  rating: number;
  imageUrl: string;
  tags: string[];
  category: string;
  basisOffered?: string[];
  totalRooms?: number;
  totalReviews?: number;
  googleLocation?: string;
  capacity?: number;
  facilities?: string[];
}
