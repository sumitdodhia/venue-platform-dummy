
import React from "react";
import { useNavigate } from "react-router-dom";
import { Building2, UtensilsCrossed, Hotel } from "lucide-react";
import { Button } from "@/components/ui/button";
import VenueCardImage from "./VenueCardImage";
import VenueCardDetails from "./VenueCardDetails";
import VenueCardPrice from "./VenueCardPrice";
import { VenueCardProps } from "./VenueCardTypes";

const VenueCard = ({
  id,
  title,
  location,
  price,
  priceLabel,
  rating,
  imageUrl,
  tags,
  category,
  totalRooms,
  basisOffered,
  facilities,
  totalReviews,
  capacity,
}: VenueCardProps) => {
  const navigate = useNavigate();

  const handleViewDetails = () => {
    // Use the correct route for venue details
    navigate(`/venues/${id}`);
    console.log("Navigating to venue:", id);
  };

  // Get icon based on category
  const renderCategoryIcon = () => {
    switch (category) {
      case "rooms":
        return <Hotel className="h-4 w-4" />;
      case "conference":
        return <Building2 className="h-4 w-4" />;
      case "restaurants":
        return <UtensilsCrossed className="h-4 w-4" />;
      default:
        return null;
    }
  };

  return (
    <div className="bg-card rounded-lg border overflow-hidden h-full flex flex-col">
      <VenueCardImage 
        imageUrl={imageUrl} 
        title={title} 
        category={category} 
        rating={rating} 
      />
      
      <VenueCardDetails
        title={title}
        location={location}
        category={category}
        tags={tags}
        facilities={facilities}
        totalRooms={totalRooms}
        basisOffered={basisOffered}
        capacity={capacity}
        totalReviews={totalReviews}
        categoryIcon={renderCategoryIcon()}
      />
      
      <div className="p-4 mt-auto border-t">
        <div className="flex items-center justify-between mb-4">
          <VenueCardPrice price={price} priceLabel={priceLabel} />
        </div>
        
        <Button 
          onClick={handleViewDetails}
          className="w-full"
        >
          View Details
        </Button>
      </div>
    </div>
  );
};

export default VenueCard;
