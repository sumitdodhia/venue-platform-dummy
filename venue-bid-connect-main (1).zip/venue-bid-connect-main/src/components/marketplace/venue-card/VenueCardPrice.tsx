
interface VenueCardPriceProps {
  price: number;
  priceLabel: string;
}

const VenueCardPrice = ({ price, priceLabel }: VenueCardPriceProps) => {
  return (
    <div>
      <p className="text-xs text-muted-foreground">Indicative pricing</p>
      <div className="flex items-baseline">
        <span className="font-semibold text-lg">From ${price}</span>
        <span className="text-sm text-muted-foreground ml-1">{priceLabel}</span>
      </div>
    </div>
  );
};

export default VenueCardPrice;
