
import { Star, MapPin } from "lucide-react";

interface VenueCardHeaderProps {
  title: string;
  location: string;
  rating: number;
  totalReviews?: number;
  googleLocation?: string;
  onLocationClick: (e: React.MouseEvent) => void;
}

const VenueCardHeader = ({ 
  title, 
  location, 
  rating, 
  totalReviews = 0, 
  googleLocation,
  onLocationClick
}: VenueCardHeaderProps) => {
  return (
    <>
      <div className="flex justify-between items-start">
        <h3 className="font-semibold text-lg line-clamp-1">{title}</h3>
        <div className="flex items-center bg-yellow-100 text-yellow-800 text-xs font-semibold px-1.5 py-0.5 rounded">
          <Star className="w-3 h-3 mr-0.5 fill-yellow-500 stroke-yellow-500" />
          <span>{rating}</span>
          {totalReviews > 0 && <span className="text-xs ml-1">({totalReviews})</span>}
        </div>
      </div>
      
      <div className="flex items-start gap-1 text-sm text-muted-foreground">
        <MapPin className="h-3.5 w-3.5 mt-0.5 flex-shrink-0" />
        {googleLocation ? (
          <a 
            href={googleLocation} 
            target="_blank" 
            rel="noopener noreferrer"
            onClick={onLocationClick}
            className="line-clamp-1 hover:underline hover:text-primary transition-colors"
          >
            {location}
          </a>
        ) : (
          <span className="line-clamp-1">{location}</span>
        )}
      </div>
    </>
  );
};

export default VenueCardHeader;
