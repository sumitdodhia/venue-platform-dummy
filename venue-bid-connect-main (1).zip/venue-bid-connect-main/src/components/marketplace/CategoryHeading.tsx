
import React from "react";
import { CategoryType } from "./CategoryTabs";

interface CategoryHeadingProps {
  category: CategoryType;
}

const CategoryHeading = ({ category }: CategoryHeadingProps) => {
  const getCategoryTitle = () => {
    switch (category) {
      case "rooms":
        return "Hotel Rooms & Accommodations";
      case "conference":
        return "Conference & Event Spaces";
      case "restaurants":
        return "Restaurants & Dining Venues";
      default:
        return "";
    }
  };
  
  const getCategoryDescription = () => {
    switch (category) {
      case "rooms":
        return "Find and book hotel rooms for your business trip, event, or leisure stay.";
      case "conference":
        return "Discover perfect venues for conferences, workshops, and large events.";
      case "restaurants":
        return "Book restaurants for team dinners, client meetings, or special occasions.";
      default:
        return "";
    }
  };

  return (
    <div className="bg-gradient-to-r from-primary/5 to-primary/10 rounded-lg p-8 mb-6 text-center">
      <h1 className="text-3xl font-bold mb-2">{getCategoryTitle()}</h1>
      <p className="text-center text-muted-foreground max-w-2xl mx-auto">
        {getCategoryDescription()}
      </p>
    </div>
  );
};

export default CategoryHeading;
