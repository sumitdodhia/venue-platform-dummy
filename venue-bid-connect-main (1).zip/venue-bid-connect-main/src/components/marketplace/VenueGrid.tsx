
import React from "react";
import VenueCard from "./venue-card/VenueCard";
import { CategoryType } from "./CategoryTabs";
import { AlertCircle } from "lucide-react";
import { Venue } from "@/types/venue";

interface VenueGridProps {
  venues: Venue[];
  category: CategoryType;
}

const VenueGrid = ({ venues, category }: VenueGridProps) => {
  // Create friendly category names for empty state messages
  const getCategoryName = (cat: CategoryType): string => {
    switch (cat) {
      case "rooms": return "hotel rooms";
      case "conference": return "conference venues";
      case "restaurants": return "restaurants";
      default: return "venues";
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
      {venues.length > 0 ? (
        venues.map(venue => (
          <VenueCard 
            key={venue.id}
            id={venue.id}
            title={venue.title}
            location={venue.location}
            price={venue.price}
            priceLabel={venue.priceLabel}
            rating={venue.rating}
            imageUrl={venue.imageUrl}
            tags={venue.tags}
            category={venue.category}
            basisOffered={(venue as any).basisOffered}
            totalRooms={(venue as any).totalRooms}
            totalReviews={venue.totalReviews}
            googleLocation={venue.googleLocation}
            capacity={(venue as any).capacity}
            facilities={venue.facilities}
          />
        ))
      ) : (
        <div className="col-span-full flex flex-col items-center justify-center py-16 px-4 text-center">
          <div className="bg-muted/30 rounded-full p-3 mb-4">
            <AlertCircle className="h-6 w-6 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-medium mb-2">No {getCategoryName(category)} found</h3>
          <p className="text-muted-foreground max-w-md">
            {category === 'rooms' ? (
              <>No hotel rooms match your current filters or are available in our database.</>
            ) : category === 'conference' ? (
              <>No conference venues match your current filters or are available in our database.</>
            ) : (
              <>No restaurants match your current filters or are available in our database.</>
            )}
          </p>
        </div>
      )}
    </div>
  );
};

export default VenueGrid;
