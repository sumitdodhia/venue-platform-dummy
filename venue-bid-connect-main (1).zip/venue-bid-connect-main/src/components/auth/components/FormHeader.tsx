
import React from "react";

interface FormHeaderProps {
  title: string;
  description: string;
  children?: React.ReactNode;
}

const FormHeader = ({ title, description, children }: FormHeaderProps) => {
  return (
    <div className="text-center">
      <h1 className="text-2xl font-bold">{title}</h1>
      <p className="text-sm text-muted-foreground mt-1">
        {description}
      </p>
      {children}
    </div>
  );
};

export default FormHeader;
