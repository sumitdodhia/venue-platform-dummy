
import { Link } from "react-router-dom";

interface FormFooterProps {
  text: string;
  linkText: string;
  linkUrl: string;
  additionalText?: string;
}

const FormFooter = ({ text, linkText, linkUrl, additionalText }: FormFooterProps) => {
  return (
    <div className="text-center text-sm">
      <p className="text-muted-foreground">
        {text}{" "}
        <Link to={linkUrl} className="text-primary hover:underline">
          {linkText}
        </Link>
      </p>
      {additionalText && (
        <p className="text-xs text-muted-foreground mt-2">
          {additionalText}
        </p>
      )}
    </div>
  );
};

export default FormFooter;
