
import { Button } from "@/components/ui/button";

interface UserTypeToggleProps {
  userType: 'corporate' | 'venue';
  setUserType: (type: 'corporate' | 'venue') => void;
}

const UserTypeToggle = ({ userType, setUserType }: UserTypeToggleProps) => {
  return (
    <div className="space-y-2">
      <div className="flex justify-center mt-4 mb-2 border rounded-md overflow-hidden">
        <Button
          type="button"
          variant={userType === 'corporate' ? "default" : "outline"}
          className={`flex-1 rounded-none ${userType === 'corporate' ? '' : 'bg-transparent hover:text-foreground'}`}
          onClick={() => setUserType('corporate')}
        >
          For Client
        </Button>
        <Button
          type="button" 
          variant={userType === 'venue' ? "default" : "outline"}
          className={`flex-1 rounded-none ${userType === 'venue' ? '' : 'bg-transparent hover:text-foreground'}`}
          onClick={() => setUserType('venue')}
        >
          For Supplier
        </Button>
      </div>
        
      <div className="text-xs text-muted-foreground mt-2 text-center">
        {userType === 'corporate' 
          ? 'Corporates / Event Planner / Travel Planners' 
          : 'Hotels / Event Venue / Restaurants'}
      </div>
    </div>
  );
};

export default UserTypeToggle;
