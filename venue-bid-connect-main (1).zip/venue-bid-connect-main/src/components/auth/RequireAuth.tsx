
import { ReactNode, useEffect, useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import AuthRequiredModal from './AuthRequiredModal';
import { Skeleton } from "@/components/ui/skeleton";

interface RequireAuthProps {
  children: ReactNode;
  adminOnly?: boolean;
  supplierOnly?: boolean;
  clientOnly?: boolean;
}

const RequireAuth = ({ 
  children, 
  adminOnly = false,
  supplierOnly = false,
  clientOnly = false
}: RequireAuthProps) => {
  const { user, isLoading, profile } = useAuth();
  const location = useLocation();
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    if (!isLoading && !user) {
      setShowModal(true);
    }
  }, [isLoading, user]);

  // Show loading state while checking authentication
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen flex-col space-y-4">
        <Skeleton className="h-12 w-12 rounded-full" />
        <Skeleton className="h-4 w-[250px]" />
        <p className="text-sm text-muted-foreground">Checking authentication...</p>
      </div>
    );
  }
  
  // If no user is logged in, show auth modal or redirect to login
  if (!user) {
    if (showModal) {
      return <AuthRequiredModal isOpen={showModal} onClose={() => setShowModal(false)} />;
    }
    
    // If they close the modal, redirect to login
    return <Navigate to="/login" state={{ from: location }} replace />;
  }
  
  // If admin only and user is not an admin
  if (adminOnly && profile?.user_type !== 'admin') {
    return <Navigate to="/dashboard" replace />;
  }
  
  // If supplier only and user is not a supplier (venue)
  if (supplierOnly && profile?.user_type !== 'venue') {
    return <Navigate to="/dashboard" replace />;
  }
  
  // If client only and user is a supplier (venue)
  if (clientOnly && profile?.user_type === 'venue') {
    return <Navigate to="/supplier" replace />;
  }
  
  // User is authenticated and authorized
  return <>{children}</>;
};

export default RequireAuth;
