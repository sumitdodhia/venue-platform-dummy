
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link } from "react-router-dom";
import PasswordInput from "./supplier/PasswordInput";
import TermsCheckbox from "./supplier/TermsCheckbox";
import { useSupplierRegistration } from "./supplier/useSupplierRegistration";
import { SupplierFormValues } from "./supplier/SupplierFormSchema";

const SupplierRegisterForm = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [businessName, setBusinessName] = useState("");
  const [taxPin, setTaxPin] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [agreeTerms, setAgreeTerms] = useState(false);
  
  const { isLoading, handleSubmit } = useSupplierRegistration();

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const formValues: SupplierFormValues = {
      name,
      email,
      businessName,
      taxPin,
      password,
      confirmPassword,
      agreeTerms,
      phone
    };

    handleSubmit(formValues);
  };

  return (
    <div className="mx-auto max-w-md space-y-6 p-6 bg-card border rounded-lg shadow-sm">
      <div className="text-center">
        <h1 className="text-2xl font-bold">Register as a Supplier</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Create your account with basic details
        </p>
      </div>
      
      <form onSubmit={onSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="name">Contact Person Name</Label>
          <Input
            id="name"
            placeholder="John Doe"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            autoComplete="name"
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            type="email"
            placeholder="your@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            autoComplete="email"
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="phone">Phone Number</Label>
          <Input
            id="phone"
            placeholder="+1 (123) 456-7890"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="company">Business / Venue Name</Label>
          <Input
            id="company"
            placeholder="Your Business Name"
            value={businessName}
            onChange={(e) => setBusinessName(e.target.value)}
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="taxPin">Tax PIN Number</Label>
          <Input
            id="taxPin"
            placeholder="e.g., A123456789Z"
            value={taxPin}
            onChange={(e) => setTaxPin(e.target.value)}
            required
          />
        </div>
        
        <PasswordInput
          id="password"
          label="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        
        <PasswordInput
          id="confirm-password"
          label="Confirm Password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          required
        />

        <TermsCheckbox 
          checked={agreeTerms}
          onCheckedChange={setAgreeTerms}
        />
        
        <Button type="submit" className="w-full" disabled={isLoading}>
          {isLoading ? "Creating account..." : "Create Supplier Account"}
        </Button>
      </form>
      
      <div className="text-center text-sm">
        <p className="text-muted-foreground">
          Already have an account?{" "}
          <Link to="/login" className="text-primary hover:underline">
            Sign In
          </Link>
        </p>
        <p className="text-xs text-muted-foreground mt-2">
          You'll be able to complete your profile setup after registration.
        </p>
      </div>
    </div>
  );
};

export default SupplierRegisterForm;
