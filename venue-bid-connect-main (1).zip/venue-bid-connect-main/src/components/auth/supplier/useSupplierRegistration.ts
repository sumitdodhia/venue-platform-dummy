
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { SupplierFormValues } from "./SupplierFormSchema";
import { useAuth } from "@/context/AuthContext";

export const useSupplierRegistration = () => {
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { signUp } = useAuth();

  const handleSubmit = async (values: SupplierFormValues) => {
    if (values.password !== values.confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }
    
    if (!values.agreeTerms) {
      toast.error("You must agree to the terms and conditions");
      return;
    }
    
    if (!values.email) {
      toast.error("Email is required");
      return;
    }
    
    setIsLoading(true);

    try {
      // Parse the name into first and last name
      const nameParts = values.name.trim().split(' ');
      const firstName = nameParts[0] || '';
      const lastName = nameParts.slice(1).join(' ') || '';
      
      const result = await signUp({
        email: values.email,
        password: values.password,
        firstName,
        lastName,
        companyName: values.businessName,
        userType: 'venue',
        phone: values.phone
      });
      
      if (result.success) {
        toast.success("Registration successful! Please complete your profile setup.");
        navigate("/login");
      }
    } catch (error: any) {
      toast.error(error.message || "Registration failed. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return {
    isLoading,
    handleSubmit
  };
};
