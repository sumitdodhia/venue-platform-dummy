
export interface SupplierFormValues {
  name: string;
  email?: string;
  businessName: string;
  taxPin: string;
  password: string;
  confirmPassword: string;
  agreeTerms: boolean;
  phone?: string;
}
