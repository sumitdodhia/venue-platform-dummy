
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import UserTypeToggle from "./components/UserTypeToggle";
import FormHeader from "./components/FormHeader";
import FormFooter from "./components/FormFooter";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { supabase } from "@/integrations/supabase/client";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { AlertCircle, Loader2 } from "lucide-react";

const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

type LoginFormValues = z.infer<typeof loginSchema>;

const LoginForm = () => {
  const [emailNotVerified, setEmailNotVerified] = useState(false);
  const [isResendingEmail, setIsResendingEmail] = useState(false);
  const [userType, setUserType] = useState<'client' | 'supplier'>('client');
  const navigate = useNavigate();
  const { signIn } = useAuth();

  const form = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const { isSubmitting } = form.formState;

  const handleResendVerification = async () => {
    const email = form.getValues("email");
    if (!email) {
      toast.error("Please enter your email address");
      return;
    }

    setIsResendingEmail(true);
    try {
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email,
      });
      
      if (error) {
        toast.error(error.message);
      } else {
        toast.success("Verification email sent! Please check your inbox.");
      }
    } catch (error: any) {
      toast.error("Failed to resend verification email");
    } finally {
      setIsResendingEmail(false);
    }
  };

  const onSubmit = async (data: LoginFormValues) => {
    setEmailNotVerified(false);

    try {
      const result = await signIn(data.email, data.password);
      
      if (result.success) {
        navigate("/dashboard");
      } else {
        // Check if the error is related to email verification
        if (result.error?.message?.toLowerCase().includes("email not confirmed")) {
          setEmailNotVerified(true);
          toast.error("Email not verified. Please check your inbox or resend the verification email.");
        } else {
          toast.error(result.error?.message || "Failed to sign in. Please check your credentials.");
        }
      }
    } catch (error: any) {
      console.error("Login error:", error);
      toast.error(error.message || "An unexpected error occurred");
    }
  };

  return (
    <div className="mx-auto max-w-md space-y-6 p-6 bg-card border rounded-lg shadow-sm">
      <FormHeader 
        title="Welcome back" 
        description="Sign in to your account to continue"
      >
        <UserTypeToggle 
          userType={userType === 'client' ? 'corporate' : 'venue'} 
          setUserType={(type) => setUserType(type === 'corporate' ? 'client' : 'supplier')} 
        />
      </FormHeader>
      
      {emailNotVerified && (
        <Alert className="bg-amber-50 border-amber-200">
          <AlertDescription className="text-amber-800">
            Your email address has not been verified. Please check your inbox or
            <Button 
              variant="link" 
              className="px-1 text-primary h-auto" 
              onClick={handleResendVerification}
              disabled={isResendingEmail}
            >
              {isResendingEmail ? "Sending..." : "resend verification email"}
            </Button>
          </AlertDescription>
        </Alert>
      )}
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Email</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="email"
                    placeholder="name@company.com"
                    autoComplete="email"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="password"
            render={({ field }) => (
              <FormItem>
                <div className="flex items-center justify-between">
                  <FormLabel>Password</FormLabel>
                  <Link 
                    to="/forgot-password"
                    className="text-xs text-primary hover:underline"
                  >
                    Forgot password?
                  </Link>
                </div>
                <FormControl>
                  <Input
                    {...field}
                    type="password"
                    placeholder="••••••••"
                    autoComplete="current-password"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <Button type="submit" className="w-full" disabled={isSubmitting}>
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Signing in...
              </>
            ) : "Sign In"}
          </Button>
        </form>
      </Form>
      
      <FormFooter 
        text="Don't have an account?"
        linkText="Register"
        linkUrl="/register"
      />
    </div>
  );
};

export default LoginForm;
