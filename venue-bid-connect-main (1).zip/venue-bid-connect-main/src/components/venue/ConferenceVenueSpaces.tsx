
import React from "react";
import ConferenceVenueDetails from "@/components/venue/ConferenceVenueDetails";

interface ConferenceVenueSpacesProps {
  category: string;
  venueTypes?: any[];
  photos?: string[];
  capacity?: number;
  price?: number;
}

const ConferenceVenueSpaces = ({ 
  category, 
  venueTypes, 
  photos,
  capacity,
  price 
}: ConferenceVenueSpacesProps) => {
  if (category !== 'conference') {
    return null;
  }

  // If there are venue types, display them
  if (venueTypes && venueTypes.length > 0) {
    return (
      <div className="pt-6">
        <h3 className="text-xl font-semibold mb-4">Available Venue Spaces</h3>
        <div className="space-y-4">
          {venueTypes.map((venueSpace) => (
            <ConferenceVenueDetails key={venueSpace.id} venueSpace={venueSpace} />
          ))}
        </div>
      </div>
    );
  }

  // If no venue types, display a default one
  return (
    <div className="pt-6">
      <h3 className="text-xl font-semibold mb-4">Conference Space</h3>
      <ConferenceVenueDetails 
        venueSpace={{
          id: "main-space",
          name: "Main Conference Hall",
          type: "Conference Hall",
          description: "Our main conference space suitable for various events from presentations to large gatherings.",
          photos: photos ? [photos[0]] : undefined,
          maxCapacity: capacity || 100,
          priceFrom: price
        }}
      />
    </div>
  );
};

export default ConferenceVenueSpaces;
