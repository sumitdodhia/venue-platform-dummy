
import React from "react";
import RoomTypeCard from "@/components/venue/RoomTypeCard";

interface RoomTypesDisplayProps {
  rooms: any[];
  category: string;
}

const RoomTypesDisplay = ({ rooms, category }: RoomTypesDisplayProps) => {
  if (category !== 'rooms' || !rooms || rooms.length === 0) {
    return null;
  }

  return (
    <div className="pt-6">
      <h3 className="text-xl font-semibold mb-4">Available Room Types</h3>
      <div className="space-y-4">
        {rooms.map((room) => (
          <RoomTypeCard key={room.id} room={room} />
        ))}
      </div>
    </div>
  );
};

export default RoomTypesDisplay;
