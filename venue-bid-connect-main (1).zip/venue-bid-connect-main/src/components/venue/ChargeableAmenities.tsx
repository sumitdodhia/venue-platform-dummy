
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FacilityItem } from "@/types/conferenceSupplier";
import { Plus } from "lucide-react";

interface ChargeableAmenitiesProps {
  facilitiesOffered: FacilityItem[];
}

const ChargeableAmenities = ({ facilitiesOffered }: ChargeableAmenitiesProps) => {
  // Filter out any chargeable amenities
  const chargeableAmenities = facilitiesOffered.filter((facility) => facility.isCharged);

  if (facilitiesOffered.length === 0 || chargeableAmenities.length === 0) {
    return null;
  }

  // Debug log to check what amenities data is coming in
  console.log("ChargeableAmenities received facilitiesOffered:", facilitiesOffered);
  console.log("Chargeable amenities:", chargeableAmenities);

  return (
    <div className="space-y-6">
      <h3 className="text-2xl font-semibold">Amenities & Services</h3>
      
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Chargeable Amenities</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {chargeableAmenities.map((facility, index) => (
              <div key={index} className="flex items-center justify-between border rounded-md p-3 bg-muted/30">
                <div>
                  <p className="font-medium">{facility.name}</p>
                  <p className="text-sm text-amber-600">
                    {facility.rate ? `$${facility.rate}` : ""} {facility.chargeType}
                  </p>
                </div>
                <Plus className="h-5 w-5 text-muted-foreground" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ChargeableAmenities;
