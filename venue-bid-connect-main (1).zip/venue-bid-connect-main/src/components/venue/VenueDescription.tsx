import { Button } from "@/components/ui/button";
import { MapPin, Star, Building, Users, Check, Utensils, Clock, ChevronDown } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

interface VenueDescriptionProps {
  category: string;
  location: string;
  tags: string[];
  price: number;
  priceLabel: string;
  description?: string;
  facilities?: string[];
  basisOffered?: string[];
  totalRooms?: number;
  googleMapUrl?: string;
  capacity?: number;
  cuisineType?: string;
  openingHours?: {
    monday: string;
    tuesday: string;
    wednesday: string;
    thursday: string;
    friday: string;
    saturday: string;
    sunday: string;
  };
  priceRange?: 1 | 2 | 3 | 4;
}

const VenueDescription = ({
  category,
  location,
  tags,
  price,
  priceLabel,
  description,
  facilities = [],
  basisOffered = [],
  totalRooms,
  googleMapUrl,
  capacity,
  cuisineType,
  openingHours,
  priceRange
}: VenueDescriptionProps) => {
  // Helper function to render price range as $ symbols
  const renderPriceRange = (range?: 1 | 2 | 3 | 4) => {
    if (!range) return null;
    const symbols = Array(4).fill('$').map((symbol, index) => 
      index < range ? <span key={index} className="text-primary">{symbol}</span> : <span key={index} className="text-muted-foreground">{symbol}</span>
    );
    return <div className="flex text-lg font-semibold">{symbols}</div>;
  };

  // Helper function to format day names
  const formatDayName = (day: string): string => {
    return day.charAt(0).toUpperCase() + day.slice(1);
  };
  
  // Get days of the week in order for display
  const daysOfWeek = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];

  return (
    <div className="space-y-6">
      <div className="grid sm:grid-cols-2 gap-6">
        <div>
          <div className="flex items-center gap-1 text-muted-foreground">
            <MapPin className="h-4 w-4" />
            <span>{location}</span>
            {googleMapUrl && (
              <>
                <span className="mx-1">•</span>
                <a 
                  href={googleMapUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline transition-colors"
                >
                  Location
                </a>
              </>
            )}
          </div>
          
          {category === "rooms" && totalRooms !== undefined && (
            <div className="flex items-center gap-1 text-muted-foreground mt-2">
              <Building className="h-4 w-4" />
              <span>{totalRooms} {totalRooms === 1 ? 'room' : 'rooms'} available</span>
            </div>
          )}

          {category === "conference" && capacity && (
            <div className="flex items-center gap-1 text-muted-foreground mt-2">
              <Users className="h-4 w-4" />
              <span>Capacity: {capacity} people</span>
            </div>
          )}
          
          {category === "restaurants" && cuisineType && (
            <div className="flex items-center gap-1 text-muted-foreground mt-2">
              <Utensils className="h-4 w-4" />
              <span>Cuisine: {cuisineType}</span>
            </div>
          )}
          
          {category === "restaurants" && capacity && (
            <div className="flex items-center gap-1 text-muted-foreground mt-2">
              <Users className="h-4 w-4" />
              <span>Capacity: {capacity} guests</span>
            </div>
          )}

          {basisOffered && basisOffered.length > 0 && (
            <div className="mt-2">
              <p className="text-sm font-medium">Basis Offered:</p>
              <p className="text-sm text-muted-foreground">{basisOffered.join(", ")}</p>
            </div>
          )}
          
          {category === "restaurants" && priceRange && (
            <div className="mt-2">
              <p className="text-sm font-medium">Price Range:</p>
              {renderPriceRange(priceRange)}
            </div>
          )}
        </div>
        
        <div className="text-right">
          <p className="text-sm text-muted-foreground">Indicative pricing - starting from</p>
          <p className="text-2xl font-bold">${price}</p>
          <p className="text-sm text-muted-foreground">{priceLabel}</p>
          <p className="text-xs text-muted-foreground mt-1">
            Actual prices may vary based on availability, dates, and specific requirements
          </p>
        </div>
      </div>

      <Separator />
      
      {description && (
        <div>
          <h3 className="text-lg font-semibold mb-2">About this Venue</h3>
          <p className="text-muted-foreground whitespace-pre-line">{description}</p>
        </div>
      )}
      
      {category === "restaurants" && openingHours && (
        <div>
          <Collapsible className="w-full border rounded-md">
            <CollapsibleTrigger className="flex items-center justify-between w-full p-3 hover:bg-muted/50 transition-colors">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                <span className="font-medium">Opening Hours</span>
              </div>
              <ChevronDown className="h-4 w-4 transition-transform ui-expanded:rotate-180" />
            </CollapsibleTrigger>
            <CollapsibleContent className="p-3 pt-0 border-t">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {daysOfWeek.map(day => openingHours[day as keyof typeof openingHours] && (
                  <div key={day} className="flex justify-between text-sm py-1">
                    <span className="font-medium capitalize">{formatDayName(day)}</span>
                    <span className="text-muted-foreground">{openingHours[day as keyof typeof openingHours]}</span>
                  </div>
                ))}
              </div>
            </CollapsibleContent>
          </Collapsible>
        </div>
      )}
      
      {tags && tags.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold mb-3">Features</h3>
          <div className="flex flex-wrap gap-2">
            {tags.map((tag, index) => (
              <Badge key={index} variant="secondary">{tag}</Badge>
            ))}
            
            {facilities && facilities.length > 0 && facilities.map((facility, index) => (
              <Badge key={`facility-${index}`} variant="outline">{facility}</Badge>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default VenueDescription;
