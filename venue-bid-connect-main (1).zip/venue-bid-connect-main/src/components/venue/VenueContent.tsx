
import React from "react";
import VenueDetailHeader from "@/components/venue/VenueDetailHeader";
import VenueDescription from "@/components/venue/VenueDescription";
import VenueSidebar from "@/components/venue/VenueSidebar";
import RoomTypesDisplay from "@/components/venue/RoomTypesDisplay";
import ConferenceVenueSpaces from "@/components/venue/ConferenceVenueSpaces";
import ChargeableAmenities from "@/components/venue/ChargeableAmenities";
import RestaurantDiningSections from "@/components/venue/RestaurantDiningSections";
import RestaurantDiningPackages from "@/components/venue/RestaurantDiningPackages";
import { Separator } from "@/components/ui/separator";
import { Venue } from "@/types/venue";
import { 
  isRoomVenue, 
  isConferenceVenue, 
  isRestaurantVenue 
} from "@/utils/venueTypeGuards";

interface VenueContentProps {
  venue: Venue;
}

const VenueContent = ({ venue }: VenueContentProps) => {
  // Extract venue spaces from venueTypes for conference venues
  const venueSpaces = isConferenceVenue(venue) && venue.venueTypes 
    ? venue.venueTypes.map((space: any) => ({
        id: space.id,
        name: space.name
      }))
    : [];
    
  // Debug log to check conference venue data
  if (isConferenceVenue(venue)) {
    console.log("Conference venue data:", venue);
    console.log("Venue spaces:", venueSpaces);
    console.log("Facilities offered:", venue.facilitiesOffered);
  }

  return (
    <div className="grid md:grid-cols-3 gap-8">
      <div className="md:col-span-2 space-y-6">
        <VenueDetailHeader 
          title={venue.title}
          imageUrl={venue.imageUrl}
          photos={venue.photos}
          category={venue.category}
          rating={venue.rating}
          location={venue.location}
        />
        
        <VenueDescription 
          category={venue.category}
          location={venue.location}
          tags={venue.tags}
          price={venue.price}
          priceLabel={venue.priceLabel}
          description={venue.description || (isRoomVenue(venue) ? venue.about : undefined)}
          facilities={venue.facilities}
          basisOffered={isRoomVenue(venue) ? venue.basisOffered : undefined}
          totalRooms={isRoomVenue(venue) ? venue.totalRooms : undefined}
          googleMapUrl={venue.googleLocation}
          capacity={!isRoomVenue(venue) && 'capacity' in venue ? venue.capacity : undefined}
          cuisineType={isRestaurantVenue(venue) ? venue.cuisineType : undefined}
          openingHours={isRestaurantVenue(venue) ? venue.openingHours : undefined}
          priceRange={isRestaurantVenue(venue) ? venue.priceRange : undefined}
        />
        
        {isRoomVenue(venue) && venue.rooms && (
          <RoomTypesDisplay 
            rooms={venue.rooms} 
            category={venue.category} 
          />
        )}
        
        {isConferenceVenue(venue) && venue.venueTypes && (
          <ConferenceVenueSpaces 
            category={venue.category} 
            venueTypes={venue.venueTypes}
            photos={venue.photos}
            capacity={venue.capacity}
            price={venue.price}
          />
        )}
        
        {isConferenceVenue(venue) && venue.facilitiesOffered && (
          <>
            {console.log("Rendering ChargeableAmenities with:", venue.facilitiesOffered)}
            <ChargeableAmenities 
              facilitiesOffered={venue.facilitiesOffered}
            />
          </>
        )}
        
        {isRestaurantVenue(venue) && venue.diningSections && (
          <>
            <RestaurantDiningSections diningSections={venue.diningSections} />
            {venue.diningPackages && (
              <RestaurantDiningPackages diningPackages={venue.diningPackages} />
            )}
          </>
        )}
        
        <Separator className="md:hidden" />
      </div>
      
      <div>
        <VenueSidebar 
          category={venue.category}
          location={venue.location}
          rating={venue.rating}
          rooms={isRoomVenue(venue) ? venue.rooms : undefined}
          basisOffered={isRoomVenue(venue) ? venue.basisOffered : undefined}
          capacity={!isRoomVenue(venue) && 'capacity' in venue ? venue.capacity : undefined}
          venueSpaces={venueSpaces}
          diningPackages={isRestaurantVenue(venue) ? venue.diningPackages : undefined}
          diningSections={isRestaurantVenue(venue) ? venue.diningSections : undefined}
          cuisineType={isRestaurantVenue(venue) ? venue.cuisineType : undefined}
          facilitiesOffered={isConferenceVenue(venue) ? venue.facilitiesOffered : undefined}
        />
      </div>
    </div>
  );
};

export default VenueContent;
