
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MapPin, Star, Building, Users, Calendar, Utensils } from "lucide-react";
import { FacilityItem } from "@/types/conferenceSupplier";
import EnquiryForm from "./EnquiryForm";

interface VenueSidebarProps {
  category: string;
  location: string;
  rating: number;
  rooms?: any[];
  basisOffered?: string[];
  capacity?: number;
  venueSpaces?: { id: string; name: string }[];
  diningPackages?: any[];
  diningSections?: any[];
  cuisineType?: string;
  facilitiesOffered?: FacilityItem[];
}

const VenueSidebar = ({
  category,
  location,
  rating,
  rooms = [],
  basisOffered = [],
  capacity,
  venueSpaces = [],
  diningPackages = [],
  diningSections = [],
  cuisineType,
  facilitiesOffered = []
}: VenueSidebarProps) => {
  // Note: We're no longer using these variables since we're removing these sections
  // const chargeableAmenities = facilitiesOffered.filter(facility => facility.isCharged);

  return (
    <div className="space-y-6 sticky top-24">
      {/* Removed the Quick Info card */}

      {/* Removed the venueSpaces card */}
      
      {/* Removed the chargeableAmenities card */}

      {/* Removed the Dining Areas card */}
      
      {/* Removed the Dining Packages card */}
      
      {/* Add the full enquiry form component */}
      <div id="enquiry-form">
        <EnquiryForm
          venueCategory={category}
          roomTypes={rooms}
          basisOptions={basisOffered}
          capacity={capacity}
          diningPackages={diningPackages}
          diningSections={diningSections}
          facilitiesOffered={facilitiesOffered}
        />
      </div>
    </div>
  );
};

export default VenueSidebar;
