
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Carousel, 
  CarouselContent, 
  CarouselItem, 
  CarouselNext, 
  CarouselPrevious 
} from "@/components/ui/carousel";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";

interface RoomTypeCardProps {
  room: {
    id: string;
    name: string;
    type: string;
    description: string;
    photos: string[];
    maxPax: number;
    priceFrom: number;
    numberOfRooms: number;
  };
}

const RoomTypeCard = ({ room }: RoomTypeCardProps) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <Card className="overflow-hidden">
      <CardContent className="p-4">
        <div className="flex flex-col md:flex-row gap-4">
          {/* Image Section (Left) */}
          <div className="md:w-1/3">
            {room.photos.length > 0 && (
              <Carousel className="w-full">
                <CarouselContent>
                  {room.photos.map((photo, index) => (
                    <CarouselItem key={index} className="basis-full">
                      <AspectRatio ratio={4/3}>
                        <img 
                          src={photo} 
                          alt={`${room.name} - Photo ${index + 1}`} 
                          className="rounded-lg object-cover w-full h-full"
                        />
                      </AspectRatio>
                    </CarouselItem>
                  ))}
                </CarouselContent>
                {room.photos.length > 1 && (
                  <>
                    <CarouselPrevious className="left-1 h-7 w-7" />
                    <CarouselNext className="right-1 h-7 w-7" />
                  </>
                )}
              </Carousel>
            )}
          </div>
          
          {/* Text Content Section (Right) */}
          <div className="md:w-2/3">
            <div className="flex flex-row items-start justify-between space-y-0 mb-2">
              <div>
                <h3 className="text-xl font-semibold">{room.name}</h3>
                <p className="text-sm text-muted-foreground">
                  {room.type} · Max {room.maxPax} guests · {room.numberOfRooms} rooms
                </p>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground mb-1">Indicative pricing - may vary</p>
                <p className="font-bold">From ${room.priceFrom}</p>
                <p className="text-sm text-muted-foreground">per night</p>
              </div>
            </div>
            
            <div className={`${isExpanded ? '' : 'line-clamp-3'} mb-2`}>
              <p>{room.description}</p>
            </div>
            
            {room.description.length > 150 && (
              <Button 
                variant="ghost" 
                size="sm" 
                className="mb-4 h-auto p-0 flex items-center"
                onClick={() => setIsExpanded(!isExpanded)}
              >
                {isExpanded ? (
                  <>Show less <ChevronUp className="h-4 w-4 ml-1" /></>
                ) : (
                  <>Read more <ChevronDown className="h-4 w-4 ml-1" /></>
                )}
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default RoomTypeCard;
