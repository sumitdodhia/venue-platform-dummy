
import { Badge } from "@/components/ui/badge";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { Star } from "lucide-react";
import { 
  Carousel, 
  CarouselContent, 
  CarouselItem, 
  CarouselNext, 
  CarouselPrevious 
} from "@/components/ui/carousel";

interface VenueDetailHeaderProps {
  title: string;
  imageUrl: string;
  photos?: string[];
  category: string;
  rating: number;
  location: string;
}

export function getCategoryLabel(category: string) {
  switch (category) {
    case 'rooms':
      return 'Room';
    case 'conference':
      return 'Conference Venue';
    case 'restaurants':
      return 'Restaurant';
    case 'catering':
      return 'Catering Service';
    default:
      return 'Venue';
  }
}

const VenueDetailHeader = ({ 
  title, 
  imageUrl, 
  photos = [], 
  category, 
  rating, 
  location 
}: VenueDetailHeaderProps) => {
  // Use photos array if available, otherwise fall back to single imageUrl
  const imagesToShow = photos && photos.length > 0 ? photos : [imageUrl];

  return (
    <div className="space-y-6">
      <div className="relative">
        {imagesToShow.length > 1 ? (
          <Carousel className="w-full">
            <CarouselContent>
              {imagesToShow.map((photo, index) => (
                <CarouselItem key={index}>
                  <AspectRatio ratio={16/9}>
                    <img 
                      src={photo} 
                      alt={`${title} - Photo ${index + 1}`}
                      className="rounded-lg object-cover w-full h-full"
                    />
                  </AspectRatio>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious className="left-2" />
            <CarouselNext className="right-2" />
          </Carousel>
        ) : (
          <AspectRatio ratio={16/9}>
            <img 
              src={imagesToShow[0]} 
              alt={title}
              className="rounded-lg object-cover w-full h-full"
            />
          </AspectRatio>
        )}
        <Badge className="absolute top-4 right-4" variant="secondary">
          {getCategoryLabel(category)}
        </Badge>
      </div>
      
      <div>
        <div className="flex justify-between items-start">
          <h1 className="text-3xl font-bold">{title}</h1>
          <div className="flex items-center bg-yellow-100 text-yellow-800 text-sm font-semibold px-2 py-1 rounded">
            <Star className="w-4 h-4 mr-1 fill-yellow-500 stroke-yellow-500" />
            <span>{rating}</span>
          </div>
        </div>
        
        {/* Removed the duplicate location display here */}
      </div>
    </div>
  );
};

export default VenueDetailHeader;
