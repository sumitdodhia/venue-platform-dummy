
import React from "react";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { Images } from "lucide-react";

interface DiningSection {
  id: string;
  name: string;
  description: string;
  capacity: number;
  isPrivate: boolean;
  isOutdoor: boolean;
  photo?: string;
  photos?: string[];
}

interface RestaurantDiningSectionsProps {
  diningSections: DiningSection[];
}

const RestaurantDiningSections = ({ diningSections }: RestaurantDiningSectionsProps) => {
  if (!diningSections || diningSections.length === 0) {
    return null;
  }

  return (
    <div className="pt-6">
      <h3 className="text-xl font-semibold mb-4">Dining Areas</h3>
      <div className="space-y-4">
        {diningSections.map((section) => (
          <DiningSectionCard key={section.id} section={section} />
        ))}
      </div>
    </div>
  );
};

// Extracted into a separate component for better organization
const DiningSectionCard = ({ section }: { section: DiningSection }) => {
  // Get display photo from photos array or fall back to main photo
  const displayPhoto = section.photos && section.photos.length > 0 
    ? section.photos[0] 
    : section.photo;
  
  return (
    <div className="p-4 border rounded-md">
      <div className="flex flex-col md:flex-row gap-4">
        {displayPhoto && (
          <div className="md:w-1/3">
            <AspectRatio ratio={4/3}>
              <img 
                src={displayPhoto} 
                alt={section.name} 
                className="rounded-md object-cover h-full w-full"
              />
            </AspectRatio>
          </div>
        )}
        <div className={displayPhoto ? "md:w-2/3" : "w-full"}>
          <h4 className="font-medium text-lg">{section.name}</h4>
          <p className="text-muted-foreground my-2">{section.description}</p>
          
          <div className="flex flex-wrap gap-2 mt-3">
            <span className="text-xs bg-primary/10 px-2 py-1 rounded-md">
              Capacity: {section.capacity} guests
            </span>
            {section.isPrivate && (
              <span className="text-xs bg-primary/10 px-2 py-1 rounded-md">
                Private
              </span>
            )}
            {section.isOutdoor && (
              <span className="text-xs bg-primary/10 px-2 py-1 rounded-md">
                Outdoor
              </span>
            )}
            {section.photos && section.photos.length > 1 && (
              <span className="text-xs bg-primary/10 px-2 py-1 rounded-md flex items-center">
                <Images className="h-3 w-3 mr-1" />
                {section.photos.length} photos
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RestaurantDiningSections;
