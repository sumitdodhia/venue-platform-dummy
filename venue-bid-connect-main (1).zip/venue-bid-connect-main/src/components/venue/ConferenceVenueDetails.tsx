
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Carousel, 
  CarouselContent, 
  CarouselItem, 
  CarouselNext, 
  CarouselPrevious 
} from "@/components/ui/carousel";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { ChevronDown, ChevronUp, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface ConferenceVenueSpaceProps {
  venueSpace: {
    id: string;
    name: string;
    type: string;
    description: string;
    photos?: string[];
    maxCapacity: number;
    priceFrom: number;
  };
}

const ConferenceVenueDetails = ({ venueSpace }: ConferenceVenueSpaceProps) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <Card className="overflow-hidden">
      <CardContent className="p-4">
        <div className="flex flex-col md:flex-row gap-4">
          {/* Image Section (Left) */}
          <div className="md:w-1/3">
            {venueSpace.photos && venueSpace.photos.length > 0 ? (
              <Carousel className="w-full">
                <CarouselContent>
                  {venueSpace.photos.map((photo, index) => (
                    <CarouselItem key={index} className="basis-full">
                      <AspectRatio ratio={4/3}>
                        <img 
                          src={photo} 
                          alt={`${venueSpace.name} - Photo ${index + 1}`} 
                          className="rounded-lg object-cover w-full h-full"
                        />
                      </AspectRatio>
                    </CarouselItem>
                  ))}
                </CarouselContent>
                {venueSpace.photos.length > 1 && (
                  <>
                    <CarouselPrevious className="left-1 h-7 w-7" />
                    <CarouselNext className="right-1 h-7 w-7" />
                  </>
                )}
              </Carousel>
            ) : (
              <AspectRatio ratio={4/3}>
                <div className="bg-muted flex items-center justify-center rounded-lg w-full h-full">
                  <p className="text-muted-foreground">No image available</p>
                </div>
              </AspectRatio>
            )}
          </div>
          
          {/* Text Content Section (Right) */}
          <div className="md:w-2/3">
            <div className="flex flex-row items-start justify-between space-y-0 mb-2">
              <div>
                <h3 className="text-xl font-semibold">{venueSpace.name}</h3>
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <Badge variant="outline">{venueSpace.type}</Badge>
                  <div className="flex items-center gap-1 ml-2">
                    <Users className="h-3.5 w-3.5" />
                    <span>Up to {venueSpace.maxCapacity} people</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground mb-1">Indicative pricing</p>
                <p className="font-bold">From ${venueSpace.priceFrom}</p>
                <p className="text-sm text-muted-foreground">per day</p>
                <p className="text-xs text-muted-foreground">May vary based on availability and requirements</p>
              </div>
            </div>
            
            <div className={`${isExpanded ? '' : 'line-clamp-3'} mb-2`}>
              <p>{venueSpace.description}</p>
            </div>
            
            {venueSpace.description.length > 150 && (
              <Button 
                variant="ghost" 
                size="sm" 
                className="mb-4 h-auto p-0 flex items-center"
                onClick={() => setIsExpanded(!isExpanded)}
              >
                {isExpanded ? (
                  <>Show less <ChevronUp className="h-4 w-4 ml-1" /></>
                ) : (
                  <>Read more <ChevronDown className="h-4 w-4 ml-1" /></>
                )}
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ConferenceVenueDetails;
