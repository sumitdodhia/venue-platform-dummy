
import React from "react";
import DateRangeSelection from "./DateRangeSelection";

interface EnquiryDateSelectionProps {
  venueCategory: string;
  eventType?: string;
  startDate: Date | undefined;
  setStartDate: (date: Date | undefined) => void;
  endDate?: Date | undefined;
  setEndDate?: (date: Date | undefined) => void;
}

const EnquiryDateSelection = ({
  venueCategory,
  eventType = "full-day",
  startDate,
  setStartDate,
  endDate,
  setEndDate
}: EnquiryDateSelectionProps) => {
  
  // For rooms category
  if (venueCategory === 'rooms') {
    return (
      <DateRangeSelection 
        startDate={startDate} 
        setStartDate={setStartDate} 
        endDate={endDate} 
        setEndDate={setEndDate}
        startLabel="Check-in Date"
        endLabel="Check-out Date"
      />
    );
  }
  
  // We don't handle conference dates here anymore as they're now handled in ConferenceOptions
  // This component is now only used for rooms category
  
  // Default - should never reach here
  return null;
};

export default EnquiryDateSelection;
