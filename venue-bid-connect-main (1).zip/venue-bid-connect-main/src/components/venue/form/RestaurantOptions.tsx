import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import EnquiryDateSelection from "./EnquiryDateSelection";

interface RestaurantOptionsProps {
  guests: string;
  setGuests: (value: string) => void;
  cuisine: string;
  setCuisine: (value: string) => void;
  seatingType: string;
  setSeatingType: (value: string) => void;
  packageType: string;
  setPackageType: (value: string) => void;
  diningSection: string;
  setDiningSection: (value: string) => void;
  specialRequirements: string[];
  setSpecialRequirements: (value: string[]) => void;
  sections?: Array<{id: string, name: string}>;
  packages?: Array<{id: string, name: string}>;
  startDate: Date | undefined;
  setStartDate: (date: Date | undefined) => void;
  eventTime: string;
  setEventTime: (time: string) => void;
}

const RestaurantOptions: React.FC<RestaurantOptionsProps> = ({
  guests,
  setGuests,
  cuisine,
  setCuisine,
  seatingType,
  setSeatingType,
  packageType,
  setPackageType,
  diningSection,
  setDiningSection,
  specialRequirements,
  setSpecialRequirements,
  sections = [],
  packages = [],
  startDate,
  setStartDate,
  eventTime,
  setEventTime,
}) => {
  const handleSpecialRequirementChange = (requirement: string) => {
    if (specialRequirements.includes(requirement)) {
      setSpecialRequirements(
        specialRequirements.filter((req) => req !== requirement)
      );
    } else {
      setSpecialRequirements([...specialRequirements, requirement]);
    }
  };

  return (
    <div className="space-y-4">
      <EnquiryDateSelection
        venueCategory="restaurants"
        startDate={startDate}
        setStartDate={setStartDate}
        eventType="single-day"
      />

      <div className="space-y-2">
        <Label htmlFor="eventTime">Reservation Time</Label>
        <Input
          id="eventTime"
          type="time"
          value={eventTime}
          onChange={(e) => setEventTime(e.target.value)}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="guests">Number of Guests</Label>
        <Input
          id="guests"
          type="number"
          min="1"
          value={guests}
          onChange={(e) => setGuests(e.target.value)}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="diningSection">Preferred Section</Label>
        <Select value={diningSection} onValueChange={setDiningSection}>
          <SelectTrigger id="diningSection">
            <SelectValue placeholder="Select a section" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="any">Any Section</SelectItem>
            {sections && sections.length > 0 ? (
              sections.map((section) => (
                <SelectItem key={section.id} value={section.id}>{section.name}</SelectItem>
              ))
            ) : (
              <>
                <SelectItem value="indoor">Indoor</SelectItem>
                <SelectItem value="outdoor">Outdoor</SelectItem>
                <SelectItem value="bar">Bar Area</SelectItem>
                <SelectItem value="private">Private Room</SelectItem>
              </>
            )}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="packageType">Dining Package</Label>
        <Select value={packageType} onValueChange={setPackageType}>
          <SelectTrigger id="packageType">
            <SelectValue placeholder="Select a package" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">No Package (À La Carte)</SelectItem>
            {packages && packages.length > 0 ? (
              packages.map((pkg) => (
                <SelectItem key={pkg.id} value={pkg.id}>{pkg.name}</SelectItem>
              ))
            ) : (
              <>
                <SelectItem value="standard">Standard Menu</SelectItem>
                <SelectItem value="premium">Premium Menu</SelectItem>
                <SelectItem value="tasting">Tasting Menu</SelectItem>
                <SelectItem value="chef">Chef's Special</SelectItem>
              </>
            )}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="cuisine">Cuisine Preference</Label>
        <Select value={cuisine} onValueChange={setCuisine}>
          <SelectTrigger id="cuisine">
            <SelectValue placeholder="Select cuisine" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="any">Any Cuisine</SelectItem>
            <SelectItem value="italian">Italian</SelectItem>
            <SelectItem value="asian">Asian</SelectItem>
            <SelectItem value="mediterranean">Mediterranean</SelectItem>
            <SelectItem value="indian">Indian</SelectItem>
            <SelectItem value="american">American</SelectItem>
            <SelectItem value="mexican">Mexican</SelectItem>
            <SelectItem value="french">French</SelectItem>
            <SelectItem value="continental">Continental</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="seatingType">Seating Type</Label>
        <Select value={seatingType} onValueChange={setSeatingType}>
          <SelectTrigger id="seatingType">
            <SelectValue placeholder="Select seating type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="any">Any Type</SelectItem>
            <SelectItem value="standard">Standard</SelectItem>
            <SelectItem value="booth">Booth</SelectItem>
            <SelectItem value="window">Window</SelectItem>
            <SelectItem value="private">Private Room</SelectItem>
            <SelectItem value="outdoor">Outdoor/Patio</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label>Special Requirements</Label>
        <div className="grid grid-cols-2 gap-2 mt-1">
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="allergyFriendly" 
              checked={specialRequirements.includes("allergyFriendly")}
              onCheckedChange={() => handleSpecialRequirementChange("allergyFriendly")}
            />
            <label htmlFor="allergyFriendly" className="text-sm">Allergy Friendly</label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="vegetarianOptions" 
              checked={specialRequirements.includes("vegetarianOptions")}
              onCheckedChange={() => handleSpecialRequirementChange("vegetarianOptions")}
            />
            <label htmlFor="vegetarianOptions" className="text-sm">Vegetarian Options</label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="veganOptions" 
              checked={specialRequirements.includes("veganOptions")}
              onCheckedChange={() => handleSpecialRequirementChange("veganOptions")}
            />
            <label htmlFor="veganOptions" className="text-sm">Vegan Options</label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="kidsMenu" 
              checked={specialRequirements.includes("kidsMenu")}
              onCheckedChange={() => handleSpecialRequirementChange("kidsMenu")}
            />
            <label htmlFor="kidsMenu" className="text-sm">Kids Menu</label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="birthdayCake" 
              checked={specialRequirements.includes("birthdayCake")}
              onCheckedChange={() => handleSpecialRequirementChange("birthdayCake")}
            />
            <label htmlFor="birthdayCake" className="text-sm">Birthday Cake</label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="alcoholFree" 
              checked={specialRequirements.includes("alcoholFree")}
              onCheckedChange={() => handleSpecialRequirementChange("alcoholFree")}
            />
            <label htmlFor="alcoholFree" className="text-sm">Alcohol-Free</label>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RestaurantOptions;
