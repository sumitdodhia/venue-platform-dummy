
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import DateRangeSelection from "./DateRangeSelection";
import { FacilityItem } from "@/types/conferenceSupplier";

interface ConferenceOptionsProps {
  attendees: string;
  setAttendees: (value: string) => void;
  layout: string;
  setLayout: (value: string) => void;
  equipment: string[];
  setEquipment: (value: string[]) => void;
  eventType: string;
  setEventType: (value: string) => void;
  venueSpace: string;
  setVenueSpace: (value: string) => void;
  maxCapacity?: number;
  venueSpaces?: Array<{id: string, name: string}>;
  startDate: Date | undefined;
  setStartDate: (date: Date | undefined) => void;
  endDate: Date | undefined;
  setEndDate: (date: Date | undefined) => void;
  facilitiesOffered?: FacilityItem[];
}

// Default equipment options in case no facilities are provided
const defaultEquipmentOptions = [
  { id: "projector", label: "Projector" },
  { id: "microphone", label: "Microphone System" },
  { id: "wifi", label: "High-Speed WiFi" },
  { id: "videoConference", label: "Video Conferencing" },
  { id: "flipChart", label: "Flip Chart" },
  { id: "whiteboard", label: "Whiteboard" },
];

const ConferenceOptions = ({ 
  attendees, 
  setAttendees, 
  layout, 
  setLayout,
  equipment,
  setEquipment,
  eventType,
  setEventType,
  venueSpace,
  setVenueSpace,
  maxCapacity,
  venueSpaces = [],
  startDate,
  setStartDate,
  endDate,
  setEndDate,
  facilitiesOffered = []
}: ConferenceOptionsProps) => {
  
  // Convert facilities to equipment options format
  const equipmentOptions = facilitiesOffered.length > 0 
    ? facilitiesOffered.map(facility => ({
        id: facility.name.toLowerCase().replace(/\s+/g, '-'),
        label: facility.name
      }))
    : defaultEquipmentOptions;
  
  const handleEquipmentChange = (itemId: string) => {
    if (equipment.includes(itemId)) {
      setEquipment(equipment.filter(id => id !== itemId));
    } else {
      setEquipment([...equipment, itemId]);
    }
  };
  
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Event Duration</Label>
        <RadioGroup 
          value={eventType} 
          onValueChange={setEventType} 
          className="space-y-1 pt-1"
        >
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="half-day-am" id="half-day-am" />
            <Label htmlFor="half-day-am" className="text-sm font-normal">Half Day (AM)</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="half-day-pm" id="half-day-pm" />
            <Label htmlFor="half-day-pm" className="text-sm font-normal">Half Day (PM)</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="full-day" id="full-day" />
            <Label htmlFor="full-day" className="text-sm font-normal">Full Day</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="multi-day" id="multi-day" />
            <Label htmlFor="multi-day" className="text-sm font-normal">Multi Day</Label>
          </div>
        </RadioGroup>
      </div>

      {/* Event Date selection moved here, right after Event Duration */}
      {eventType === 'multi-day' ? (
        <DateRangeSelection 
          startDate={startDate} 
          setStartDate={setStartDate} 
          endDate={endDate} 
          setEndDate={setEndDate}
          startLabel="Event Start Date"
          endLabel="Event End Date"
        />
      ) : (
        <DateRangeSelection 
          startDate={startDate} 
          setStartDate={setStartDate} 
          showEndDate={false}
          startLabel={
            eventType === 'half-day-am' ? 'Half Day (AM) Date' : 
            eventType === 'half-day-pm' ? 'Half Day (PM) Date' : 
            'Event Date'
          }
        />
      )}

      <div className="space-y-2">
        <Label htmlFor="venueSpace">Venue Space</Label>
        <Select value={venueSpace} onValueChange={setVenueSpace}>
          <SelectTrigger id="venueSpace" className="w-full">
            <SelectValue placeholder="Select venue space" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="any">Any Space</SelectItem>
            {venueSpaces && venueSpaces.length > 0 && venueSpaces.map((space) => (
              <SelectItem key={space.id} value={space.id}>{space.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    
      <div className="space-y-2">
        <Label htmlFor="attendees">Number of Attendees</Label>
        <Input 
          id="attendees" 
          type="number" 
          min="1" 
          max={maxCapacity} 
          value={attendees} 
          onChange={(e) => setAttendees(e.target.value)}
          required 
        />
        {maxCapacity && (
          <p className="text-xs text-muted-foreground">
            Maximum capacity: {maxCapacity} people
          </p>
        )}
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="layout">Preferred Seating Layout</Label>
        <Select value={layout} onValueChange={setLayout}>
          <SelectTrigger id="layout" className="w-full">
            <SelectValue placeholder="Select layout" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="any">Any Layout</SelectItem>
            <SelectItem value="theater">Theater</SelectItem>
            <SelectItem value="classroom">Classroom</SelectItem>
            <SelectItem value="boardroom">Boardroom</SelectItem>
            <SelectItem value="banquet">Banquet</SelectItem>
            <SelectItem value="reception">Reception</SelectItem>
            <SelectItem value="u-shape">U-Shape</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-2">
        <Label className="text-base">Equipment & Amenities Required</Label>
        <div className="grid grid-cols-2 gap-1 pt-1">
          {equipmentOptions.map((item) => (
            <div 
              key={item.id} 
              className="flex items-center space-x-2 p-2 rounded-md hover:bg-muted/50 cursor-pointer"
              onClick={() => handleEquipmentChange(item.id)}
            >
              <Checkbox 
                id={`equipment-${item.id}`} 
                checked={equipment.includes(item.id)}
                className="pointer-events-none"
              />
              <Label 
                htmlFor={`equipment-${item.id}`}
                className="text-sm font-normal cursor-pointer"
              >
                {item.label}
              </Label>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ConferenceOptions;
