
import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface RoomOptionsProps {
  roomCount: string;
  setRoomCount: (count: string) => void;
  selectedRoomType: string;
  setSelectedRoomType: (type: string) => void;
  selectedBasis: string;
  setSelectedBasis: (basis: string) => void;
  roomTypes: Array<{id: string, name: string}>;
  basisOptions: string[];
}

const RoomOptions = ({
  roomCount,
  setRoomCount,
  selectedRoomType,
  setSelectedRoomType,
  selectedBasis,
  setSelectedBasis,
  roomTypes,
  basisOptions
}: RoomOptionsProps) => {
  return (
    <>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="roomCount">Number of Rooms</Label>
          <Input 
            id="roomCount" 
            type="number"
            min="1"
            value={roomCount}
            onChange={(e) => setRoomCount(e.target.value)}
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="roomType">Room Type</Label>
          <Select value={selectedRoomType} onValueChange={setSelectedRoomType}>
            <SelectTrigger id="roomType">
              <SelectValue placeholder="Select room type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Any Room Type</SelectItem>
              {roomTypes.map(room => (
                <SelectItem key={room.id} value={room.id}>{room.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {basisOptions.length > 0 && (
        <div className="space-y-2">
          <Label htmlFor="basis">Basis</Label>
          <Select value={selectedBasis} onValueChange={setSelectedBasis}>
            <SelectTrigger id="basis">
              <SelectValue placeholder="Select basis" />
            </SelectTrigger>
            <SelectContent>
              {basisOptions.map((basis, index) => (
                <SelectItem key={index} value={basis}>{basis}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}
    </>
  );
};

export default RoomOptions;
