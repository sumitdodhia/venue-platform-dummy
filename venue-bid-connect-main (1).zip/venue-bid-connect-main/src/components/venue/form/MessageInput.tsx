
import React from "react";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

interface MessageInputProps {
  message: string;
  setMessage: (message: string) => void;
}

const MessageInput = ({ message, setMessage }: MessageInputProps) => {
  return (
    <div className="space-y-2">
      <Label htmlFor="message">Additional Requirements</Label>
      <Textarea 
        id="message" 
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        className="min-h-[100px]"
        required
      />
    </div>
  );
};

export default MessageInput;
