
import React from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useEnquiryForm } from "@/hooks/useEnquiryForm";
import { FacilityItem } from "@/types/conferenceSupplier";

// Import the components
import ContactInformation from "./form/ContactInformation";
import EnquiryDateSelection from "./form/EnquiryDateSelection";
import RoomOptions from "./form/RoomOptions";
import MessageInput from "./form/MessageInput";
import ConferenceOptions from "./form/ConferenceOptions";
import RestaurantOptions from "./form/RestaurantOptions";

interface EnquiryFormProps {
  venueCategory: string;
  roomTypes?: Array<{id: string, name: string}>;
  basisOptions?: string[];
  capacity?: number;
  diningPackages?: Array<{id: string, name: string}>;
  diningSections?: Array<{id: string, name: string}>;
  facilitiesOffered?: FacilityItem[];
}

const EnquiryForm = ({ 
  venueCategory, 
  roomTypes = [], 
  basisOptions = [], 
  capacity,
  diningPackages = [],
  diningSections = [],
  facilitiesOffered = []
}: EnquiryFormProps) => {
  const {
    // Contact information
    name, setName, email, setEmail, phone, setPhone, message, setMessage,
    
    // Dates
    startDate, setStartDate, endDate, setEndDate,
    
    // Room details
    roomCount, setRoomCount, selectedRoomType, setSelectedRoomType, 
    selectedBasis, setSelectedBasis,
    
    // Conference details
    attendees, setAttendees, layout, setLayout, equipment, setEquipment,
    eventType, setEventType, venueSpace, setVenueSpace,
    
    // Restaurant details
    guests, setGuests, cuisine, setCuisine, seatingType, setSeatingType,
    packageType, setPackageType, diningSection, setDiningSection,
    specialRequirements, setSpecialRequirements, eventTime, setEventTime,
    
    // Submit handler
    handleSubmitEnquiry
  } = useEnquiryForm({ 
    venueCategory, 
    roomTypes, 
    basisOptions, 
    capacity,
    diningPackages,
    diningSections
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle>Send an Enquiry</CardTitle>
        <CardDescription>
          Contact this venue directly to learn more or make a booking
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmitEnquiry} className="space-y-4">
          <ContactInformation 
            name={name} 
            setName={setName} 
            email={email} 
            setEmail={setEmail} 
            phone={phone} 
            setPhone={setPhone} 
          />

          {/* Conference-specific fields */}
          {venueCategory === 'conference' && (
            <ConferenceOptions
              attendees={attendees}
              setAttendees={setAttendees}
              layout={layout}
              setLayout={setLayout}
              equipment={equipment}
              setEquipment={setEquipment}
              eventType={eventType}
              setEventType={setEventType}
              venueSpace={venueSpace}
              setVenueSpace={setVenueSpace}
              maxCapacity={capacity}
              venueSpaces={roomTypes} // reusing roomTypes for venue spaces
              startDate={startDate}
              setStartDate={setStartDate}
              endDate={endDate}
              setEndDate={setEndDate}
              facilitiesOffered={facilitiesOffered}
            />
          )}

          {/* Restaurant-specific fields */}
          {venueCategory === 'restaurants' && (
            <RestaurantOptions
              guests={guests}
              setGuests={setGuests}
              cuisine={cuisine}
              setCuisine={setCuisine}
              seatingType={seatingType}
              setSeatingType={setSeatingType}
              packageType={packageType}
              setPackageType={setPackageType}
              diningSection={diningSection}
              setDiningSection={setDiningSection}
              specialRequirements={specialRequirements}
              setSpecialRequirements={setSpecialRequirements}
              sections={diningSections}
              packages={diningPackages}
              startDate={startDate}
              setStartDate={setStartDate}
              eventTime={eventTime}
              setEventTime={setEventTime}
            />
          )}

          {/* Date selection for rooms category only */}
          {venueCategory === 'rooms' && (
            <EnquiryDateSelection
              venueCategory={venueCategory}
              eventType={eventType}
              startDate={startDate}
              setStartDate={setStartDate}
              endDate={endDate}
              setEndDate={setEndDate}
            />
          )}

          {/* Room-specific fields */}
          {venueCategory === 'rooms' && (
            <RoomOptions 
              roomCount={roomCount} 
              setRoomCount={setRoomCount}
              selectedRoomType={selectedRoomType}
              setSelectedRoomType={setSelectedRoomType}
              selectedBasis={selectedBasis}
              setSelectedBasis={setSelectedBasis}
              roomTypes={roomTypes}
              basisOptions={basisOptions}
            />
          )}

          <MessageInput message={message} setMessage={setMessage} />
          
          <Button type="submit" className="w-full">Send Enquiry</Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default EnquiryForm;
