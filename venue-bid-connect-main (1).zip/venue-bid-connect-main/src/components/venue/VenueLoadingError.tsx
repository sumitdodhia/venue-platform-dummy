
import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";

interface VenueLoadingErrorProps {
  isLoading?: boolean;
}

const VenueLoadingError = ({ isLoading }: VenueLoadingErrorProps) => {
  const navigate = useNavigate();
  
  if (isLoading) {
    return (
      <div className="text-center py-20">
        <p>Loading venue details...</p>
      </div>
    );
  }

  return (
    <div className="text-center py-20">
      <h2 className="text-2xl font-bold mb-4">Venue not found</h2>
      <Button onClick={() => navigate("/marketplace")}>Return to Marketplace</Button>
    </div>
  );
};

export default VenueLoadingError;
