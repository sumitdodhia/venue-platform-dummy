
import React from "react";

interface DiningPackage {
  id: string;
  name: string;
  description: string;
  pricePerPerson: number;
  includes: string[];
  minGuests?: number;
  maxGuests?: number;
}

interface RestaurantDiningPackagesProps {
  diningPackages: DiningPackage[];
}

const RestaurantDiningPackages = ({ diningPackages }: RestaurantDiningPackagesProps) => {
  if (!diningPackages || diningPackages.length === 0) {
    return null;
  }

  return (
    <div className="pt-6">
      <h3 className="text-xl font-semibold mb-4">Available Dining Packages</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {diningPackages.map((pkg) => (
          <div key={pkg.id} className="border p-4 rounded-md hover:border-primary/50 transition-colors">
            <h4 className="font-semibold text-lg">{pkg.name}</h4>
            <p className="text-sm text-muted-foreground mb-3">{pkg.description}</p>
            
            {pkg.includes && pkg.includes.length > 0 && (
              <div className="mt-2">
                <h5 className="text-sm font-medium">Includes:</h5>
                <ul className="list-disc list-inside text-sm text-muted-foreground mt-1">
                  {pkg.includes.map((item, idx) => (
                    <li key={idx}>{item}</li>
                  ))}
                </ul>
              </div>
            )}
            
            <div className="flex flex-wrap gap-2 mt-2">
              {pkg.minGuests && (
                <span className="text-xs bg-primary/10 px-2 py-1 rounded-md">
                  Min {pkg.minGuests} guests
                </span>
              )}
              {pkg.maxGuests && (
                <span className="text-xs bg-primary/10 px-2 py-1 rounded-md">
                  Max {pkg.maxGuests} guests
                </span>
              )}
            </div>
            
            <div className="mt-2 text-right">
              <p className="text-lg font-semibold">${pkg.pricePerPerson}</p>
              <p className="text-xs text-muted-foreground">per person</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RestaurantDiningPackages;
