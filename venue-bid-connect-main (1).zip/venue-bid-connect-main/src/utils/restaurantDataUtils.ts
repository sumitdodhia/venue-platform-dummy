
import { toast } from 'sonner';
import { PartialRestaurantDetails, DiningSection, DiningPackage } from '@/types/restaurantSupplier';
import { 
  RESTAURANT_STORAGE_KEY, 
  DINING_SECTIONS_STORAGE_KEY, 
  DINING_PACKAGES_STORAGE_KEY 
} from '@/constants/restaurantStorageKeys';

// Helper function to reduce image sizes before storage
export const optimizeImages = (photos: string[]): string[] => {
  // For this implementation, we'll just limit the number of photos to reduce storage size
  // In a real app, you would resize/compress the images
  return photos.slice(0, 3);
};

// Load restaurant data from localStorage
export const loadRestaurantData = (): PartialRestaurantDetails | null => {
  try {
    const storedRestaurant = localStorage.getItem(RESTAURANT_STORAGE_KEY);
    const storedSections = localStorage.getItem(DINING_SECTIONS_STORAGE_KEY);
    const storedPackages = localStorage.getItem(DINING_PACKAGES_STORAGE_KEY);
    
    const restaurantData = storedRestaurant ? JSON.parse(storedRestaurant) : null;
    const sections = storedSections ? JSON.parse(storedSections) : [];
    const packages = storedPackages ? JSON.parse(storedPackages) : [];
    
    // Merge all data
    if (restaurantData) {
      return {
        ...restaurantData,
        sections,
        packages
      };
    }
    return null;
  } catch (error) {
    console.error("Error loading restaurant data:", error);
    toast.error("Failed to load restaurant data");
    return null;
  }
};

// Save restaurant details
export const saveRestaurantDetails = (details: PartialRestaurantDetails): PartialRestaurantDetails => {
  try {
    // Optimize images
    const optimizedPhotos = details.photos ? optimizeImages(details.photos) : [];
    
    // Create restaurant with ID if it doesn't exist
    const restaurantWithId: PartialRestaurantDetails = {
      ...details,
      photos: optimizedPhotos,
      id: details.id || `restaurant-${Date.now()}`
    };
    
    localStorage.setItem(RESTAURANT_STORAGE_KEY, JSON.stringify(restaurantWithId));
    return restaurantWithId;
  } catch (error) {
    console.error("Error saving restaurant details:", error);
    toast.error("Failed to save restaurant details");
    throw error;
  }
};

// Save dining sections
export const saveDiningSections = (sections: DiningSection[]): DiningSection[] => {
  try {
    localStorage.setItem(DINING_SECTIONS_STORAGE_KEY, JSON.stringify(sections));
    return sections;
  } catch (error) {
    console.error("Error saving dining sections:", error);
    toast.error("Failed to save dining sections");
    throw error;
  }
};

// Save dining packages
export const saveDiningPackages = (packages: DiningPackage[]): DiningPackage[] => {
  try {
    localStorage.setItem(DINING_PACKAGES_STORAGE_KEY, JSON.stringify(packages));
    return packages;
  } catch (error) {
    console.error("Error saving dining packages:", error);
    toast.error("Failed to save dining packages");
    throw error;
  }
};

// Publish restaurant (making it available in the marketplace)
export const publishRestaurant = (restaurant: PartialRestaurantDetails | null): PartialRestaurantDetails | null => {
  if (!restaurant) {
    toast.error("No restaurant data to publish");
    return null;
  }
  
  try {
    // Make sure restaurant has all required data
    if (!restaurant.name || !restaurant.cuisineType || !restaurant.capacity) {
      toast.error("Please complete all required restaurant information before publishing");
      return null;
    }
    
    // Mark as published
    const publishedRestaurant = {
      ...restaurant,
      isPublished: true,
      publishedAt: new Date().toISOString()
    };
    
    // Save to localStorage
    localStorage.setItem(RESTAURANT_STORAGE_KEY, JSON.stringify(publishedRestaurant));
    
    return publishedRestaurant;
  } catch (error) {
    console.error("Error publishing restaurant:", error);
    toast.error("Failed to publish restaurant");
    throw error;
  }
};
