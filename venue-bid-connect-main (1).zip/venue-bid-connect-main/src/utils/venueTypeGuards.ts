
import { Venue, RoomVenue, ConferenceVenue, RestaurantVenue } from "@/types/venue";

// Type guard functions to check venue category
export function isRoomVenue(venue: Venue): venue is RoomVenue {
  return venue.category === 'rooms';
}

export function isConferenceVenue(venue: Venue): venue is ConferenceVenue {
  return venue.category === 'conference';
}

export function isRestaurantVenue(venue: Venue): venue is RestaurantVenue {
  return venue.category === 'restaurants';
}
