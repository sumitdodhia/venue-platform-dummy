
import { PartialRestaurantDetails } from '@/types/restaurantSupplier';
import { 
  RESTAURANT_STORAGE_KEY, 
  DINING_SECTIONS_STORAGE_KEY, 
  DINING_PACKAGES_STORAGE_KEY 
} from '@/constants/restaurantStorageKeys';
import { RestaurantVenue } from '@/types/venue';

// Convert restaurant to venue format for marketplace
export const convertToVenue = (restaurantDetails: PartialRestaurantDetails): RestaurantVenue | null => {
  if (!restaurantDetails) return null;
  
  const defaultPhoto = "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=1770&auto=format&fit=crop&ixlib=rb-4.0.3";
  
  // Make sure sections have the correct photo format
  const sections = restaurantDetails.sections?.map(section => ({
    ...section,
    // Ensure photos array exists if there's at least a main photo
    photos: section.photos || (section.photo ? [section.photo] : [])
  })) || [];
  
  // Create default opening hours when they're missing or partial
  const defaultOpeningHours = {
    monday: "09:00-22:00",
    tuesday: "09:00-22:00",
    wednesday: "09:00-22:00",
    thursday: "09:00-22:00",
    friday: "09:00-23:00",
    saturday: "09:00-23:00",
    sunday: "09:00-22:00"
  };
  
  // Merge any provided opening hours with defaults
  const openingHours = restaurantDetails.openingHours ? {
    ...defaultOpeningHours,
    ...restaurantDetails.openingHours
  } : defaultOpeningHours;
  
  return {
    id: restaurantDetails.id || `restaurant-${Date.now()}`,
    title: restaurantDetails.name || "Unnamed Restaurant",
    location: restaurantDetails.location ? 
      `${restaurantDetails.location.city || ""}, ${restaurantDetails.location.country || ""}` : 
      "Location not specified",
    price: restaurantDetails.packages && restaurantDetails.packages.length > 0 ? 
      Math.min(...restaurantDetails.packages.map(p => p.pricePerPerson)) : 
      25,
    priceLabel: "/person",
    rating: restaurantDetails.rating || 4.5,
    imageUrl: restaurantDetails.photos && restaurantDetails.photos.length > 0 ? 
      restaurantDetails.photos[0] : defaultPhoto,
    photos: restaurantDetails.photos || [defaultPhoto],
    tags: [
      restaurantDetails.cuisineType || "Restaurant", 
      ...(restaurantDetails.facilities || []).slice(0, 3)
    ],
    category: "restaurants" as const,
    description: restaurantDetails.description || "",
    facilities: restaurantDetails.facilities || [],
    cuisineType: restaurantDetails.cuisineType,
    capacity: restaurantDetails.capacity,
    googleLocation: restaurantDetails.googleMapUrl,
    diningPackages: restaurantDetails.packages || [],
    diningSections: sections,
    priceRange: restaurantDetails.priceRange,
    openingHours: openingHours,
  };
};

// Get all restaurants as venues for marketplace
export const getRestaurantsAsVenues = (): RestaurantVenue[] => {
  try {
    const storedRestaurant = localStorage.getItem(RESTAURANT_STORAGE_KEY);
    const storedSections = localStorage.getItem(DINING_SECTIONS_STORAGE_KEY);
    const storedPackages = localStorage.getItem(DINING_PACKAGES_STORAGE_KEY);
    
    if (!storedRestaurant) return [];
    
    const restaurantData = JSON.parse(storedRestaurant);
    const sections = storedSections ? JSON.parse(storedSections) : [];
    const packages = storedPackages ? JSON.parse(storedPackages) : [];
    
    const completeRestaurant = {
      ...restaurantData,
      sections,
      packages
    };
    
    return [convertToVenue(completeRestaurant)].filter(Boolean) as RestaurantVenue[];
  } catch (error) {
    console.error("Error getting restaurants as venues:", error);
    return [];
  }
};

