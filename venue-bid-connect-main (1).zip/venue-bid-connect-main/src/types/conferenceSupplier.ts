
export type ConferenceVenueType = {
  id: string;
  name: string;
  type: string;
  description: string;
  photos: string[];
  maxCapacity: number;
  priceFrom: number;
  propertyId?: string;
};

export type VenueType = {
  id: string;
  name: string;
  type: string;
  description: string;
  photos: string[];
  maxCapacity: number;
  priceFrom: number;
  propertyId?: string;
};

export type FacilityItem = {
  name: string;
  isCharged: boolean;
  rate?: number;
  chargeType?: "Per Person" | "Per Event" | "Inclusive" | "Subject to Enquiry";
};

export type ConferenceVenueDetails = {
  id?: string;
  name: string;
  photos: string[];
  area: string;
  country: string;
  about: string;
  totalCapacity: number;
  facilitiesOffered: FacilityItem[];
  facilities?: string[];
  googleLocation: string;
};
