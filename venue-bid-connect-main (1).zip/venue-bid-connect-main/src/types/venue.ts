
// Common venue type shared across different venue categories
export interface BaseVenue {
  id: string;
  title: string;
  location: string;
  price: number;
  priceLabel: string;
  rating: number;
  imageUrl: string;
  tags: string[];
  category: 'rooms' | 'conference' | 'restaurants';
  totalReviews?: number;
  photos?: string[];
  facilities?: string[];
  googleLocation?: string;
  description?: string;
  about?: string;
}

// Adding specific venue interfaces for each category
export interface RoomVenue extends BaseVenue {
  category: 'rooms';
  totalRooms?: number;
  basisOffered?: string[];
  rooms?: any[];
}

export interface ConferenceVenue extends BaseVenue {
  category: 'conference';
  capacity?: number;
  venueTypes?: any[];
  facilitiesOffered?: {
    name: string;
    isCharged: boolean;
    rate?: number;
    chargeType?: "Per Person" | "Per Event" | "Inclusive" | "Subject to Enquiry";
  }[];
}

export interface DiningSection {
  id: string;
  name: string;
  description: string;
  capacity: number;
  isPrivate: boolean;
  isOutdoor: boolean;
  photo?: string;
  photos?: string[];
}

export interface DiningPackage {
  id: string;
  name: string;
  description: string;
  pricePerPerson: number;
  includes: string[];
  minGuests?: number;
  maxGuests?: number;
}

export interface RestaurantVenue extends BaseVenue {
  category: 'restaurants';
  cuisineType?: string;
  capacity?: number;
  diningSections?: DiningSection[];
  diningPackages?: DiningPackage[];
  openingHours?: {
    monday: string;
    tuesday: string;
    wednesday: string;
    thursday: string;
    friday: string;
    saturday: string;
    sunday: string;
  };
  priceRange?: 1 | 2 | 3 | 4;
}

// Combined venue type for places that need to handle all venue types
export type Venue = RoomVenue | ConferenceVenue | RestaurantVenue;
