
export type RoomType = {
  id: string;
  name: string;
  type: string;
  description: string;
  photos: string[];
  maxPax: number;
  priceFrom: number;
  numberOfRooms: number;
  propertyId?: string;
};

export type PropertyDetails = {
  id?: string;
  name: string;
  photos: string[];
  area: string;
  country: string;
  about: string;
  totalRooms: number;
  facilities: string[];
  googleLocation: string;
  basisOffered: string[];
  rating: number;
  ratingCount: number;
};
