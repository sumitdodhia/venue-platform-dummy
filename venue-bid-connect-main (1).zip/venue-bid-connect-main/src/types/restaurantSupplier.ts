
export interface DiningSection {
  id: string;
  name: string;
  description: string;
  capacity: number;
  isPrivate: boolean;
  isOutdoor: boolean;
  photo?: string;  // Main photo
  photos?: string[]; // All photos including the main one
}

export interface DiningPackage {
  id: string;
  name: string;
  description: string;
  pricePerPerson: number;
  includes: string[];
  minGuests?: number;
  maxGuests?: number;
}

export interface RestaurantDetails {
  id: string;
  name: string;
  description: string;
  location: {
    address: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
    googleMapUrl?: string;
  };
  cuisineType: string;
  priceRange: 1 | 2 | 3 | 4; // $ to $$$$
  capacity: number;
  openingHours: {
    monday: string;
    tuesday: string;
    wednesday: string;
    thursday: string;
    friday: string;
    saturday: string;
    sunday: string;
  };
  facilities: string[];
  photos: string[];
  sections: DiningSection[];
  packages: DiningPackage[];
  minimumNotice: number; // hours
  rating?: number;
  ratingCount?: number;
  googleMapUrl?: string;
  isPublished?: boolean;
  publishedAt?: string;
  menuPdf?: string;
}

export interface PartialRestaurantDetails extends Partial<
  Omit<RestaurantDetails, 'location' | 'openingHours' | 'priceRange'>
> {
  location?: Partial<RestaurantDetails['location']>;
  openingHours?: Partial<RestaurantDetails['openingHours']>;
  priceRange?: 1 | 2 | 3 | 4;
  menuPdf?: string;
}
