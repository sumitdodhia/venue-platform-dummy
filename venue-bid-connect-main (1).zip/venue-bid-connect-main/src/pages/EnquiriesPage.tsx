
import EnquiriesList from "@/components/dashboard/EnquiriesList";

const EnquiriesPage = () => {
  return <EnquiriesList />;
};

export default EnquiriesPage;
