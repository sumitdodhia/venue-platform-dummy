
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const ActiveBidsPage = () => {
  return (
    <div className="container mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Active Bids</h1>
        <p className="text-muted-foreground">
          Track the progress of your active bid requests
        </p>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Your Active Bid Requests</CardTitle>
        </CardHeader>
        <CardContent>
          <p>Active bids content will go here...</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default ActiveBidsPage;
