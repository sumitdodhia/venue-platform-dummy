
import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import ResponsesList from "@/components/client/ResponsesList";
import ResponseFilters from "@/components/client/ResponseFilters";

// Mock data for responses
const mockResponses = [
  {
    id: "1",
    enquiryId: "e1",
    supplierName: "Grand Hotel",
    venueName: "Grand Ballroom",
    price: "$5,000",
    description: "Our grand ballroom can accommodate 150 people with full catering services.",
    status: "new",
    submittedDate: "2025-05-15",
    catering: "Full service with customizable menu",
    availability: "Available on requested dates",
    notes: "Premium decoration included in price"
  },
  {
    id: "2",
    enquiryId: "e1",
    supplierName: "City Conference Center",
    venueName: "Executive Meeting Room",
    price: "$3,200",
    description: "Professional meeting space with state-of-the-art AV equipment.",
    status: "reviewed",
    submittedDate: "2025-05-14",
    catering: "Coffee and snacks included",
    availability: "Available on requested dates",
    notes: "Free parking for all attendees"
  },
  {
    id: "3",
    enquiryId: "e2",
    supplierName: "Riverside Venue",
    venueName: "Garden Pavilion",
    price: "$4,500",
    description: "Beautiful outdoor venue with contingency indoor space.",
    status: "accepted",
    submittedDate: "2025-05-10",
    menu: "BBQ and seafood options available",
    availability: "Available on requested dates",
    notes: "Sound system included in price"
  },
  {
    id: "4",
    enquiryId: "e3",
    supplierName: "Mountain Retreat",
    venueName: "Summit Hall",
    price: "$6,800",
    description: "Exclusive mountaintop venue with breathtaking views.",
    status: "declined",
    submittedDate: "2025-05-08",
    catering: "Farm to table dining included",
    availability: "Limited availability",
    notes: "Transportation can be arranged at additional cost"
  }
];

const ClientResponsesPage = () => {
  const [activeTab, setActiveTab] = useState("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  
  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };
  
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Responses</h1>
        <p className="text-muted-foreground">View and manage responses to your enquiries</p>
      </div>
      
      <ResponseFilters 
        selectedFilter={filterStatus}
        onFilterChange={setFilterStatus}
      />
      
      <Card>
        <CardContent className="p-6">
          <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="all">All Responses</TabsTrigger>
              <TabsTrigger value="pending">Pending Review</TabsTrigger>
              <TabsTrigger value="accepted">Accepted</TabsTrigger>
              <TabsTrigger value="declined">Declined</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all">
              <ResponsesList responses={mockResponses} />
            </TabsContent>
            
            <TabsContent value="pending">
              <ResponsesList responses={mockResponses.filter(r => r.status === "new" || r.status === "reviewed")} />
            </TabsContent>
            
            <TabsContent value="accepted">
              <ResponsesList responses={mockResponses.filter(r => r.status === "accepted")} />
            </TabsContent>
            
            <TabsContent value="declined">
              <ResponsesList responses={mockResponses.filter(r => r.status === "declined")} />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default ClientResponsesPage;
