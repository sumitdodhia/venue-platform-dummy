
import IndexPage from "./IndexPage";

const HomePage = () => {
  return <IndexPage />;
};

export default HomePage;
