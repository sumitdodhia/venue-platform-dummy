
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import BidResponsesList from "@/components/client/BidResponsesList";
import ResponseFilters from "@/components/client/ResponseFilters";

const ClientResponsesPage = () => {
  const [filterStatus, setFilterStatus] = useState<string>("all");
  
  return (
    <div className="container mx-auto space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Responses to Your Bids</h1>
          <p className="text-muted-foreground">
            Review and manage all responses to your bid requests
          </p>
        </div>
      </div>
      
      <Card>
        <CardHeader className="px-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <CardTitle>Bid Responses</CardTitle>
            <ResponseFilters 
              selectedFilter={filterStatus}
              onFilterChange={setFilterStatus}
            />
          </div>
        </CardHeader>
        <CardContent className="px-6">
          <Tabs defaultValue="received" className="w-full">
            <TabsList className="mb-6">
              <TabsTrigger value="received">Received</TabsTrigger>
              <TabsTrigger value="accepted">Accepted</TabsTrigger>
              <TabsTrigger value="declined">Declined</TabsTrigger>
            </TabsList>
            <TabsContent value="received">
              <BidResponsesList status="received" />
            </TabsContent>
            <TabsContent value="accepted">
              <BidResponsesList status="accepted" />
            </TabsContent>
            <TabsContent value="declined">
              <BidResponsesList status="declined" />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default ClientResponsesPage;
