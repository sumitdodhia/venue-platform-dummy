
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import EnquiryStatusBadge from "@/components/dashboard/EnquiryStatusBadge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

// Mock data for active bids
const activeBids = [
  {
    enquiryId: "ENQ-230",
    title: "Annual Sales Conference",
    venue: "Marriott Downtown",
    price: "$4,800",
    supplier: "Marriott Hotels",
    date: "2025-07-10",
    status: "active",
    responseCount: 3
  },
  {
    enquiryId: "ENQ-245",
    title: "Executive Retreat",
    venue: "Lakeside Resort & Spa",
    price: "$12,500",
    supplier: "Luxury Resorts Group",
    date: "2025-08-15",
    status: "active",
    responseCount: 5
  },
  {
    enquiryId: "ENQ-248",
    title: "Team Building Workshop",
    venue: "Urban Conference Center",
    price: "$3,200",
    supplier: "City Venues Inc.",
    date: "2025-06-22",
    status: "awarded",
    responseCount: 2
  }
];

const ActiveBidsPage = () => {
  const [filter, setFilter] = useState("all");
  
  const filteredBids = filter === "all" 
    ? activeBids 
    : activeBids.filter(bid => bid.status === filter);
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Active Bids</h1>
          <p className="text-muted-foreground">
            View and manage all active bids for your enquiries
          </p>
        </div>
        <Button asChild>
          <Link to="/dashboard/new-enquiry">Create New Enquiry</Link>
        </Button>
      </div>
      
      <div className="flex gap-2 mb-6">
        <Button 
          variant={filter === "all" ? "default" : "outline"} 
          onClick={() => setFilter("all")}
        >
          All Bids
        </Button>
        <Button 
          variant={filter === "active" ? "default" : "outline"} 
          onClick={() => setFilter("active")}
        >
          Active
        </Button>
        <Button 
          variant={filter === "awarded" ? "default" : "outline"} 
          onClick={() => setFilter("awarded")}
        >
          Awarded
        </Button>
      </div>
      
      <Card>
        <CardHeader className="pb-2">
          <CardTitle>Your Bids</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Enquiry ID</TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Venue</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Supplier</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Responses</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredBids.map((bid) => (
                <TableRow key={bid.enquiryId}>
                  <TableCell className="font-medium">{bid.enquiryId}</TableCell>
                  <TableCell>{bid.title}</TableCell>
                  <TableCell>{bid.venue}</TableCell>
                  <TableCell>{bid.price}</TableCell>
                  <TableCell>{bid.supplier}</TableCell>
                  <TableCell>{bid.date}</TableCell>
                  <TableCell>
                    <EnquiryStatusBadge status={bid.status} />
                  </TableCell>
                  <TableCell>{bid.responseCount}</TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm" asChild>
                      <Link to={`/dashboard/enquiries/${bid.enquiryId}`}>
                        View Details
                      </Link>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {filteredBids.length === 0 && (
                <TableRow>
                  <TableCell colSpan={9} className="text-center py-10">
                    No bids found matching the selected filter.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default ActiveBidsPage;
