
import { Link } from "react-router-dom";
import RegisterForm from "@/components/auth/RegisterForm";

const RegisterPage = () => {
  return (
    <main className="flex-1 flex items-center justify-center p-4 bg-muted/30">
      <div className="w-full max-w-md">
        <RegisterForm />
        
        <div className="mt-4 text-center">
          <Link to="/" className="text-sm text-primary hover:underline">
            Back to home
          </Link>
        </div>
      </div>
    </main>
  );
};

export default RegisterPage;
