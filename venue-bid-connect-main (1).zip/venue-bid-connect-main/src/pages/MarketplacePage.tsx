
import Marketplace from "@/components/marketplace/Marketplace";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { PlusCircle } from "lucide-react";
import { useState } from "react";
import InlineEnquiryForm from "@/components/marketplace/InlineEnquiryForm";

const MarketplacePage = () => {
  const [isEnquiryFormOpen, setIsEnquiryFormOpen] = useState(false);
  
  const handleNewBidRequest = () => {
    setIsEnquiryFormOpen(true);
    
    // Show a toast notification
    toast.success("Opening bid request form", {
      description: "Fill out the form to submit your requirements"
    });
  };
  
  return (
    <>
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold">Restaurants, Rooms & Conference Venues</h1>
          <Button 
            className="bg-primary hover:bg-primary/90 gap-2"
            onClick={handleNewBidRequest}
          >
            <PlusCircle className="h-4 w-4" />
            Submit New Bid Request
          </Button>
        </div>
      </div>
      <Marketplace />
      
      <InlineEnquiryForm 
        isOpen={isEnquiryFormOpen}
        onClose={() => setIsEnquiryFormOpen(false)}
      />
    </>
  );
};

export default MarketplacePage;
