
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { TabsContent, Tabs } from "@/components/ui/tabs";
import EnquiryCategoryTabs, { EnquiryCategory } from "@/components/enquiry/EnquiryCategoryTabs";
import EnquiryHeader from "@/components/enquiry/EnquiryHeader";
import RoomsForm from "@/components/enquiry/RoomsForm";
import ConferenceForm from "@/components/enquiry/ConferenceForm";
import RestaurantsForm from "@/components/enquiry/RestaurantsForm";

const NewEnquiryPage = () => {
  const navigate = useNavigate();
  const [category, setCategory] = useState<EnquiryCategory>("rooms");

  const handleSubmitSuccess = () => {
    navigate("/dashboard");
  };

  const handleCategoryChange = (value: string) => {
    setCategory(value as EnquiryCategory);
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      <EnquiryHeader />

      <div className="bg-card border rounded-lg p-6 mt-8 shadow-sm">
        <Tabs value={category} className="space-y-6" onValueChange={handleCategoryChange}>
          <EnquiryCategoryTabs 
            category={category}
            onCategoryChange={handleCategoryChange}
          />
          
          <TabsContent value="rooms">
            <RoomsForm onSubmitSuccess={handleSubmitSuccess} />
          </TabsContent>
          
          <TabsContent value="conference">
            <ConferenceForm onSubmitSuccess={handleSubmitSuccess} />
          </TabsContent>
          
          <TabsContent value="restaurants">
            <RestaurantsForm onSubmitSuccess={handleSubmitSuccess} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default NewEnquiryPage;
