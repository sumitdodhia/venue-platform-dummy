
import { Link } from "react-router-dom";
import SupplierRegisterForm from "@/components/auth/SupplierRegisterForm";

const SupplierRegisterPage = () => {
  return (
    <main className="flex-1 flex items-center justify-center p-4 bg-muted/30">
      <div className="w-full max-w-md">
        <SupplierRegisterForm />
        
        <div className="mt-4 text-center">
          <p className="text-sm text-muted-foreground mb-2">
            Complete your profile setup after registration to add business details.
          </p>
          <Link to="/suppliers" className="text-sm text-primary hover:underline">
            Back to suppliers
          </Link>
        </div>
      </div>
    </main>
  );
};

export default SupplierRegisterPage;
