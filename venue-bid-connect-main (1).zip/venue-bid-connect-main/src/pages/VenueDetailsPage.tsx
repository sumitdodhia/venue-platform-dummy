
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import VenueContent from '@/components/venue/VenueContent';
import VenueLoadingError from '@/components/venue/VenueLoadingError';
import { useVenuesFromDatabase } from '@/hooks/useVenuesFromDatabase';
import { Venue } from '@/types/venue';

const VenueDetailsPage = () => {
  const { venueId } = useParams<{ venueId: string }>();
  const navigate = useNavigate();
  const [venue, setVenue] = useState<Venue | null>(null);
  const [relatedVenues, setRelatedVenues] = useState<Venue[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Get venues from database only
  const { venues: dbVenues, isLoading: dbLoading } = useVenuesFromDatabase();

  useEffect(() => {
    const fetchVenue = async () => {
      setIsLoading(true);
      setError(null);
      
      try {
        console.log("All venues from database:", dbVenues);
        console.log("Looking for venue ID:", venueId);
        
        // Find the venue with matching ID in database venues only
        const foundVenue = dbVenues.find(venue => venue.id === venueId);
        
        if (foundVenue) {
          console.log("Found venue:", foundVenue);
          setVenue(foundVenue);
          
          // Get related venues of the same category
          const relatedVenuesData = dbVenues
            .filter(v => v.category === foundVenue.category && v.id !== venueId)
            .slice(0, 3);
            
          setRelatedVenues(relatedVenuesData);
        } else {
          console.log("Venue not found with ID:", venueId);
          setError("Venue not found");
        }
      } catch (err) {
        console.error("Error fetching venue:", err);
        setError("Failed to load venue details");
      } finally {
        setIsLoading(false);
      }
    };

    // Wait for database venues to load before searching
    if (!dbLoading && dbVenues.length >= 0) {
      fetchVenue();
    }
  }, [venueId, dbVenues, dbLoading]);

  if (isLoading || dbLoading) {
    return <VenueLoadingError isLoading={true} />;
  }

  if (error || !venue) {
    return <VenueLoadingError />;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Button variant="outline" onClick={() => navigate('/marketplace')} className="mb-4">
          Back to marketplace
        </Button>
      </div>
      
      <VenueContent venue={venue} />
      
      {relatedVenues.length > 0 && (
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6">You might also like</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {relatedVenues.map(relatedVenue => (
              <div key={relatedVenue.id} className="border p-4 rounded-md">
                <h3 className="font-semibold mb-2">{relatedVenue.title}</h3>
                <p className="text-sm text-muted-foreground mb-4">{relatedVenue.location}</p>
                <Button onClick={() => navigate(`/venues/${relatedVenue.id}`)}>
                  View Details
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default VenueDetailsPage;
