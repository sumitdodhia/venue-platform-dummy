
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const BookingsPage = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Bookings Management</h1>
        <p className="text-muted-foreground">Track and manage confirmed bookings</p>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Recent Bookings</CardTitle>
        </CardHeader>
        <CardContent>
          <p>Bookings listing will go here...</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default BookingsPage;
