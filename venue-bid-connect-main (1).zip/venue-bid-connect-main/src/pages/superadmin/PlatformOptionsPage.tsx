
import { useState } from "react";
import { 
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "@/components/ui/sonner";
import {
  Save,
  Plus,
  Edit,
  Trash2,
  Search,
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Define platform option types
interface OptionItem {
  id: string;
  name: string;
  value: string;
}

interface OptionCategory {
  id: string;
  name: string;
  description: string;
  items: OptionItem[];
}

// Mock data for platform options
const initialOptions: OptionCategory[] = [
  {
    id: "venue-types",
    name: "Venue Types",
    description: "Types of venues available in the platform",
    items: [
      { id: "venue-1", name: "Conference Hall", value: "conference_hall" },
      { id: "venue-2", name: "Meeting Room", value: "meeting_room" },
      { id: "venue-3", name: "Restaurant", value: "restaurant" },
      { id: "venue-4", name: "Hotel", value: "hotel" }
    ]
  },
  {
    id: "amenities",
    name: "Amenities",
    description: "Amenities and facilities available in venues",
    items: [
      { id: "amenity-1", name: "Wi-Fi", value: "wifi" },
      { id: "amenity-2", name: "Projector", value: "projector" },
      { id: "amenity-3", name: "Catering", value: "catering" },
      { id: "amenity-4", name: "Parking", value: "parking" },
      { id: "amenity-5", name: "Accessible", value: "accessible" }
    ]
  },
  {
    id: "event-types",
    name: "Event Types",
    description: "Types of events supported by venues",
    items: [
      { id: "event-1", name: "Conference", value: "conference" },
      { id: "event-2", name: "Wedding", value: "wedding" },
      { id: "event-3", name: "Corporate Party", value: "corporate_party" },
      { id: "event-4", name: "Exhibition", value: "exhibition" }
    ]
  },
  {
    id: "meal-types",
    name: "Meal Types",
    description: "Types of meals offered by venues",
    items: [
      { id: "meal-1", name: "Breakfast", value: "breakfast" },
      { id: "meal-2", name: "Lunch", value: "lunch" },
      { id: "meal-3", name: "Dinner", value: "dinner" },
      { id: "meal-4", name: "Buffet", value: "buffet" }
    ]
  },
  {
    id: "currencies",
    name: "Currencies",
    description: "Available currencies for pricing",
    items: [
      { id: "currency-1", name: "US Dollar", value: "USD" },
      { id: "currency-2", name: "Euro", value: "EUR" },
      { id: "currency-3", name: "British Pound", value: "GBP" }
    ]
  },
  {
    id: "room-types",
    name: "Room Types",
    description: "Types of hotel rooms",
    items: [
      { id: "room-1", name: "Single", value: "single" },
      { id: "room-2", name: "Double", value: "double" },
      { id: "room-3", name: "Suite", value: "suite" },
      { id: "room-4", name: "Executive", value: "executive" }
    ]
  }
];

const PlatformOptionsPage = () => {
  const [options, setOptions] = useState<OptionCategory[]>(initialOptions);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<OptionCategory | null>(null);
  
  // Dialog states
  const [categoryDialogOpen, setCategoryDialogOpen] = useState(false);
  const [itemDialogOpen, setItemDialogOpen] = useState(false);
  const [currentCategory, setCurrentCategory] = useState<OptionCategory | null>(null);
  const [currentItem, setCurrentItem] = useState<OptionItem | null>(null);
  const [editingExisting, setEditingExisting] = useState(false);
  
  // Filter categories based on search query
  const filteredCategories = options.filter(category =>
    category.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    category.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    category.items.some(item => item.name.toLowerCase().includes(searchQuery.toLowerCase()))
  );
  
  const handleAddCategory = () => {
    setCurrentCategory({
      id: "",
      name: "",
      description: "",
      items: []
    });
    setEditingExisting(false);
    setCategoryDialogOpen(true);
  };
  
  const handleEditCategory = (category: OptionCategory) => {
    setCurrentCategory({...category});
    setEditingExisting(true);
    setCategoryDialogOpen(true);
  };
  
  const handleDeleteCategory = (categoryId: string) => {
    setOptions(options.filter(cat => cat.id !== categoryId));
    if (selectedCategory?.id === categoryId) {
      setSelectedCategory(null);
    }
    toast.success("Category deleted successfully");
  };
  
  const handleSaveCategory = () => {
    if (!currentCategory) return;
    
    // Generate slug-like ID if new category
    if (!editingExisting) {
      currentCategory.id = currentCategory.name.toLowerCase().replace(/\s+/g, '-');
    }
    
    if (editingExisting) {
      // Update existing category
      setOptions(options.map(cat => 
        cat.id === currentCategory.id ? currentCategory : cat
      ));
      
      // Update selectedCategory if it's the one being edited
      if (selectedCategory?.id === currentCategory.id) {
        setSelectedCategory(currentCategory);
      }
    } else {
      // Add new category
      setOptions([...options, currentCategory]);
    }
    
    setCategoryDialogOpen(false);
    toast.success(`Category ${editingExisting ? 'updated' : 'added'} successfully`);
  };
  
  const handleAddItem = () => {
    if (!selectedCategory) return;
    
    setCurrentItem({
      id: "",
      name: "",
      value: ""
    });
    setEditingExisting(false);
    setItemDialogOpen(true);
  };
  
  const handleEditItem = (item: OptionItem) => {
    setCurrentItem({...item});
    setEditingExisting(true);
    setItemDialogOpen(true);
  };
  
  const handleDeleteItem = (itemId: string) => {
    if (!selectedCategory) return;
    
    const updatedCategory = {
      ...selectedCategory,
      items: selectedCategory.items.filter(item => item.id !== itemId)
    };
    
    setOptions(options.map(cat => 
      cat.id === selectedCategory.id ? updatedCategory : cat
    ));
    
    setSelectedCategory(updatedCategory);
    toast.success("Option deleted successfully");
  };
  
  const handleSaveItem = () => {
    if (!currentItem || !selectedCategory) return;
    
    // Generate ID if new item
    if (!editingExisting) {
      currentItem.id = `${selectedCategory.id}-${Date.now()}`;
    }
    
    // Generate value from name if not provided
    if (!currentItem.value) {
      currentItem.value = currentItem.name.toLowerCase().replace(/\s+/g, '_');
    }
    
    let updatedItems;
    if (editingExisting) {
      // Update existing item
      updatedItems = selectedCategory.items.map(item => 
        item.id === currentItem.id ? currentItem : item
      );
    } else {
      // Add new item
      updatedItems = [...selectedCategory.items, currentItem];
    }
    
    const updatedCategory = {
      ...selectedCategory,
      items: updatedItems
    };
    
    setOptions(options.map(cat => 
      cat.id === selectedCategory.id ? updatedCategory : cat
    ));
    
    setSelectedCategory(updatedCategory);
    setItemDialogOpen(false);
    toast.success(`Option ${editingExisting ? 'updated' : 'added'} successfully`);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Platform Options</h1>
          <p className="text-muted-foreground">Manage dropdown lists and platform options</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1">
          <CardHeader className="pb-3">
            <div className="flex justify-between items-center">
              <CardTitle>Categories</CardTitle>
              <Button size="sm" onClick={handleAddCategory}>
                <Plus className="h-4 w-4 mr-2" />
                New Category
              </Button>
            </div>
            <div className="relative mt-2">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search categories..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
          </CardHeader>
          <CardContent className="max-h-[500px] overflow-auto">
            <div className="space-y-2">
              {filteredCategories.map((category) => (
                <div 
                  key={category.id}
                  onClick={() => setSelectedCategory(category)}
                  className={`p-3 border rounded-md cursor-pointer flex justify-between items-center transition-colors ${
                    selectedCategory?.id === category.id 
                      ? "bg-primary/10 border-primary/20" 
                      : "hover:bg-muted"
                  }`}
                >
                  <div>
                    <p className="font-medium">{category.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {category.items.length} options
                    </p>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEditCategory(category);
                      }}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteCategory(category.id);
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
              {filteredCategories.length === 0 && (
                <div className="p-4 text-center text-muted-foreground">
                  No categories found
                </div>
              )}
            </div>
          </CardContent>
        </Card>
        
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>
                  {selectedCategory ? selectedCategory.name : "Select a Category"}
                </CardTitle>
                {selectedCategory && (
                  <CardDescription>{selectedCategory.description}</CardDescription>
                )}
              </div>
              {selectedCategory && (
                <Button size="sm" onClick={handleAddItem}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Option
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {selectedCategory ? (
              selectedCategory.items.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Option Name</TableHead>
                      <TableHead>Value</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedCategory.items.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell className="font-mono text-sm">{item.value}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => handleEditItem(item)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => handleDeleteItem(item.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center text-muted-foreground">
                  <p>No options added yet</p>
                  <Button variant="outline" className="mt-4" onClick={handleAddItem}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add First Option
                  </Button>
                </div>
              )
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center text-muted-foreground">
                <p>Select a category to manage its options</p>
                <p className="text-sm mt-2">Or create a new category using the button above</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* Dialog for adding/editing categories */}
      <Dialog open={categoryDialogOpen} onOpenChange={setCategoryDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingExisting ? "Edit Category" : "Add New Category"}
            </DialogTitle>
            <DialogDescription>
              {editingExisting 
                ? "Modify the category details below" 
                : "Create a new category for platform options"}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="category-name">Category Name</Label>
              <Input 
                id="category-name"
                value={currentCategory?.name || ""} 
                onChange={(e) => setCurrentCategory(curr => curr ? {...curr, name: e.target.value} : null)}
                placeholder="e.g., Venue Types"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="category-description">Description</Label>
              <Input
                id="category-description"
                value={currentCategory?.description || ""}
                onChange={(e) => setCurrentCategory(curr => curr ? {...curr, description: e.target.value} : null)}
                placeholder="e.g., Types of venues available in the platform"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setCategoryDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveCategory}>Save Category</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Dialog for adding/editing items */}
      <Dialog open={itemDialogOpen} onOpenChange={setItemDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingExisting ? "Edit Option" : "Add New Option"}
            </DialogTitle>
            <DialogDescription>
              {editingExisting 
                ? `Modify the option details for ${selectedCategory?.name}` 
                : `Add a new option to ${selectedCategory?.name}`}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="item-name">Option Name</Label>
              <Input 
                id="item-name"
                value={currentItem?.name || ""} 
                onChange={(e) => setCurrentItem(curr => curr ? {...curr, name: e.target.value} : null)}
                placeholder="e.g., Conference Hall"
              />
              <p className="text-xs text-muted-foreground">
                This is the display name shown to users
              </p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="item-value">Option Value</Label>
              <Input
                id="item-value"
                value={currentItem?.value || ""}
                onChange={(e) => setCurrentItem(curr => curr ? {...curr, value: e.target.value} : null)}
                placeholder="e.g., conference_hall"
              />
              <p className="text-xs text-muted-foreground">
                This is the value stored in the database (auto-generated if left empty)
              </p>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setItemDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveItem}>Save Option</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PlatformOptionsPage;
