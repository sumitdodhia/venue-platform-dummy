
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { User, Users, CreditCard, Check, Settings, Globe, List, Mail } from "lucide-react";
import { Link } from "react-router-dom";

const SuperadminDashboardPage = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Super Admin Dashboard</h1>
      <p className="text-muted-foreground">Manage suppliers, clients, and system settings.</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <DashboardCard
          title="Supplier Verification"
          description="Verify and manage supplier accounts"
          icon={<User className="h-6 w-6 text-primary" />}
          linkTo="/superadmin/suppliers"
          metrics={[
            { label: "Pending Verification", value: "5" },
            { label: "Verified Suppliers", value: "32" },
          ]}
        />
        
        <DashboardCard
          title="Client Management"
          description="Manage client accounts and access"
          icon={<Users className="h-6 w-6 text-primary" />}
          linkTo="/superadmin/clients"
          metrics={[
            { label: "Active Clients", value: "147" },
            { label: "Flagged Accounts", value: "3" },
          ]}
        />
        
        <DashboardCard
          title="System Settings"
          description="Email configuration and admin settings"
          icon={<Settings className="h-6 w-6 text-primary" />}
          linkTo="/superadmin/system-settings"
          metrics={[
            { label: "SendGrid Status", value: "Connected" },
            { label: "Email Templates", value: "8" },
          ]}
        />
        
        <DashboardCard
          title="Payment Integrations"
          description="Manage payment providers and settings"
          icon={<CreditCard className="h-6 w-6 text-primary" />}
          linkTo="/superadmin/payment-integrations"
          metrics={[
            { label: "Active Gateways", value: "2" },
            { label: "Last Transaction", value: "2h ago" },
          ]}
        />
        
        <DashboardCard
          title="Platform Options"
          description="Manage dropdown options across the platform"
          icon={<List className="h-6 w-6 text-primary" />}
          linkTo="/superadmin/platform-options"
          metrics={[
            { label: "Option Categories", value: "8" },
            { label: "Total Options", value: "124" },
          ]}
        />
      </div>
    </div>
  );
};

interface Metric {
  label: string;
  value: string;
}

interface DashboardCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  linkTo: string;
  metrics: Metric[];
}

const DashboardCard = ({ title, description, icon, linkTo, metrics }: DashboardCardProps) => {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">{title}</CardTitle>
          {icon}
        </div>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {metrics.map((metric, index) => (
            <div key={index} className="flex justify-between">
              <span className="text-sm text-muted-foreground">{metric.label}:</span>
              <span className="text-sm font-medium">{metric.value}</span>
            </div>
          ))}
        </div>
        <div className="mt-4">
          <Link 
            to={linkTo} 
            className="text-primary text-sm font-medium hover:underline"
          >
            Manage →
          </Link>
        </div>
      </CardContent>
    </Card>
  );
};

export default SuperadminDashboardPage;
