
import { useState } from "react";
import { Link } from "react-router-dom";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Check, X, Search } from "lucide-react";
import { faker } from "@faker-js/faker";

interface Supplier {
  id: string;
  name: string;
  email: string;
  businessName: string;
  registerDate: string;
  status: "pending" | "verified" | "rejected";
  type: "restaurant" | "conference" | "hotel" | "multiple";
  taxPin: string;
}

// Generate mock supplier data
const generateSuppliers = (count: number): Supplier[] => {
  return Array.from({ length: count }, () => ({
    id: faker.string.uuid(),
    name: faker.person.fullName(),
    email: faker.internet.email(),
    businessName: faker.company.name(),
    registerDate: faker.date.recent({ days: 30 }).toISOString().split('T')[0],
    status: faker.helpers.arrayElement(['pending', 'verified', 'rejected']),
    type: faker.helpers.arrayElement(['restaurant', 'conference', 'hotel', 'multiple']),
    taxPin: faker.finance.accountNumber()
  }));
};

const mockSuppliers = generateSuppliers(15);

const SupplierVerificationPage = () => {
  const [suppliers, setSuppliers] = useState<Supplier[]>(mockSuppliers);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  
  // Filter suppliers based on search query and status filter
  const filteredSuppliers = suppliers.filter(supplier => {
    const matchesSearch = 
      supplier.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      supplier.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      supplier.businessName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      supplier.taxPin.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || supplier.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });
  
  // Filter counts for badges
  const pendingCount = suppliers.filter(s => s.status === "pending").length;
  const verifiedCount = suppliers.filter(s => s.status === "verified").length;
  const rejectedCount = suppliers.filter(s => s.status === "rejected").length;
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Supplier Verification</h1>
          <p className="text-muted-foreground">Verify and manage supplier accounts</p>
        </div>
      </div>
      
      {/* Filters and search */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex gap-2">
          <Button 
            variant={statusFilter === "all" ? "default" : "outline"}
            size="sm"
            onClick={() => setStatusFilter("all")}
          >
            All ({suppliers.length})
          </Button>
          <Button 
            variant={statusFilter === "pending" ? "default" : "outline"}
            size="sm"
            onClick={() => setStatusFilter("pending")}
          >
            Pending ({pendingCount})
          </Button>
          <Button 
            variant={statusFilter === "verified" ? "default" : "outline"}
            size="sm"
            onClick={() => setStatusFilter("verified")}
          >
            Verified ({verifiedCount})
          </Button>
          <Button 
            variant={statusFilter === "rejected" ? "default" : "outline"}
            size="sm"
            onClick={() => setStatusFilter("rejected")}
          >
            Rejected ({rejectedCount})
          </Button>
        </div>
        
        <div className="relative w-full sm:w-auto">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search suppliers..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 w-full sm:w-[300px]"
          />
        </div>
      </div>
      
      {/* Suppliers table */}
      <div className="rounded-lg border shadow-sm overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Business Name</TableHead>
              <TableHead>Contact</TableHead>
              <TableHead>Tax PIN</TableHead>
              <TableHead>Register Date</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredSuppliers.map((supplier) => (
              <TableRow key={supplier.id}>
                <TableCell className="font-medium">{supplier.businessName}</TableCell>
                <TableCell>
                  <div>{supplier.name}</div>
                  <div className="text-muted-foreground text-sm">{supplier.email}</div>
                </TableCell>
                <TableCell>{supplier.taxPin}</TableCell>
                <TableCell>{supplier.registerDate}</TableCell>
                <TableCell>
                  <StatusBadge status={supplier.status} />
                </TableCell>
                <TableCell className="text-right">
                  <Button 
                    variant="outline" 
                    size="sm"
                    asChild
                  >
                    <Link to={`/superadmin/suppliers/${supplier.id}`}>
                      View Details
                    </Link>
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {filteredSuppliers.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8">
                  <div className="text-muted-foreground">No suppliers found</div>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

const StatusBadge = ({ status }: { status: string }) => {
  switch (status) {
    case "pending":
      return <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200">Pending</Badge>;
    case "verified":
      return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Verified</Badge>;
    case "rejected":
      return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Rejected</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

export default SupplierVerificationPage;
