
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const VenuesPage = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Venues Management</h1>
        <p className="text-muted-foreground">Manage and approve venue listings</p>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Venues List</CardTitle>
        </CardHeader>
        <CardContent>
          <p>Venues listing and approval interface will go here...</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default VenuesPage;
