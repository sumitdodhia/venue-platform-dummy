
import { useState } from "react";
import { 
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/components/ui/sonner";
import { Mail, User, Key, Send, Save } from "lucide-react";

const SystemSettingsPage = () => {
  // Email settings
  const [emailSettings, setEmailSettings] = useState({
    sendgridApiKey: "SG.xxxxxxxxxxxxxxxxxxxxxxxxxxx",
    fromEmail: "noreply@venuebid.com",
    fromName: "VenueBid",
    testMode: false,
    enquiryTemplate: "d-12345678abcdefg",
    bidTemplate: "d-87654321abcdefg",
    welcomeTemplate: "d-11223344abcdefg",
  });
  
  // Admin account settings
  const [adminSettings, setAdminSettings] = useState({
    adminEmail: "admin@venuebid.com",
    adminName: "System Administrator",
    currentPassword: "",
    newPassword: "",
    confirmPassword: ""
  });
  
  const handleEmailSettingChange = (field: keyof typeof emailSettings, value: any) => {
    setEmailSettings(prev => ({ ...prev, [field]: value }));
  };
  
  const handleAdminSettingChange = (field: keyof typeof adminSettings, value: string) => {
    setAdminSettings(prev => ({ ...prev, [field]: value }));
  };
  
  const handleSaveEmailSettings = () => {
    // In a real application, you'd save these to your backend
    toast.success("Email settings saved successfully");
  };
  
  const handleSaveAdminSettings = () => {
    if (adminSettings.newPassword && adminSettings.newPassword.length < 8) {
      toast.error("Password must be at least 8 characters");
      return;
    }
    
    if (adminSettings.newPassword !== adminSettings.confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }
    
    // In a real application, you'd validate the current password and save changes
    toast.success("Admin settings saved successfully");
  };
  
  const handleTestEmail = () => {
    // In a real application, you'd send a test email
    toast.success("Test email sent successfully. Check your inbox.");
  };
  
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">System Settings</h1>
        <p className="text-muted-foreground">Manage email configuration and admin settings</p>
      </div>
      
      <Tabs defaultValue="email">
        <TabsList className="grid w-full md:w-auto grid-cols-2">
          <TabsTrigger value="email">Email Configuration</TabsTrigger>
          <TabsTrigger value="account">Admin Account</TabsTrigger>
        </TabsList>
        
        <TabsContent value="email">
          <Card className="mt-4">
            <CardHeader>
              <CardTitle>Email Configuration</CardTitle>
              <CardDescription>Configure SendGrid integration and email templates</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">SendGrid Configuration</h3>
                
                <div className="grid gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="sendgrid-api-key">SendGrid API Key</Label>
                    <div className="flex">
                      <Input 
                        id="sendgrid-api-key"
                        type="password" 
                        value={emailSettings.sendgridApiKey} 
                        onChange={(e) => handleEmailSettingChange('sendgridApiKey', e.target.value)}
                        className="flex-1"
                      />
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Your SendGrid API key for sending emails
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="from-email">From Email</Label>
                      <Input 
                        id="from-email"
                        type="email" 
                        value={emailSettings.fromEmail} 
                        onChange={(e) => handleEmailSettingChange('fromEmail', e.target.value)}
                      />
                    </div>
                    
                    <div className="grid gap-2">
                      <Label htmlFor="from-name">From Name</Label>
                      <Input 
                        id="from-name"
                        value={emailSettings.fromName} 
                        onChange={(e) => handleEmailSettingChange('fromName', e.target.value)}
                      />
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="test-mode"
                      checked={emailSettings.testMode}
                      onCheckedChange={(checked) => handleEmailSettingChange('testMode', checked)}
                    />
                    <Label htmlFor="test-mode">Enable Test Mode</Label>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4 pt-4 border-t">
                <h3 className="text-lg font-medium">Email Templates</h3>
                
                <div className="grid gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="enquiry-template">Enquiry Notification Template ID</Label>
                    <Input 
                      id="enquiry-template"
                      value={emailSettings.enquiryTemplate} 
                      onChange={(e) => handleEmailSettingChange('enquiryTemplate', e.target.value)}
                    />
                    <p className="text-sm text-muted-foreground">
                      SendGrid template ID for enquiry notifications
                    </p>
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="bid-template">Bid Response Template ID</Label>
                    <Input 
                      id="bid-template"
                      value={emailSettings.bidTemplate} 
                      onChange={(e) => handleEmailSettingChange('bidTemplate', e.target.value)}
                    />
                    <p className="text-sm text-muted-foreground">
                      SendGrid template ID for bid notifications
                    </p>
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="welcome-template">Welcome Email Template ID</Label>
                    <Input 
                      id="welcome-template"
                      value={emailSettings.welcomeTemplate} 
                      onChange={(e) => handleEmailSettingChange('welcomeTemplate', e.target.value)}
                    />
                    <p className="text-sm text-muted-foreground">
                      SendGrid template ID for welcome emails
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between border-t pt-4">
              <Button variant="outline" onClick={handleTestEmail}>
                <Send className="mr-2 h-4 w-4" />
                Send Test Email
              </Button>
              <Button onClick={handleSaveEmailSettings}>
                <Save className="mr-2 h-4 w-4" />
                Save Email Settings
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="account">
          <Card className="mt-4">
            <CardHeader>
              <CardTitle>Admin Account</CardTitle>
              <CardDescription>Update your administrator account details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Account Information</h3>
                
                <div className="grid gap-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="admin-email">Email Address</Label>
                      <div className="flex">
                        <div className="flex items-center px-3 border rounded-l-md bg-muted">
                          <Mail className="h-4 w-4 text-muted-foreground" />
                        </div>
                        <Input 
                          id="admin-email"
                          type="email" 
                          value={adminSettings.adminEmail} 
                          onChange={(e) => handleAdminSettingChange('adminEmail', e.target.value)}
                          className="rounded-l-none"
                        />
                      </div>
                    </div>
                    
                    <div className="grid gap-2">
                      <Label htmlFor="admin-name">Full Name</Label>
                      <div className="flex">
                        <div className="flex items-center px-3 border rounded-l-md bg-muted">
                          <User className="h-4 w-4 text-muted-foreground" />
                        </div>
                        <Input 
                          id="admin-name"
                          value={adminSettings.adminName} 
                          onChange={(e) => handleAdminSettingChange('adminName', e.target.value)}
                          className="rounded-l-none"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4 pt-4 border-t">
                <h3 className="text-lg font-medium">Change Password</h3>
                
                <div className="grid gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="current-password">Current Password</Label>
                    <div className="flex">
                      <div className="flex items-center px-3 border rounded-l-md bg-muted">
                        <Key className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <Input 
                        id="current-password"
                        type="password" 
                        value={adminSettings.currentPassword} 
                        onChange={(e) => handleAdminSettingChange('currentPassword', e.target.value)}
                        className="rounded-l-none"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="new-password">New Password</Label>
                      <Input 
                        id="new-password"
                        type="password" 
                        value={adminSettings.newPassword} 
                        onChange={(e) => handleAdminSettingChange('newPassword', e.target.value)}
                      />
                    </div>
                    
                    <div className="grid gap-2">
                      <Label htmlFor="confirm-password">Confirm Password</Label>
                      <Input 
                        id="confirm-password"
                        type="password" 
                        value={adminSettings.confirmPassword} 
                        onChange={(e) => handleAdminSettingChange('confirmPassword', e.target.value)}
                      />
                    </div>
                  </div>
                  
                  <p className="text-sm text-muted-foreground">
                    Password must be at least 8 characters and include a mix of letters, numbers, and symbols.
                  </p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end border-t pt-4">
              <Button onClick={handleSaveAdminSettings}>
                <Save className="mr-2 h-4 w-4" />
                Save Admin Settings
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SystemSettingsPage;
