
import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/components/ui/sonner";
import { faker } from "@faker-js/faker";

// Import refactored components
import SupplierBasicDetails from "@/components/superadmin/supplier/SupplierBasicDetails";
import SupplierAdditionalInfo from "@/components/superadmin/supplier/SupplierAdditionalInfo";
import SupplierDocuments from "@/components/superadmin/supplier/SupplierDocuments";
import SupplierPaymentInfo from "@/components/superadmin/supplier/SupplierPaymentInfo";
import SupplierVenues from "@/components/superadmin/supplier/SupplierVenues";
import SupplierVerificationSidebar from "@/components/superadmin/supplier/SupplierVerificationSidebar";

// Generate mock supplier data based on ID
const getSupplierDetails = (id: string) => {
  return {
    id,
    // These fields match the supplier registration form
    name: faker.person.fullName(),
    email: faker.internet.email(),
    businessName: faker.company.name(),
    taxPin: faker.finance.accountNumber(),
    registerDate: faker.date.recent({ days: 30 }).toISOString().split('T')[0],
    status: faker.helpers.arrayElement(['pending', 'verified', 'rejected']) as 'pending' | 'verified' | 'rejected',
    // Additional details
    phone: faker.phone.number(),
    address: `${faker.location.streetAddress()}, ${faker.location.city()}, ${faker.location.country()}`,
    type: faker.helpers.arrayElement(['restaurant', 'conference', 'hotel', 'multiple']),
    description: faker.company.catchPhrase(),
    venues: Array.from({ length: faker.number.int({ min: 1, max: 5 }) }, () => ({
      id: faker.string.uuid(),
      name: `${faker.company.name()} ${faker.location.city()}`,
      type: faker.helpers.arrayElement(['Restaurant', 'Conference Hall', 'Hotel']),
      address: faker.location.streetAddress(),
      city: faker.location.city(),
    })),
    documents: [
      { 
        name: 'Business Registration Certificate', 
        status: faker.helpers.arrayElement(['verified', 'pending']),
        date: faker.date.recent({ days: 10 }).toISOString().split('T')[0]
      },
      { 
        name: 'Tax Registration Document (PIN)', 
        status: faker.helpers.arrayElement(['verified', 'pending']),
        date: faker.date.recent({ days: 10 }).toISOString().split('T')[0]
      },
      { 
        name: 'Business License', 
        status: faker.helpers.arrayElement(['verified', 'pending']),
        date: faker.date.recent({ days: 10 }).toISOString().split('T')[0]
      }
    ],
    paymentInfo: {
      accountName: faker.person.fullName(),
      accountNumber: faker.finance.accountNumber(),
      bankName: faker.company.name()
    }
  };
};

const SupplierDetailsPage = () => {
  const { supplierId } = useParams();
  const navigate = useNavigate();
  const [supplier] = useState(getSupplierDetails(supplierId || 'unknown'));
  const [status, setStatus] = useState<'pending' | 'verified' | 'rejected'>(supplier.status);
  const [notes, setNotes] = useState("");
  
  const [verificationChecklist, setVerificationChecklist] = useState({
    businessInfo: false,
    taxPin: false,
    legalDocuments: false,
    venuesValid: false,
    contactVerified: false
  });
  
  const updateChecklistItem = (key: keyof typeof verificationChecklist) => {
    setVerificationChecklist(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };
  
  const allChecked = Object.values(verificationChecklist).every(Boolean);
  
  const handleVerify = () => {
    setStatus('verified');
    toast.success(`${supplier.businessName} has been verified successfully.`);
  };
  
  const handleReject = () => {
    setStatus('rejected');
    toast.error(`${supplier.businessName} has been rejected.`);
  };
  
  const handleSave = () => {
    toast.success("Supplier information updated successfully.");
    navigate('/superadmin/suppliers');
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'verified': return 'bg-green-50 text-green-700 border-green-200';
      case 'pending': return 'bg-orange-50 text-orange-700 border-orange-200';
      case 'rejected': return 'bg-red-50 text-red-700 border-red-200';
      default: return '';
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">{supplier.businessName}</h1>
          <div className="flex items-center gap-2 mt-1">
            <Badge variant="outline" className={getStatusColor(status)}>
              {status.charAt(0).toUpperCase() + status.slice(1)}
            </Badge>
            <span className="text-muted-foreground">Registered on {supplier.registerDate}</span>
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={() => navigate('/superadmin/suppliers')}
          >
            Back to List
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Tabs defaultValue="details">
            <TabsList className="grid grid-cols-2 mb-4">
              <TabsTrigger value="details">Basic Details</TabsTrigger>
              <TabsTrigger value="venues">Venues</TabsTrigger>
            </TabsList>
            
            <TabsContent value="details" className="space-y-4">
              <SupplierBasicDetails 
                businessName={supplier.businessName}
                name={supplier.name}
                email={supplier.email}
                taxPin={supplier.taxPin}
              />
              
              <SupplierAdditionalInfo 
                phone={supplier.phone}
                address={supplier.address}
                description={supplier.description}
              />
              
              <SupplierDocuments documents={supplier.documents} />
              
              <SupplierPaymentInfo paymentInfo={supplier.paymentInfo} />
            </TabsContent>
            
            <TabsContent value="venues" className="space-y-4">
              <SupplierVenues venues={supplier.venues} />
            </TabsContent>
          </Tabs>
        </div>
        
        <div className="space-y-6">
          <SupplierVerificationSidebar
            status={status}
            verificationChecklist={verificationChecklist}
            notes={notes}
            allChecked={allChecked}
            updateChecklistItem={updateChecklistItem}
            setNotes={setNotes}
            handleVerify={handleVerify}
            handleReject={handleReject}
          />
          
          <Button onClick={handleSave} className="w-full">
            Save Changes
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SupplierDetailsPage;
