
import { useState } from "react";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  Flag, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  MoreVertical
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/components/ui/sonner";
import { faker } from "@faker-js/faker";

interface Client {
  id: string;
  name: string;
  email: string;
  company: string | null;
  registerDate: string;
  lastActivity: string;
  status: "active" | "inactive" | "flagged" | "suspended";
  enquiries: number;
  bookings: number;
}

// Generate mock client data
const generateClients = (count: number): Client[] => {
  return Array.from({ length: count }, () => ({
    id: faker.string.uuid(),
    name: faker.person.fullName(),
    email: faker.internet.email(),
    company: faker.helpers.maybe(() => faker.company.name(), { probability: 0.7 }),
    registerDate: faker.date.past({ years: 1 }).toISOString().split('T')[0],
    lastActivity: faker.date.recent({ days: 30 }).toISOString().split('T')[0],
    status: faker.helpers.arrayElement(['active', 'inactive', 'flagged', 'suspended']),
    enquiries: faker.number.int({ min: 0, max: 20 }),
    bookings: faker.number.int({ min: 0, max: 10 }),
  }));
};

const mockClients = generateClients(20);

const ClientManagementPage = () => {
  const [clients, setClients] = useState<Client[]>(mockClients);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [actionType, setActionType] = useState<"flag" | "suspend" | "activate">("flag");
  const [actionReason, setActionReason] = useState("");
  
  // Filter clients based on search query and status filter
  const filteredClients = clients.filter(client => {
    const matchesSearch = 
      client.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      client.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (client.company && client.company.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesStatus = statusFilter === "all" || client.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });
  
  // Status counts for badges
  const activeCount = clients.filter(c => c.status === "active").length;
  const inactiveCount = clients.filter(c => c.status === "inactive").length;
  const flaggedCount = clients.filter(c => c.status === "flagged").length;
  const suspendedCount = clients.filter(c => c.status === "suspended").length;
  
  const handleAction = (client: Client, action: "flag" | "suspend" | "activate") => {
    setSelectedClient(client);
    setActionType(action);
    setActionReason("");
    setDialogOpen(true);
  };
  
  const confirmAction = () => {
    if (!selectedClient) return;
    
    // Update client status based on action type
    const updatedClients = clients.map(client => {
      if (client.id === selectedClient.id) {
        let newStatus: "active" | "inactive" | "flagged" | "suspended";
        
        switch (actionType) {
          case "flag":
            newStatus = "flagged";
            break;
          case "suspend":
            newStatus = "suspended";
            break;
          case "activate":
            newStatus = "active";
            break;
          default:
            newStatus = client.status;
        }
        
        return { ...client, status: newStatus };
      }
      return client;
    });
    
    setClients(updatedClients);
    setDialogOpen(false);
    
    // Show success toast
    let message = "";
    switch (actionType) {
      case "flag":
        message = `${selectedClient.name} has been flagged.`;
        break;
      case "suspend":
        message = `${selectedClient.name}'s account has been suspended.`;
        break;
      case "activate":
        message = `${selectedClient.name}'s account has been activated.`;
        break;
    }
    
    toast.success(message);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Client Management</h1>
          <p className="text-muted-foreground">Manage and monitor client accounts</p>
        </div>
      </div>
      
      {/* Filters and search */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex flex-wrap gap-2">
          <Button 
            variant={statusFilter === "all" ? "default" : "outline"}
            size="sm"
            onClick={() => setStatusFilter("all")}
          >
            All ({clients.length})
          </Button>
          <Button 
            variant={statusFilter === "active" ? "default" : "outline"}
            size="sm"
            onClick={() => setStatusFilter("active")}
          >
            Active ({activeCount})
          </Button>
          <Button 
            variant={statusFilter === "flagged" ? "default" : "outline"}
            size="sm"
            onClick={() => setStatusFilter("flagged")}
          >
            Flagged ({flaggedCount})
          </Button>
          <Button 
            variant={statusFilter === "suspended" ? "default" : "outline"}
            size="sm"
            onClick={() => setStatusFilter("suspended")}
          >
            Suspended ({suspendedCount})
          </Button>
        </div>
        
        <div className="relative w-full sm:w-auto">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search clients..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 w-full sm:w-[300px]"
          />
        </div>
      </div>
      
      {/* Clients table */}
      <div className="rounded-lg border shadow-sm overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Client</TableHead>
              <TableHead>Company</TableHead>
              <TableHead>Account</TableHead>
              <TableHead>Activity</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredClients.map((client) => (
              <TableRow key={client.id}>
                <TableCell>
                  <div className="font-medium">{client.name}</div>
                  <div className="text-muted-foreground text-sm">{client.email}</div>
                </TableCell>
                <TableCell>{client.company || "-"}</TableCell>
                <TableCell>
                  <div>Registered: {client.registerDate}</div>
                  <div className="text-sm text-muted-foreground">
                    {client.enquiries} enquiries, {client.bookings} bookings
                  </div>
                </TableCell>
                <TableCell>Last active: {client.lastActivity}</TableCell>
                <TableCell>
                  <StatusBadge status={client.status} />
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreVertical className="h-4 w-4" />
                        <span className="sr-only">Open menu</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      
                      {client.status !== "flagged" && (
                        <DropdownMenuItem onClick={() => handleAction(client, "flag")}>
                          <Flag className="mr-2 h-4 w-4 text-orange-600" />
                          Flag Account
                        </DropdownMenuItem>
                      )}
                      
                      {client.status !== "suspended" && (
                        <DropdownMenuItem onClick={() => handleAction(client, "suspend")}>
                          <XCircle className="mr-2 h-4 w-4 text-red-600" />
                          Suspend Account
                        </DropdownMenuItem>
                      )}
                      
                      {(client.status === "flagged" || client.status === "suspended") && (
                        <DropdownMenuItem onClick={() => handleAction(client, "activate")}>
                          <CheckCircle className="mr-2 h-4 w-4 text-green-600" />
                          Activate Account
                        </DropdownMenuItem>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
            {filteredClients.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8">
                  <div className="text-muted-foreground">No clients found</div>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {actionType === "flag" && "Flag Client Account"}
              {actionType === "suspend" && "Suspend Client Account"}
              {actionType === "activate" && "Activate Client Account"}
            </DialogTitle>
            <DialogDescription>
              {selectedClient && (
                <span>
                  {actionType === "flag" && `You're about to flag ${selectedClient.name}'s account.`}
                  {actionType === "suspend" && `You're about to suspend ${selectedClient.name}'s account. They will not be able to use the platform until reactivated.`}
                  {actionType === "activate" && `You're about to activate ${selectedClient.name}'s account.`}
                </span>
              )}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div>
              <label className="text-sm font-medium mb-1 block">
                Reason for {actionType === "flag" ? "flagging" : actionType === "suspend" ? "suspending" : "activating"}
              </label>
              <Textarea 
                placeholder="Provide a reason..." 
                value={actionReason} 
                onChange={(e) => setActionReason(e.target.value)}
                className="h-32"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              variant={actionType === "activate" ? "default" : "destructive"}
              onClick={confirmAction}
            >
              {actionType === "flag" && "Flag Account"}
              {actionType === "suspend" && "Suspend Account"}
              {actionType === "activate" && "Activate Account"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

const StatusBadge = ({ status }: { status: string }) => {
  switch (status) {
    case "active":
      return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Active</Badge>;
    case "inactive":
      return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">Inactive</Badge>;
    case "flagged":
      return <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200">Flagged</Badge>;
    case "suspended":
      return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Suspended</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

export default ClientManagementPage;
