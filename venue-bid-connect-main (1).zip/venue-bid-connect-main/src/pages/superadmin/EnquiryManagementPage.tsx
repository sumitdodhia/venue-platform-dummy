
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const EnquiryManagementPage = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Enquiry Management</h1>
        <p className="text-muted-foreground">Monitor and manage platform enquiries</p>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Active Enquiries</CardTitle>
        </CardHeader>
        <CardContent>
          <p>Active enquiries listing will go here...</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default EnquiryManagementPage;
