import { useState } from "react";
import { 
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/components/ui/sonner";
import { 
  Save, 
  CreditCard, 
  Wallet, 
  RefreshCw,
  Check,
  X,
  DollarSign,
  Euro,
  PoundSterling,
  CircleDollarSign
} from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const PaymentIntegrationsPage = () => {
  // Stripe settings
  const [stripeSettings, setStripeSettings] = useState({
    enabled: true,
    liveMode: false,
    publishableKey: "pk_test_51Hg...",
    secretKey: "sk_test_51Hg...",
    webhookSecret: "whsec_...",
    enabledCurrencies: ["USD", "EUR", "GBP"],
    subscriptionPlans: [
      { id: "basic", name: "Basic Plan", price: 49 },
      { id: "standard", name: "Standard Plan", price: 99 },
      { id: "premium", name: "Premium Plan", price: 199 }
    ]
  });
  
  // PayPal settings
  const [paypalSettings, setPaypalSettings] = useState({
    enabled: false,
    liveMode: false,
    clientId: "AZ1_...",
    clientSecret: "EFG2_...",
    enabledCurrencies: ["USD", "EUR"]
  });
  
  const handleStripeSettingChange = (field: keyof typeof stripeSettings, value: any) => {
    setStripeSettings(prev => ({ ...prev, [field]: value }));
  };
  
  const handlePayPalSettingChange = (field: keyof typeof paypalSettings, value: any) => {
    setPaypalSettings(prev => ({ ...prev, [field]: value }));
  };
  
  const handleSaveStripeSettings = () => {
    // In a real application, you'd save these to your backend
    toast.success("Stripe settings saved successfully");
  };
  
  const handleSavePayPalSettings = () => {
    // In a real application, you'd save these to your backend
    toast.success("PayPal settings saved successfully");
  };
  
  const handleTestStripeConnection = () => {
    // In a real application, you'd test the connection
    toast.success("Stripe connection successful");
  };
  
  const handleTestPayPalConnection = () => {
    // In a real application, you'd test the connection
    toast.success("PayPal connection successful");
  };
  
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Payment Integrations</h1>
        <p className="text-muted-foreground">Configure payment providers and settings</p>
      </div>
      
      <Tabs defaultValue="stripe">
        <TabsList className="grid w-full md:w-auto grid-cols-2">
          <TabsTrigger value="stripe">
            <CreditCard className="h-4 w-4 mr-2" />
            Stripe
          </TabsTrigger>
          <TabsTrigger value="paypal">
            <Wallet className="h-4 w-4 mr-2" />
            PayPal
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="stripe">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Stripe Configuration</CardTitle>
                <CardDescription>Configure Stripe payment gateway settings</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm">Enabled</span>
                <Switch 
                  checked={stripeSettings.enabled}
                  onCheckedChange={(checked) => handleStripeSettingChange('enabled', checked)}
                />
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between border rounded-lg p-4 bg-muted/30">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-full ${stripeSettings.liveMode ? "bg-green-100" : "bg-amber-100"}`}>
                    {stripeSettings.liveMode ? (
                      <Check className="h-5 w-5 text-green-600" />
                    ) : (
                      <RefreshCw className="h-5 w-5 text-amber-600" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium">
                      {stripeSettings.liveMode ? "Live Mode" : "Test Mode"}
                    </p>
                    <p className="text-muted-foreground text-sm">
                      {stripeSettings.liveMode 
                        ? "Processing real transactions with live API keys" 
                        : "Using test API keys, no real transactions will be processed"}
                    </p>
                  </div>
                </div>
                <div>
                  <Switch 
                    checked={stripeSettings.liveMode}
                    onCheckedChange={(checked) => handleStripeSettingChange('liveMode', checked)}
                  />
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">API Credentials</h3>
                
                <div className="grid gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="publishable-key">
                      {stripeSettings.liveMode ? "Live Publishable Key" : "Test Publishable Key"}
                    </Label>
                    <Input 
                      id="publishable-key"
                      value={stripeSettings.publishableKey} 
                      onChange={(e) => handleStripeSettingChange('publishableKey', e.target.value)}
                    />
                    <p className="text-sm text-muted-foreground">
                      The publishable key from your Stripe dashboard
                    </p>
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="secret-key">
                      {stripeSettings.liveMode ? "Live Secret Key" : "Test Secret Key"}
                    </Label>
                    <Input 
                      id="secret-key"
                      type="password"
                      value={stripeSettings.secretKey} 
                      onChange={(e) => handleStripeSettingChange('secretKey', e.target.value)}
                    />
                    <p className="text-sm text-muted-foreground">
                      Keep this key secret and secure
                    </p>
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="webhook-secret">Webhook Signing Secret</Label>
                    <Input 
                      id="webhook-secret"
                      type="password"
                      value={stripeSettings.webhookSecret} 
                      onChange={(e) => handleStripeSettingChange('webhookSecret', e.target.value)}
                    />
                  </div>
                </div>
              </div>
              
              <div className="space-y-4 pt-4">
                <h3 className="text-lg font-medium">Enabled Currencies</h3>
                <div className="flex flex-wrap gap-2">
                  <CurrencyBadge 
                    currency="USD" 
                    isEnabled={stripeSettings.enabledCurrencies.includes("USD")}
                    onToggle={() => {
                      if (stripeSettings.enabledCurrencies.includes("USD")) {
                        handleStripeSettingChange(
                          'enabledCurrencies', 
                          stripeSettings.enabledCurrencies.filter(c => c !== "USD")
                        );
                      } else {
                        handleStripeSettingChange(
                          'enabledCurrencies', 
                          [...stripeSettings.enabledCurrencies, "USD"]
                        );
                      }
                    }}
                  />
                  
                  <CurrencyBadge 
                    currency="EUR" 
                    isEnabled={stripeSettings.enabledCurrencies.includes("EUR")}
                    onToggle={() => {
                      if (stripeSettings.enabledCurrencies.includes("EUR")) {
                        handleStripeSettingChange(
                          'enabledCurrencies', 
                          stripeSettings.enabledCurrencies.filter(c => c !== "EUR")
                        );
                      } else {
                        handleStripeSettingChange(
                          'enabledCurrencies', 
                          [...stripeSettings.enabledCurrencies, "EUR"]
                        );
                      }
                    }}
                  />
                  
                  <CurrencyBadge 
                    currency="GBP" 
                    isEnabled={stripeSettings.enabledCurrencies.includes("GBP")}
                    onToggle={() => {
                      if (stripeSettings.enabledCurrencies.includes("GBP")) {
                        handleStripeSettingChange(
                          'enabledCurrencies', 
                          stripeSettings.enabledCurrencies.filter(c => c !== "GBP")
                        );
                      } else {
                        handleStripeSettingChange(
                          'enabledCurrencies', 
                          [...stripeSettings.enabledCurrencies, "GBP"]
                        );
                      }
                    }}
                  />
                </div>
              </div>
              
              <div className="space-y-4 pt-4">
                <h3 className="text-lg font-medium">Subscription Plans</h3>
                <Accordion type="single" collapsible className="w-full">
                  {stripeSettings.subscriptionPlans.map((plan, index) => (
                    <AccordionItem key={plan.id} value={plan.id}>
                      <AccordionTrigger className="hover:no-underline">
                        <div className="flex items-center justify-between w-full pr-4">
                          <span>{plan.name}</span>
                          <Badge variant="outline" className="ml-auto mr-4">
                            ${plan.price}/month
                          </Badge>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-4 py-2">
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label htmlFor={`plan-name-${index}`}>Plan Name</Label>
                              <Input 
                                id={`plan-name-${index}`}
                                value={plan.name}
                                onChange={(e) => {
                                  const newPlans = [...stripeSettings.subscriptionPlans];
                                  newPlans[index].name = e.target.value;
                                  handleStripeSettingChange('subscriptionPlans', newPlans);
                                }}
                              />
                            </div>
                            
                            <div className="space-y-2">
                              <Label htmlFor={`plan-price-${index}`}>Monthly Price ($)</Label>
                              <Input 
                                id={`plan-price-${index}`}
                                type="number"
                                value={plan.price}
                                onChange={(e) => {
                                  const newPlans = [...stripeSettings.subscriptionPlans];
                                  newPlans[index].price = parseInt(e.target.value) || 0;
                                  handleStripeSettingChange('subscriptionPlans', newPlans);
                                }}
                              />
                            </div>
                          </div>
                          
                          <div className="flex justify-end">
                            <Button 
                              variant="destructive" 
                              size="sm"
                              onClick={() => {
                                const newPlans = stripeSettings.subscriptionPlans.filter((_, i) => i !== index);
                                handleStripeSettingChange('subscriptionPlans', newPlans);
                              }}
                            >
                              Remove Plan
                            </Button>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
                
                <Button 
                  variant="outline"
                  onClick={() => {
                    handleStripeSettingChange('subscriptionPlans', [
                      ...stripeSettings.subscriptionPlans,
                      { id: `plan_${Date.now()}`, name: "New Plan", price: 99 }
                    ]);
                  }}
                >
                  <PlusIcon />
                  <span className="ml-2">Add Subscription Plan</span>
                </Button>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between border-t pt-4">
              <Button variant="outline" onClick={handleTestStripeConnection}>
                <RefreshCw className="mr-2 h-4 w-4" />
                Test Connection
              </Button>
              <Button onClick={handleSaveStripeSettings}>
                <Save className="mr-2 h-4 w-4" />
                Save Stripe Settings
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="paypal">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>PayPal Configuration</CardTitle>
                <CardDescription>Configure PayPal payment gateway settings</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm">Enabled</span>
                <Switch 
                  checked={paypalSettings.enabled}
                  onCheckedChange={(checked) => handlePayPalSettingChange('enabled', checked)}
                />
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between border rounded-lg p-4 bg-muted/30">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-full ${paypalSettings.liveMode ? "bg-green-100" : "bg-amber-100"}`}>
                    {paypalSettings.liveMode ? (
                      <Check className="h-5 w-5 text-green-600" />
                    ) : (
                      <RefreshCw className="h-5 w-5 text-amber-600" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium">
                      {paypalSettings.liveMode ? "Live Mode" : "Sandbox Mode"}
                    </p>
                    <p className="text-muted-foreground text-sm">
                      {paypalSettings.liveMode 
                        ? "Processing real transactions with live API credentials" 
                        : "Using sandbox API credentials, no real transactions will be processed"}
                    </p>
                  </div>
                </div>
                <div>
                  <Switch 
                    checked={paypalSettings.liveMode}
                    onCheckedChange={(checked) => handlePayPalSettingChange('liveMode', checked)}
                  />
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">API Credentials</h3>
                
                <div className="grid gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="client-id">
                      {paypalSettings.liveMode ? "Live Client ID" : "Sandbox Client ID"}
                    </Label>
                    <Input 
                      id="client-id"
                      value={paypalSettings.clientId} 
                      onChange={(e) => handlePayPalSettingChange('clientId', e.target.value)}
                    />
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="client-secret">
                      {paypalSettings.liveMode ? "Live Client Secret" : "Sandbox Client Secret"}
                    </Label>
                    <Input 
                      id="client-secret"
                      type="password"
                      value={paypalSettings.clientSecret} 
                      onChange={(e) => handlePayPalSettingChange('clientSecret', e.target.value)}
                    />
                  </div>
                </div>
              </div>
              
              <div className="space-y-4 pt-4">
                <h3 className="text-lg font-medium">Enabled Currencies</h3>
                <div className="flex flex-wrap gap-2">
                  <CurrencyBadge 
                    currency="USD" 
                    isEnabled={paypalSettings.enabledCurrencies.includes("USD")}
                    onToggle={() => {
                      if (paypalSettings.enabledCurrencies.includes("USD")) {
                        handlePayPalSettingChange(
                          'enabledCurrencies', 
                          paypalSettings.enabledCurrencies.filter(c => c !== "USD")
                        );
                      } else {
                        handlePayPalSettingChange(
                          'enabledCurrencies', 
                          [...paypalSettings.enabledCurrencies, "USD"]
                        );
                      }
                    }}
                  />
                  
                  <CurrencyBadge 
                    currency="EUR" 
                    isEnabled={paypalSettings.enabledCurrencies.includes("EUR")}
                    onToggle={() => {
                      if (paypalSettings.enabledCurrencies.includes("EUR")) {
                        handlePayPalSettingChange(
                          'enabledCurrencies', 
                          paypalSettings.enabledCurrencies.filter(c => c !== "EUR")
                        );
                      } else {
                        handlePayPalSettingChange(
                          'enabledCurrencies', 
                          [...paypalSettings.enabledCurrencies, "EUR"]
                        );
                      }
                    }}
                  />
                  
                  <CurrencyBadge 
                    currency="GBP" 
                    isEnabled={paypalSettings.enabledCurrencies.includes("GBP")}
                    onToggle={() => {
                      if (paypalSettings.enabledCurrencies.includes("GBP")) {
                        handlePayPalSettingChange(
                          'enabledCurrencies', 
                          paypalSettings.enabledCurrencies.filter(c => c !== "GBP")
                        );
                      } else {
                        handlePayPalSettingChange(
                          'enabledCurrencies', 
                          [...paypalSettings.enabledCurrencies, "GBP"]
                        );
                      }
                    }}
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between border-t pt-4">
              <Button variant="outline" onClick={handleTestPayPalConnection}>
                <RefreshCw className="mr-2 h-4 w-4" />
                Test Connection
              </Button>
              <Button onClick={handleSavePayPalSettings}>
                <Save className="mr-2 h-4 w-4" />
                Save PayPal Settings
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

// Currency badge component for toggleable currency selection
interface CurrencyBadgeProps {
  currency: string;
  isEnabled: boolean;
  onToggle: () => void;
}

const CurrencyBadge = ({ currency, isEnabled, onToggle }: CurrencyBadgeProps) => {
  // Get currency icon based on currency code
  const getCurrencyIcon = (code: string) => {
    switch (code) {
      case "USD":
        return <DollarSign className="h-4 w-4" />;
      case "EUR":
        return <Euro className="h-4 w-4" />;
      case "GBP":
        return <PoundSterling className="h-4 w-4" />;
      default:
        return <CircleDollarSign className="h-4 w-4" />;
    }
  };
  
  return (
    <Badge
      variant={isEnabled ? "default" : "outline"}
      className={`cursor-pointer ${
        isEnabled 
          ? "bg-primary" 
          : "hover:bg-primary/10"
      } flex items-center gap-1 px-3 py-1`}
      onClick={onToggle}
    >
      {getCurrencyIcon(currency)}
      {currency}
      {isEnabled ? (
        <Check className="h-3 w-3 ml-1" />
      ) : null}
    </Badge>
  );
};

// Define the PlusIcon component to replace the previous implementation that was causing errors
const PlusIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="h-4 w-4"
    >
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
};

export default PaymentIntegrationsPage;
