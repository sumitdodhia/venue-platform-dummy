
import LoginPage from "./LoginPage";

const AuthPage = () => {
  return <LoginPage />;
};

export default AuthPage;
