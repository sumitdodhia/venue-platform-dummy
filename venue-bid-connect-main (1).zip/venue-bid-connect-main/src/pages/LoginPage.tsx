
import { Link } from "react-router-dom";
import LoginForm from "@/components/auth/LoginForm";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { InfoIcon } from "lucide-react";

const LoginPage = () => {
  return (
    <main className="flex-1 flex flex-col items-center justify-center p-4 bg-muted/30">
      <div className="w-full max-w-md space-y-4">
        <Alert className="bg-blue-50 border-blue-200 mb-4">
          <InfoIcon className="h-4 w-4 text-blue-500" />
          <AlertDescription className="text-blue-800">
            After registration, please check your email for a verification link before logging in.
          </AlertDescription>
        </Alert>
        
        <LoginForm />
        
        <div className="mt-4 text-center">
          <Link to="/" className="text-sm text-primary hover:underline">
            Back to home
          </Link>
        </div>
      </div>
    </main>
  );
};

export default LoginPage;
