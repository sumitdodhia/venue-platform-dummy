
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Check, ArrowRight } from "lucide-react";

const HowItWorksPage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-8">How FindToTable Works</h1>
        
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4 mb-12">
          <Card className="text-center">
            <CardHeader>
              <div className="text-4xl mb-4">🔍</div>
              <CardTitle>1. Search & Filter</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Browse through our extensive collection of venues and filter based on your requirements.
              </p>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardHeader>
              <div className="text-4xl mb-4">✉️</div>
              <CardTitle>2. Send Enquiry</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Contact venues directly or submit a detailed enquiry for multiple venues to bid on.
              </p>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardHeader>
              <div className="text-4xl mb-4">📋</div>
              <CardTitle>3. Receive Proposals</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Venues will respond with their availability, pricing, and special offers tailored to your needs.
              </p>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardHeader>
              <div className="text-4xl mb-4">✅</div>
              <CardTitle>4. Compare & Select</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Compare proposals side by side and select the best option for your event.
              </p>
            </CardContent>
          </Card>
        </div>
        
        <div className="text-center">
          <Link to="/marketplace">
            <Button size="lg" className="gap-2">
              Start Exploring <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default HowItWorksPage;
