
import EnquiryDetails from "@/components/client/EnquiryDetails";
import { useParams } from "react-router-dom";

const EnquiryDetailsPage = () => {
  const { enquiryId } = useParams();
  
  return <EnquiryDetails enquiryId={enquiryId} />;
};

export default EnquiryDetailsPage;
