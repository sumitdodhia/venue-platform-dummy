
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Check, ArrowRight, Building, Users, TrendingUp } from "lucide-react";

const SuppliersPage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-8">For Suppliers</h1>
        
        <div className="grid gap-8 md:grid-cols-3 mb-12">
          <Card className="text-center">
            <CardHeader>
              <Building className="h-12 w-12 mx-auto mb-4 text-primary" />
              <CardTitle>Showcase Your Venue</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                List your venues with detailed descriptions, photos, and availability.
              </p>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardHeader>
              <Users className="h-12 w-12 mx-auto mb-4 text-primary" />
              <CardTitle>Connect with Clients</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Receive enquiries and bid on events that match your venue capabilities.
              </p>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardHeader>
              <TrendingUp className="h-12 w-12 mx-auto mb-4 text-primary" />
              <CardTitle>Grow Your Business</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Increase bookings and revenue through our platform's wide reach.
              </p>
            </CardContent>
          </Card>
        </div>
        
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Benefits of Joining FindToTable</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 md:grid-cols-2">
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <Check className="h-5 w-5 text-green-500 mt-0.5" />
                <p>Increased visibility to potential clients</p>
              </div>
              <div className="flex items-start gap-3">
                <Check className="h-5 w-5 text-green-500 mt-0.5" />
                <p>Direct communication with event planners</p>
              </div>
              <div className="flex items-start gap-3">
                <Check className="h-5 w-5 text-green-500 mt-0.5" />
                <p>Manage bookings and enquiries in one place</p>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <Check className="h-5 w-5 text-green-500 mt-0.5" />
                <p>Competitive bidding opportunities</p>
              </div>
              <div className="flex items-start gap-3">
                <Check className="h-5 w-5 text-green-500 mt-0.5" />
                <p>Easy venue management tools</p>
              </div>
              <div className="flex items-start gap-3">
                <Check className="h-5 w-5 text-green-500 mt-0.5" />
                <p>24/7 support and assistance</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <div className="text-center">
          <Link to="/supplier-register">
            <Button size="lg" className="gap-2">
              Join as Supplier <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default SuppliersPage;
