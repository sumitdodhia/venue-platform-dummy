
import { SupplierSettings } from "@/components/supplier/settings/SupplierSettings";

const SupplierSettingsPage = () => {
  return <SupplierSettings />;
};

export default SupplierSettingsPage;
