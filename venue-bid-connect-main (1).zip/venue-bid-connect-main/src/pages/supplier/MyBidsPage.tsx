
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const MyBidsPage = () => {
  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold">My Bids</h1>
          <p className="text-muted-foreground">Track and manage your submitted bids</p>
        </div>
      </div>
      
      <Card>
        <CardHeader className="pb-4">
          <CardTitle>Submitted Bids</CardTitle>
        </CardHeader>
        <CardContent className="p-6 text-center">
          <p className="text-muted-foreground">You haven't submitted any bids yet.</p>
          <p className="text-sm text-muted-foreground mt-2">When you respond to enquiries, your bids will appear here.</p>
          <div className="mt-6">
            <Button asChild>
              <Link to="/supplier/dashboard/enquiries">View Available Enquiries</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default MyBidsPage;
