
import SupplierDashboard from "@/components/supplier/SupplierDashboard";

const SupplierDashboardPage = () => {
  return <SupplierDashboard />;
};

export default SupplierDashboardPage;
