
import BidForm from "@/components/supplier/BidForm";

const BidFormPage = () => {
  return <BidForm />;
};

export default BidFormPage;
