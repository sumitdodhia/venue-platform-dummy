
import DirectEnquiriesList from "@/components/supplier/enquiries/DirectEnquiriesList";

const DirectEnquiriesPage = () => {
  return <DirectEnquiriesList />;
};

export default DirectEnquiriesPage;
