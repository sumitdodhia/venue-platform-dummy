
import { SupplierProfile } from "@/components/supplier/profile/SupplierProfile";

const SupplierProfilePage = () => {
  return <SupplierProfile />;
};

export default SupplierProfilePage;
