
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Plus, Building, MapPin, Edit, Trash2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import { useState, useEffect } from "react";
import DeleteVenueModal from "@/components/supplier/DeleteVenueModal";

const VenuesListPage = () => {
  const { user } = useAuth();
  const [venues, setVenues] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [deleteModal, setDeleteModal] = useState<{
    isOpen: boolean;
    venue: any | null;
    isDeleting: boolean;
  }>({
    isOpen: false,
    venue: null,
    isDeleting: false
  });

  useEffect(() => {
    if (user) {
      fetchUserVenues();
    }
  }, [user]);

  const fetchUserVenues = async () => {
    if (!user) return;

    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('venues')
        .select('*')
        .eq('owner_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching venues:', error);
        toast.error('Failed to fetch venues');
        return;
      }

      console.log("User venues fetched:", data);
      setVenues(data || []);
    } catch (error) {
      console.error('Error fetching venues:', error);
      toast.error('Failed to fetch venues');
    } finally {
      setIsLoading(false);
    }
  };

  const openDeleteModal = (venue: any) => {
    setDeleteModal({
      isOpen: true,
      venue,
      isDeleting: false
    });
  };

  const closeDeleteModal = () => {
    setDeleteModal({
      isOpen: false,
      venue: null,
      isDeleting: false
    });
  };

  const handleDeleteVenue = async () => {
    if (!deleteModal.venue || !user) {
      toast.error("Cannot delete venue");
      return;
    }

    setDeleteModal(prev => ({ ...prev, isDeleting: true }));

    try {
      console.log("Attempting to delete venue:", deleteModal.venue.id);
      
      const { error } = await supabase
        .from('venues')
        .delete()
        .eq('id', deleteModal.venue.id)
        .eq('owner_id', user.id);

      if (error) {
        console.error('Error deleting venue:', error);
        toast.error('Failed to delete venue: ' + error.message);
        return;
      }

      console.log('Venue deleted successfully from database');
      
      // Remove the venue from local state immediately
      setVenues(prevVenues => prevVenues.filter(venue => venue.id !== deleteModal.venue.id));
      
      toast.success('Venue deleted successfully');
      closeDeleteModal();
    } catch (error: any) {
      console.error('Error deleting venue:', error);
      toast.error('An unexpected error occurred');
    } finally {
      setDeleteModal(prev => ({ ...prev, isDeleting: false }));
    }
  };

  const getEditRoute = (venue: any) => {
    switch (venue.type) {
      case 'hotel':
      case 'rooms':
        return `/supplier/venues/${venue.id}/edit/hotel`;
      case 'conference':
      case 'conference_venue':
        return `/supplier/venues/${venue.id}/edit/conference`;
      case 'restaurant':
      case 'dining':
        return `/supplier/venues/${venue.id}/edit/restaurant`;
      default:
        return `/supplier/venues/${venue.id}/edit`;
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div className="flex flex-wrap justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Venue Management</h1>
            <p className="text-muted-foreground">Loading your venues...</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="pb-4">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="h-3 bg-gray-200 rounded"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Venue Management</h1>
          <p className="text-muted-foreground">Manage and track your venues</p>
        </div>
        <div className="flex gap-3">
          <Button asChild className="gap-2">
            <Link to="/supplier/venues/add">
              <Plus className="h-4 w-4" />
              Add Venue
            </Link>
          </Button>
        </div>
      </div>
      
      {venues.length === 0 ? (
        <Card>
          <CardHeader className="pb-4">
            <CardTitle>My Venues</CardTitle>
          </CardHeader>
          <CardContent className="p-6 text-center">
            <Building className="h-12 w-12 mx-auto mb-3 text-muted-foreground/60" />
            <p className="text-muted-foreground">You haven't added any venues yet.</p>
            <p className="text-sm text-muted-foreground mt-2">Add your first venue to start receiving enquiries.</p>
            <div className="mt-6">
              <Button asChild>
                <Link to="/supplier/venues/add">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Your First Venue
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {venues.map((venue) => (
            <Card key={venue.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">{venue.name}</CardTitle>
                    <div className="flex items-center text-sm text-muted-foreground mt-1">
                      <MapPin className="h-4 w-4 mr-1" />
                      {venue.location}
                    </div>
                  </div>
                  <div className="flex space-x-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 p-0"
                      asChild
                    >
                      <Link to={getEditRoute(venue)}>
                        <Edit className="h-4 w-4" />
                      </Link>
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 p-0 text-red-500 hover:text-red-600"
                      onClick={() => openDeleteModal(venue)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Type:</span>
                    <span className="text-sm text-muted-foreground capitalize">{venue.type}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Rating:</span>
                    <span className="text-sm text-muted-foreground">{venue.rating}/5</span>
                  </div>
                  {venue.capacity && (
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Capacity:</span>
                      <span className="text-sm text-muted-foreground">{venue.capacity}</span>
                    </div>
                  )}
                  {venue.description && (
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {venue.description}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <DeleteVenueModal
        isOpen={deleteModal.isOpen}
        onClose={closeDeleteModal}
        onConfirm={handleDeleteVenue}
        venueName={deleteModal.venue?.name || ''}
        isDeleting={deleteModal.isDeleting}
      />
    </div>
  );
};

export default VenuesListPage;
