
import SupplierEnquiriesList from "@/components/supplier/SupplierEnquiriesList";

const SupplierEnquiriesPage = () => {
  return <SupplierEnquiriesList />;
};

export default SupplierEnquiriesPage;
