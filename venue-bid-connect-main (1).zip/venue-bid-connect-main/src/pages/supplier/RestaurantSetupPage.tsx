
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { RestaurantDetails, PartialRestaurantDetails } from "@/types/restaurantSupplier";
import { useRestaurantSupplierSetup } from "@/hooks/useRestaurantSupplierSetup";
import RestaurantSetupWorkflow from "@/components/supplier/restaurant/RestaurantSetupWorkflow";

const RestaurantSetupPage = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("details");
  
  const { 
    restaurant, 
    saveRestaurantDetails,
    saveDiningPackages,
    saveDiningSections,
    publishRestaurant
  } = useRestaurantSupplierSetup();

  // Save restaurant details
  const handleSaveDetails = (details: PartialRestaurantDetails) => {
    saveRestaurantDetails(details);
    toast.success("Restaurant details saved successfully!");
    setActiveTab("sections");
  };

  // Save dining sections
  const handleSaveSections = (sections: RestaurantDetails["sections"]) => {
    saveDiningSections(sections);
    toast.success("Dining sections saved successfully!");
    setActiveTab("packages");
  };

  // Save dining packages
  const handleSavePackages = (packages: RestaurantDetails["packages"]) => {
    saveDiningPackages(packages);
    toast.success("Dining packages saved successfully!");
    setActiveTab("review");
  };

  // Publish the restaurant
  const handlePublish = () => {
    publishRestaurant();
    toast.success("Restaurant published successfully!");
    navigate("/supplier/dashboard/venues");
  };

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-8">Restaurant Setup</h1>
      
      <RestaurantSetupWorkflow
        restaurant={restaurant}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onSaveDetails={handleSaveDetails}
        onSaveSections={handleSaveSections}
        onSavePackages={handleSavePackages}
        onPublish={handlePublish}
      />
    </div>
  );
};

export default RestaurantSetupPage;
