
import { useParams } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { enquiryData } from "@/components/supplier/bid/types";
import EnquiryStatusBadge from "@/components/supplier/enquiries/EnquiryStatusBadge";

const EnquiryDetailsPage = () => {
  const { enquiryId } = useParams();
  const enquiry = enquiryId ? enquiryData[enquiryId] : null;

  if (!enquiry) {
    return (
      <div className="space-y-4">
        <h1 className="text-2xl font-bold">Enquiry Not Found</h1>
        <p>The requested enquiry could not be found.</p>
        <Button asChild>
          <Link to="/supplier/dashboard/enquiries">Back to Enquiries</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Enquiry Details</h1>
          <p className="text-muted-foreground">
            Reference ID: {enquiry.id}
          </p>
        </div>

        <div className="flex gap-2">
          {enquiry.status === "new" && (
            <Button asChild>
              <Link to={`/supplier/dashboard/enquiries/${enquiry.id}/bid`}>
                Submit Bid
              </Link>
            </Button>
          )}
          <Button variant="outline" asChild>
            <Link to="/supplier/dashboard/enquiries">
              Back to Enquiries
            </Link>
          </Button>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Enquiry Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Title</p>
                <p>{enquiry.title}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Status</p>
                <EnquiryStatusBadge status={enquiry.status} />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Company</p>
                <p>{enquiry.company}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Date</p>
                <p>{"date" in enquiry ? enquiry.date : "checkInDate" in enquiry ? enquiry.checkInDate : "N/A"}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Deadline</p>
                <p>{enquiry.deadline}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">
                  {"guests" in enquiry ? "Guest Count" : "Room Count"}
                </p>
                <p>{("guests" in enquiry ? enquiry.guests : "roomCount" in enquiry ? enquiry.roomCount : "N/A")}</p>
              </div>
            </div>

            {"budget" in enquiry && (
              <div>
                <p className="text-sm font-medium text-muted-foreground">Budget</p>
                <p>${enquiry.budget}</p>
              </div>
            )}

            {"requirements" in enquiry && (
              <div className="pt-4 border-t">
                <p className="text-sm font-medium text-muted-foreground mb-2">Requirements</p>
                <p>{enquiry.requirements}</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Client Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Company</p>
                <p>{enquiry.company}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Contact</p>
                <p>{enquiry.company} Representative</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Email</p>
                <p>contact@{enquiry.company.toLowerCase().replace(/\s+/g, '')}.com</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Phone</p>
                <p>+1 (555) 123-4567</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default EnquiryDetailsPage;
