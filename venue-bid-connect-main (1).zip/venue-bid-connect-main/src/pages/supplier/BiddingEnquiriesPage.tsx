
import BiddingEnquiriesList from "@/components/supplier/enquiries/BiddingEnquiriesList";

const BiddingEnquiriesPage = () => {
  return <BiddingEnquiriesList />;
};

export default BiddingEnquiriesPage;
