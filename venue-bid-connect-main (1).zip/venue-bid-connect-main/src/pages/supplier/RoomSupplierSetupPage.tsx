
import { useRoomSupplierSetup } from "@/hooks/useRoomSupplierSetup";
import PropertySetupStep from "@/components/supplier/rooms/PropertySetupStep";
import RoomTypesSetupStep from "@/components/supplier/rooms/RoomTypesSetupStep";
import ReviewPublishStep from "@/components/supplier/rooms/ReviewPublishStep";
import { useState } from "react";
import { RoomType } from "@/types/roomSupplier";

const RoomSupplierSetupPage = () => {
  const {
    currentStep,
    propertyDetails,
    roomTypes,
    isPublishing,
    handlePropertySubmit,
    handleRoomTypesSubmit,
    handlePublish,
    handleBack,
    setPropertyDetails,
    setRoomTypes
  } = useRoomSupplierSetup();

  const handleAddRoom = (room: RoomType) => {
    setRoomTypes([...roomTypes, room]);
  };

  const handleEditRoom = (updatedRoom: RoomType) => {
    setRoomTypes(roomTypes.map(room => 
      room.id === updatedRoom.id ? updatedRoom : room
    ));
  };

  const handleDeleteRoom = (id: string) => {
    setRoomTypes(roomTypes.filter(room => room.id !== id));
  };

  const handleGoToPropertyStep = () => {
    // This would set currentStep to 1, but since we can't modify currentStep directly,
    // we'll use handleBack when on step 2
    if (currentStep === 2) {
      handleBack();
    }
  };

  const handleGoToRoomStep = () => {
    // This would set currentStep to 2, but the flow is controlled by the hook
    // Users can navigate back from step 3 to step 2
    if (currentStep === 3) {
      handleBack();
    }
  };

  const handleContinueToReview = () => {
    handleRoomTypesSubmit(roomTypes);
  };

  return (
    <div className="container py-8 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">Room Supplier Setup</h1>
      
      {currentStep === 1 && (
        <PropertySetupStep 
          propertyDetails={propertyDetails}
          onSave={handlePropertySubmit}
        />
      )}
      
      {currentStep === 2 && (
        <RoomTypesSetupStep
          propertyDetails={propertyDetails}
          roomTypes={roomTypes}
          onAddRoom={handleAddRoom}
          onEditRoom={handleEditRoom}
          onDeleteRoom={handleDeleteRoom}
          onBack={handleGoToPropertyStep}
          onContinue={handleContinueToReview}
        />
      )}
      
      {currentStep === 3 && (
        <ReviewPublishStep
          propertyDetails={propertyDetails}
          roomTypes={roomTypes}
          onBack={handleGoToRoomStep}
          onPublish={handlePublish}
          isPublishing={isPublishing}
        />
      )}
    </div>
  );
};

export default RoomSupplierSetupPage;
