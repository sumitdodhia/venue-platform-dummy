
import { useConferenceVenueSetup } from "@/hooks/useConferenceVenueSetup";
import VenueSetupStep from "@/components/supplier/conference/VenueSetupStep";
import VenueTypesSetupStep from "@/components/supplier/conference/VenueTypesSetupStep";
import ReviewPublishStep from "@/components/supplier/conference/ReviewPublishStep";

const ConferenceVenueSetupPage = () => {
  const {
    venueDetails,
    venueTypes,
    step,
    isPublishing,
    handleVenueSave,
    handleAddVenue,
    handleEditVenue,
    handleDeleteVenue,
    handleSubmit,
    handleGoToVenueStep,
    handleGoToTypesStep,
    handlePublish
  } = useConferenceVenueSetup();

  return (
    <div className="container py-8 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">Property Setup</h1>
      
      {/* Progress indicator could be added here */}
      
      {step === "venue" && (
        <VenueSetupStep 
          venueDetails={venueDetails}
          onSave={handleVenueSave}
        />
      )}
      
      {step === "types" && (
        <VenueTypesSetupStep
          venueDetails={venueDetails}
          venueTypes={venueTypes}
          onAddVenue={handleAddVenue}
          onEditVenue={handleEditVenue}
          onDeleteVenue={handleDeleteVenue}
          onBack={handleGoToVenueStep}
          onContinue={handleSubmit}
        />
      )}
      
      {step === "review" && (
        <ReviewPublishStep
          venueDetails={venueDetails}
          venueTypes={venueTypes}
          onBack={handleGoToTypesStep}
          onPublish={handlePublish}
          isPublishing={isPublishing}
        />
      )}
    </div>
  );
};

export default ConferenceVenueSetupPage;
