
import { useParams, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/context/AuthContext';

const VenueEditPage = () => {
  const { venueId } = useParams<{ venueId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [venue, setVenue] = useState<any>(null);

  useEffect(() => {
    if (venueId && user) {
      fetchVenue();
    }
  }, [venueId, user]);

  const fetchVenue = async () => {
    if (!venueId || !user) return;
    
    setIsLoading(true);
    try {
      console.log("Fetching venue with ID:", venueId);
      
      const { data, error } = await supabase
        .from('venues')
        .select('*')
        .eq('id', venueId)
        .eq('owner_id', user.id)
        .single();

      if (error) {
        console.error('Error fetching venue:', error);
        if (error.code === 'PGRST116') {
          toast.error('Venue not found or you do not have permission to edit it');
        } else {
          toast.error('Failed to load venue: ' + error.message);
        }
        navigate('/supplier/venues');
        return;
      }

      if (data) {
        console.log("Venue data loaded:", data);
        setVenue(data);
      }
    } catch (error) {
      console.error('Error fetching venue:', error);
      toast.error('Failed to load venue');
      navigate('/supplier/venues');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!venueId || !venue || !user) return;

    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('venues')
        .update({
          name: venue.name,
          type: venue.type,
          description: venue.description,
          location: venue.location,
          capacity: venue.capacity,
          price_from: venue.price_from,
        })
        .eq('id', venueId)
        .eq('owner_id', user.id);

      if (error) {
        console.error('Error updating venue:', error);
        toast.error('Failed to update venue: ' + error.message);
        return;
      }

      toast.success('Venue updated successfully');
      navigate('/supplier/venues');
    } catch (error) {
      console.error('Error updating venue:', error);
      toast.error('Failed to update venue');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <p>Loading venue...</p>
      </div>
    );
  }

  if (!venue) {
    return (
      <div className="container mx-auto px-4 py-8">
        <p>Venue not found</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Button variant="outline" onClick={() => navigate('/supplier/venues')} className="mb-4">
          Back to venues
        </Button>
        <h1 className="text-3xl font-bold">Edit Venue</h1>
      </div>

      <Card className="max-w-2xl">
        <CardHeader>
          <CardTitle>Venue Details</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSave} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="name">Venue Name</Label>
              <Input
                id="name"
                value={venue.name || ''}
                onChange={(e) => setVenue({...venue, name: e.target.value})}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="type">Venue Type</Label>
              <Input
                id="type"
                value={venue.type || ''}
                onChange={(e) => setVenue({...venue, type: e.target.value})}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                value={venue.location || ''}
                onChange={(e) => setVenue({...venue, location: e.target.value})}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="capacity">Capacity</Label>
              <Input
                id="capacity"
                type="number"
                value={venue.capacity || ''}
                onChange={(e) => setVenue({...venue, capacity: parseInt(e.target.value) || 0})}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="price_from">Price From</Label>
              <Input
                id="price_from"
                type="number"
                value={venue.price_from || ''}
                onChange={(e) => setVenue({...venue, price_from: parseFloat(e.target.value) || 0})}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={venue.description || ''}
                onChange={(e) => setVenue({...venue, description: e.target.value})}
                rows={4}
              />
            </div>

            <div className="flex justify-end space-x-4">
              <Button type="button" variant="outline" onClick={() => navigate('/supplier/venues')}>
                Cancel
              </Button>
              <Button type="submit" disabled={isSaving}>
                {isSaving ? 'Saving...' : 'Save Changes'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default VenueEditPage;
