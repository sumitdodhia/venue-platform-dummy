import { useParams } from 'react-router-dom';
import VenueForm from "@/components/supplier/VenueForm";
import VenueTypeSelection from "@/components/supplier/VenueTypeSelection";

const VenueFormPage = () => {
  const { venueType } = useParams();
  
  // If no venue type is selected, show the selection screen
  if (!venueType) {
    return <VenueTypeSelection />;
  }
  
  // Otherwise show the appropriate form
  return <VenueForm venueType={venueType} />;
};

export default VenueFormPage;
