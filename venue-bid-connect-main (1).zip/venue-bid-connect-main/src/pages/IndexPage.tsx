
import React from "react";
import Hero from "@/components/home/Hero";
import Features from "@/components/home/Features";
import HowItWorks from "@/components/home/HowItWorks";
import Testimonials from "@/components/home/Testimonials";
import SupplierCTA from "@/components/home/SupplierCTA";
import Newsletter from "@/components/home/Newsletter";

const IndexPage = () => {
  return (
    <div className="container mx-auto">
      <Hero />
      <Features />
      <HowItWorks />
      <Testimonials />
      <SupplierCTA />
      <Newsletter />
    </div>
  );
};

export default IndexPage;
