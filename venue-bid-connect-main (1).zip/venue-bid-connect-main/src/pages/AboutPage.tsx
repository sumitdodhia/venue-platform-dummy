
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Target, Award } from "lucide-react";

const AboutPage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-8">About FindToTable</h1>
        
        <div className="prose max-w-none mb-12">
          <p className="text-lg text-center text-muted-foreground mb-8">
            FindToTable is a revolutionary platform connecting event organizers with the perfect venues and suppliers for their needs.
          </p>
        </div>
        
        <div className="grid gap-8 md:grid-cols-3 mb-12">
          <Card className="text-center">
            <CardHeader>
              <Target className="h-12 w-12 mx-auto mb-4 text-primary" />
              <CardTitle>Our Mission</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                To simplify event planning by connecting clients with the perfect venues through a transparent, competitive marketplace.
              </p>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardHeader>
              <Users className="h-12 w-12 mx-auto mb-4 text-primary" />
              <CardTitle>Our Team</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                A dedicated team of event industry professionals committed to making venue booking seamless and efficient.
              </p>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardHeader>
              <Award className="h-12 w-12 mx-auto mb-4 text-primary" />
              <CardTitle>Our Values</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Transparency, quality, and exceptional service drive everything we do to ensure successful events.
              </p>
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Why Choose FindToTable?</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>
              FindToTable revolutionizes the way events are planned by providing a comprehensive platform where clients can discover, compare, and book venues with ease. Our innovative bidding system ensures competitive pricing while maintaining quality standards.
            </p>
            <p>
              Whether you're planning a corporate conference, wedding reception, or private dinner, FindToTable connects you with verified suppliers who understand your needs and can deliver exceptional experiences.
            </p>
            <p>
              For suppliers, we provide tools to showcase your venues effectively, manage enquiries efficiently, and grow your business through our extensive network of event planners and corporate clients.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AboutPage;
