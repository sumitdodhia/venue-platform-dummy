
import { supabase } from '@/integrations/supabase/client';
import { EnquiryFormData, EnquirySubmitResponse } from '@/components/enquiry/types';
import { toast } from 'sonner';

export const submitEnquiry = async (formData: EnquiryFormData): Promise<EnquirySubmitResponse> => {
  try {
    // Get current user
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      return {
        success: false,
        error: 'You must be logged in to submit an enquiry'
      };
    }

    // Determine the category based on form data
    let category: 'conference' | 'rooms' | 'restaurants' | 'catering' = 'conference';
    
    if (formData.checkInDate && formData.checkOutDate) {
      category = 'rooms';
    } else if (formData.reservationDate) {
      category = 'restaurants';
    }
    
    // Insert base enquiry
    const { data: enquiryData, error: enquiryError } = await supabase
      .from('enquiries')
      .insert({
        title: formData.title,
        company: formData.company,
        category: category,
        user_id: user.id,
        budget: formData.budget,
        requirements: formData.requirements,
        deadline: formData.deadline,
        status: 'new'
      })
      .select('id')
      .single();
    
    if (enquiryError || !enquiryData) {
      console.error('Error submitting enquiry:', enquiryError);
      return {
        success: false,
        error: enquiryError?.message || 'Failed to submit enquiry'
      };
    }
    
    const enquiryId = enquiryData.id;
    
    // Insert category-specific details
    if (category === 'conference' && formData.date && formData.guests) {
      const { error: conferenceError } = await supabase
        .from('conference_enquiries')
        .insert({
          enquiry_id: enquiryId,
          date: formData.date,
          guests: formData.guests
        });
      
      if (conferenceError) {
        console.error('Error submitting conference details:', conferenceError);
        return {
          success: false,
          error: conferenceError.message
        };
      }
    } else if (category === 'rooms' && formData.checkInDate && formData.checkOutDate && formData.roomCount && formData.city && formData.country) {
      const { error: roomError } = await supabase
        .from('room_enquiries')
        .insert({
          enquiry_id: enquiryId,
          check_in_date: formData.checkInDate,
          check_out_date: formData.checkOutDate,
          room_count: formData.roomCount,
          room_type: formData.roomType || 'Any',
          meal_plan: formData.mealPlan,
          city: formData.city,
          country: formData.country
        });
      
      if (roomError) {
        console.error('Error submitting room details:', roomError);
        return {
          success: false,
          error: roomError.message
        };
      }
    }
    
    return {
      success: true,
      enquiryId
    };
  } catch (error: any) {
    console.error('Error in submitEnquiry:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

export const getEnquiries = async () => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      return {
        success: false,
        error: 'You must be logged in to view your enquiries'
      };
    }
    
    const { data, error } = await supabase
      .from('enquiries')
      .select(`
        *,
        conference_enquiries(*),
        room_enquiries(*)
      `)
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error('Error fetching enquiries:', error);
      return {
        success: false,
        error: error.message
      };
    }
    
    return {
      success: true,
      data
    };
  } catch (error: any) {
    console.error('Error in getEnquiries:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

export const getEnquiry = async (enquiryId: string) => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      return {
        success: false,
        error: 'You must be logged in to view this enquiry'
      };
    }
    
    const { data, error } = await supabase
      .from('enquiries')
      .select(`
        *,
        conference_enquiries(*),
        room_enquiries(*)
      `)
      .eq('id', enquiryId)
      .maybeSingle();
    
    if (error) {
      console.error('Error fetching enquiry:', error);
      return {
        success: false,
        error: error.message
      };
    }
    
    if (!data) {
      return {
        success: false,
        error: 'Enquiry not found'
      };
    }
    
    return {
      success: true,
      data
    };
  } catch (error: any) {
    console.error('Error in getEnquiry:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

export const getSupplierEnquiries = async () => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      return {
        success: false,
        error: 'You must be logged in to view enquiries'
      };
    }
    
    const { data, error } = await supabase
      .from('enquiries')
      .select(`
        *,
        conference_enquiries(*),
        room_enquiries(*)
      `)
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error('Error fetching supplier enquiries:', error);
      return {
        success: false,
        error: error.message
      };
    }
    
    return {
      success: true,
      data
    };
  } catch (error: any) {
    console.error('Error in getSupplierEnquiries:', error);
    return {
      success: false,
      error: error.message
    };
  }
};
