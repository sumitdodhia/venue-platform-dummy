
import { RestaurantDetails, DiningSection, DiningPackage } from "@/types/restaurantSupplier";
import { RestaurantVenue } from "@/types/venue";

const RESTAURANT_STORAGE_KEY = "venueApp_restaurant";
const DINING_SECTIONS_STORAGE_KEY = "venueApp_restaurant_sections";
const DINING_PACKAGES_STORAGE_KEY = "venueApp_restaurant_packages";

// Helper function to optimize images
const optimizeImages = (photos: string[]): string[] => {
  return photos.slice(0, 3);
};

// Get restaurant from local storage
export const getRestaurant = (): RestaurantDetails | null => {
  try {
    const storedRestaurant = localStorage.getItem(RESTAURANT_STORAGE_KEY);
    const storedSections = localStorage.getItem(DINING_SECTIONS_STORAGE_KEY);
    const storedPackages = localStorage.getItem(DINING_PACKAGES_STORAGE_KEY);
    
    if (!storedRestaurant) return null;
    
    const restaurantData = JSON.parse(storedRestaurant);
    const sections = storedSections ? JSON.parse(storedSections) : [];
    const packages = storedPackages ? JSON.parse(storedPackages) : [];
    
    return {
      ...restaurantData,
      sections,
      packages
    };
  } catch (error) {
    console.error("Error loading restaurant data:", error);
    return null;
  }
};

// Save restaurant to local storage
export const saveRestaurant = (restaurantDetails: Partial<RestaurantDetails>): void => {
  try {
    // Optimize images to reduce storage size
    const optimizedPhotos = restaurantDetails.photos ? optimizeImages(restaurantDetails.photos) : [];
    
    // Create restaurant with ID if it doesn't exist
    const restaurantWithId = {
      ...restaurantDetails,
      photos: optimizedPhotos,
      id: restaurantDetails.id || `restaurant-${Date.now()}`
    };
    
    localStorage.setItem(RESTAURANT_STORAGE_KEY, JSON.stringify(restaurantWithId));
  } catch (error) {
    console.error("Error saving restaurant details:", error);
    throw error;
  }
};

// Save dining sections
export const saveDiningSections = (sections: DiningSection[]): void => {
  try {
    localStorage.setItem(DINING_SECTIONS_STORAGE_KEY, JSON.stringify(sections));
  } catch (error) {
    console.error("Error saving dining sections:", error);
    throw error;
  }
};

// Save dining packages
export const saveDiningPackages = (packages: DiningPackage[]): void => {
  try {
    localStorage.setItem(DINING_PACKAGES_STORAGE_KEY, JSON.stringify(packages));
  } catch (error) {
    console.error("Error saving dining packages:", error);
    throw error;
  }
};

// Convert restaurant to venue format for marketplace
export const convertRestaurantToVenue = (restaurantDetails: RestaurantDetails): RestaurantVenue | null => {
  if (!restaurantDetails) return null;
  
  const defaultPhoto = "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=1770&auto=format&fit=crop&ixlib=rb-4.0.3";
  
  // Format sections to ensure they have the correct photo structure
  const sections = restaurantDetails.sections?.map(section => ({
    ...section,
    // Ensure photos array exists if there's at least a main photo
    photos: section.photos || (section.photo ? [section.photo] : [])
  })) || [];
  
  return {
    id: restaurantDetails.id,
    title: restaurantDetails.name,
    location: restaurantDetails.location ? 
      `${restaurantDetails.location.city}, ${restaurantDetails.location.country}` : 
      "Location not specified",
    price: restaurantDetails.packages && restaurantDetails.packages.length > 0 ? 
      Math.min(...restaurantDetails.packages.map(p => p.pricePerPerson)) : 
      25,
    priceLabel: "/person",
    rating: restaurantDetails.rating || 4.5,
    imageUrl: restaurantDetails.photos && restaurantDetails.photos.length > 0 ? 
      restaurantDetails.photos[0] : defaultPhoto,
    photos: restaurantDetails.photos || [defaultPhoto],
    tags: [
      restaurantDetails.cuisineType, 
      ...(restaurantDetails.facilities || []).slice(0, 3)
    ],
    category: "restaurants" as const,
    description: restaurantDetails.description,
    facilities: restaurantDetails.facilities || [],
    cuisineType: restaurantDetails.cuisineType,
    capacity: restaurantDetails.capacity,
    googleLocation: restaurantDetails.googleMapUrl,
    diningPackages: restaurantDetails.packages || [],
    diningSections: sections,
    priceRange: restaurantDetails.priceRange,
    openingHours: restaurantDetails.openingHours,
  };
};

// Get all restaurants as venues for marketplace
export const getRestaurantsAsVenues = (): RestaurantVenue[] => {
  const restaurant = getRestaurant();
  
  if (!restaurant) return [];
  
  const venue = convertRestaurantToVenue(restaurant);
  return venue ? [venue] : [];
};
