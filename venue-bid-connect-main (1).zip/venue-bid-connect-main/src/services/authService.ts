
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface SignUpParams {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  companyName?: string;
  userType: 'venue' | 'corporate' | 'agent';
  phone?: string;
  city?: string;
  country?: string;
}

export interface SignInParams {
  email: string;
  password: string;
}

export const signUp = async (params: SignUpParams) => {
  try {
    const { email, password, firstName, lastName, companyName, userType, phone, city, country } = params;
    
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          first_name: firstName,
          last_name: lastName,
          company_name: companyName,
          user_type: userType,
          phone,
          city,
          country
        }
      }
    });
    
    if (error) {
      console.error('Error signing up:', error);
      toast.error(error.message);
      return { success: false, error };
    }
    
    toast.success('Successfully signed up! Please check your email to verify your account.');
    return { success: true, user: data.user };
  } catch (error: any) {
    console.error('Error in signUp:', error);
    toast.error(error.message);
    return { success: false, error };
  }
};

export const signIn = async ({ email, password }: SignInParams) => {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });
    
    if (error) {
      console.error('Error signing in:', error);
      toast.error(error.message);
      return { success: false, error };
    }
    
    toast.success('Successfully signed in!');
    return { success: true, user: data.user };
  } catch (error: any) {
    console.error('Error in signIn:', error);
    toast.error(error.message);
    return { success: false, error };
  }
};

export const signOut = async () => {
  try {
    const { error } = await supabase.auth.signOut();
    
    if (error) {
      console.error('Error signing out:', error);
      toast.error(error.message);
      return { success: false, error };
    }
    
    toast.success('Successfully signed out!');
    return { success: true };
  } catch (error: any) {
    console.error('Error in signOut:', error);
    toast.error(error.message);
    return { success: false, error };
  }
};

export const getCurrentUser = async () => {
  try {
    const { data, error } = await supabase.auth.getUser();
    
    if (error) {
      console.error('Error getting user:', error);
      return { success: false, error };
    }
    
    if (!data.user) {
      return { success: false, error: { message: 'No user found' } };
    }
    
    // Get the user's profile
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', data.user.id)
      .single();
    
    if (profileError) {
      console.error('Error getting profile:', profileError);
      return { success: false, error: profileError };
    }
    
    return { success: true, user: data.user, profile };
  } catch (error: any) {
    console.error('Error in getCurrentUser:', error);
    return { success: false, error };
  }
};

export const getUserProfile = async (userId: string) => {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();
    
    if (error) {
      console.error('Error getting profile:', error);
      return { success: false, error };
    }
    
    return { success: true, profile: data };
  } catch (error: any) {
    console.error('Error in getUserProfile:', error);
    return { success: false, error };
  }
};
