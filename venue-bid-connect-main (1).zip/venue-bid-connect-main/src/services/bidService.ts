
import { supabase } from '@/integrations/supabase/client';
import { BidFormValues } from '@/components/supplier/bid/types';
import { toast } from 'sonner';

export const submitBid = async (
  enquiryId: string,
  venueId: string | undefined,
  formData: BidFormValues
): Promise<{ success: boolean; error?: string; bidId?: string }> => {
  try {
    // Get current user
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      return {
        success: false,
        error: 'You must be logged in to submit a bid'
      };
    }

    // Format the data for submission
    const bidData = {
      enquiry_id: enquiryId,
      venue_id: venueId,
      owner_id: user.id,
      price: formData.price,
      venue: formData.venue,
      description: formData.description,
      inclusions: formData.inclusions,
      availability: formData.availability,
      status: 'pending',
      submitted_at: new Date().toISOString()
    };
    
    // Insert bid
    const { data, error } = await supabase
      .from('bids')
      .insert(bidData)
      .select('id')
      .single();
    
    if (error || !data) {
      console.error('Error submitting bid:', error);
      return {
        success: false,
        error: error?.message || 'Failed to submit bid'
      };
    }
    
    return {
      success: true,
      bidId: data.id
    };
  } catch (error: any) {
    console.error('Error in submitBid:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

export const getSupplierBids = async () => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      return {
        success: false,
        error: 'You must be logged in to view your bids'
      };
    }
    
    const { data, error } = await supabase
      .from('bids')
      .select(`
        *,
        enquiries(*)
      `)
      .eq('owner_id', user.id)
      .order('submitted_at', { ascending: false });
    
    if (error) {
      console.error('Error fetching bids:', error);
      return {
        success: false,
        error: error.message
      };
    }
    
    return {
      success: true,
      data
    };
  } catch (error: any) {
    console.error('Error in getSupplierBids:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

export const getBidsForEnquiry = async (enquiryId: string) => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      return {
        success: false,
        error: 'You must be logged in to view bids'
      };
    }
    
    // Check if the user owns the enquiry
    const { data: enquiryData, error: enquiryError } = await supabase
      .from('enquiries')
      .select('user_id')
      .eq('id', enquiryId)
      .single();
    
    if (enquiryError || !enquiryData) {
      console.error('Error checking enquiry ownership:', enquiryError);
      return {
        success: false,
        error: enquiryError?.message || 'Enquiry not found'
      };
    }
    
    if (enquiryData.user_id !== user.id) {
      return {
        success: false,
        error: 'You do not have permission to view bids for this enquiry'
      };
    }
    
    const { data, error } = await supabase
      .from('bids')
      .select(`
        *,
        venues(*)
      `)
      .eq('enquiry_id', enquiryId)
      .order('submitted_at', { ascending: false });
    
    if (error) {
      console.error('Error fetching bids for enquiry:', error);
      return {
        success: false,
        error: error.message
      };
    }
    
    return {
      success: true,
      data
    };
  } catch (error: any) {
    console.error('Error in getBidsForEnquiry:', error);
    return {
      success: false,
      error: error.message
    };
  }
};
