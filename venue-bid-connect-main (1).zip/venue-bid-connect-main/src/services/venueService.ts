
import { supabase } from "@/integrations/supabase/client";

export const createVenue = async (venueData: {
  name: string;
  type: string;
  description: string;
  location: string;
  capacity?: number;
  photos?: string[];
  facilities?: string[];
  price_from?: number;
  rating?: number;
  total_reviews?: number;
}) => {
  try {
    const { data: user } = await supabase.auth.getUser();
    
    if (!user.user) {
      return { success: false, error: { message: "Not authenticated" } };
    }

    const { data, error } = await supabase
      .from("venues")
      .insert({
        name: venueData.name,
        type: venueData.type,
        description: venueData.description,
        location: venueData.location,
        capacity: venueData.capacity,
        photos: venueData.photos || [],
        facilities: venueData.facilities || [],
        price_from: venueData.price_from,
        rating: venueData.rating || 4.5,
        total_reviews: venueData.total_reviews || 0,
        owner_id: user.user.id
      })
      .select();

    if (error) {
      console.error("Error creating venue:", error);
      return { success: false, error };
    }

    return { success: true, data };
  } catch (error) {
    console.error("Error creating venue:", error);
    return { 
      success: false, 
      error: { message: "Failed to create venue" } 
    };
  }
};

export const getVenues = async () => {
  try {
    const { data: user } = await supabase.auth.getUser();
    
    if (!user.user) {
      return { success: false, error: { message: "Not authenticated" } };
    }

    const { data, error } = await supabase
      .from("venues")
      .select()
      .eq("owner_id", user.user.id);

    if (error) {
      console.error("Error fetching venues:", error);
      return { success: false, error };
    }

    return { success: true, data };
  } catch (error) {
    console.error("Error fetching venues:", error);
    return { 
      success: false, 
      error: { message: "Failed to fetch venues" } 
    };
  }
};

export const getVenueById = async (venueId: string) => {
  try {
    const { data, error } = await supabase
      .from("venues")
      .select()
      .eq("id", venueId)
      .single();

    if (error) {
      console.error("Error fetching venue:", error);
      return { success: false, error };
    }

    return { success: true, data };
  } catch (error) {
    console.error("Error fetching venue:", error);
    return { 
      success: false, 
      error: { message: "Failed to fetch venue" } 
    };
  }
};

export const updateVenue = async (venueId: string, venueData: {
  name?: string;
  type?: string;
  description?: string;
  location?: string;
  capacity?: number;
  photos?: string[];
  facilities?: string[];
  price_from?: number;
  rating?: number;
  total_reviews?: number;
}) => {
  try {
    const { data: user } = await supabase.auth.getUser();
    
    if (!user.user) {
      return { success: false, error: { message: "Not authenticated" } };
    }

    const { data, error } = await supabase
      .from("venues")
      .update(venueData)
      .eq("id", venueId)
      .eq("owner_id", user.user.id)
      .select();

    if (error) {
      console.error("Error updating venue:", error);
      return { success: false, error };
    }

    return { success: true, data };
  } catch (error) {
    console.error("Error updating venue:", error);
    return { 
      success: false, 
      error: { message: "Failed to update venue" } 
    };
  }
};

export const deleteVenue = async (venueId: string) => {
  try {
    const { data: user } = await supabase.auth.getUser();
    
    if (!user.user) {
      return { success: false, error: { message: "Not authenticated" } };
    }

    console.log(`Attempting to delete venue ${venueId} for user ${user.user.id}`);

    // First verify the venue exists and belongs to the user
    const { data: existingVenue, error: fetchError } = await supabase
      .from("venues")
      .select("id")
      .eq("id", venueId)
      .eq("owner_id", user.user.id)
      .single();

    if (fetchError) {
      console.error("Error checking venue ownership:", fetchError);
      return { success: false, error: { message: "Venue not found or you don't have permission to delete it" } };
    }

    if (!existingVenue) {
      console.error("Venue not found or not owned by user");
      return { success: false, error: { message: "Venue not found or you don't have permission to delete it" } };
    }

    // Now delete the venue
    const { data, error } = await supabase
      .from("venues")
      .delete()
      .eq("id", venueId)
      .eq("owner_id", user.user.id)
      .select();

    if (error) {
      console.error("Error deleting venue:", error);
      return { success: false, error };
    }

    console.log("Venue deleted successfully:", data);
    return { success: true, data };
  } catch (error) {
    console.error("Error deleting venue:", error);
    return { 
      success: false, 
      error: { message: "Failed to delete venue" } 
    };
  }
};

// Update the property service to save room properties to database as well
export const saveRoomPropertyToDatabase = async (propertyDetails: any, roomTypes: any[]) => {
  try {
    const { data: user } = await supabase.auth.getUser();
    
    if (!user.user) {
      return { success: false, error: { message: "Not authenticated" } };
    }

    // Create venue entry for the room property
    const venueData = {
      name: propertyDetails.name,
      type: 'rooms',
      description: propertyDetails.about,
      location: `${propertyDetails.area}, ${propertyDetails.country}`,
      capacity: propertyDetails.totalRooms,
      photos: propertyDetails.photos || [],
      facilities: propertyDetails.facilities || [],
      price_from: roomTypes.length > 0 ? Math.min(...roomTypes.map(r => r.priceFrom)) : 0,
      rating: propertyDetails.rating || 4.5,
      total_reviews: propertyDetails.ratingCount || 0,
    };

    return await createVenue(venueData);
  } catch (error) {
    console.error("Error saving room property to database:", error);
    return { 
      success: false, 
      error: { message: "Failed to save room property" } 
    };
  }
};
