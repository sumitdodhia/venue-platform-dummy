// Store property data in local storage to persist between sessions
import { PropertyDetails, RoomType } from "@/types/roomSupplier";
import { RoomVenue } from "@/types/venue";
import { saveRoomPropertyToDatabase } from "./venueService";

const PROPERTY_STORAGE_KEY = "venueApp_properties";
const ROOMS_STORAGE_KEY = "venueApp_roomTypes";

// Helper function to reduce image sizes before storage
const optimizeImages = (photos: string[]): string[] => {
  // For this implementation, we'll just limit the number of photos to reduce storage size
  // In a real app, you would resize/compress the images
  return photos.slice(0, 2);
};

// Get properties from local storage
export const getProperties = (): PropertyDetails[] => {
  const storedProperties = localStorage.getItem(PROPERTY_STORAGE_KEY);
  return storedProperties ? JSON.parse(storedProperties) : [];
};

// Add a property to local storage
export const saveProperty = (propertyDetails: PropertyDetails): void => {
  const properties = getProperties();
  
  // Optimize images to reduce storage size
  const optimizedPhotos = optimizeImages(propertyDetails.photos || []);
  
  // Generate an ID if not provided
  const propertyWithId = {
    ...propertyDetails,
    photos: optimizedPhotos,
    id: propertyDetails.id || `property-${Date.now()}`
  };
  
  // Update if exists, otherwise add
  const updatedProperties = propertyDetails.id 
    ? properties.map(p => p.id === propertyDetails.id ? propertyWithId : p)
    : [...properties, propertyWithId];
  
  try {
    localStorage.setItem(PROPERTY_STORAGE_KEY, JSON.stringify(updatedProperties));
  } catch (error) {
    console.error("Error saving property to localStorage:", error);
    throw new Error("Failed to save property. Storage quota may be exceeded.");
  }
};

// Publish property to both local storage and database
export const publishProperty = async (propertyDetails: PropertyDetails, roomTypes: RoomType[]) => {
  try {
    // Save to local storage first
    saveProperty(propertyDetails);
    saveRoomTypes(roomTypes, propertyDetails.id);
    
    // Also save to database
    const result = await saveRoomPropertyToDatabase(propertyDetails, roomTypes);
    
    if (!result.success) {
      console.error("Failed to save to database:", result.error);
      // Still continue - local storage save was successful
    }
    
    return { success: true };
  } catch (error) {
    console.error("Error publishing property:", error);
    return { success: false, error };
  }
};

// Get room types from local storage
export const getRoomTypes = (): RoomType[] => {
  const storedRoomTypes = localStorage.getItem(ROOMS_STORAGE_KEY);
  return storedRoomTypes ? JSON.parse(storedRoomTypes) : [];
};

// Save room types to local storage
export const saveRoomTypes = (roomTypes: RoomType[], propertyId?: string): void => {
  // Optimize room images to reduce storage
  const optimizedRoomTypes = roomTypes.map(room => ({
    ...room,
    photos: optimizeImages(room.photos || [])
  }));
  
  // If propertyId is provided, associate rooms with this property
  const roomsWithProperty = propertyId 
    ? optimizedRoomTypes.map(room => ({ ...room, propertyId }))
    : optimizedRoomTypes;
  
  try {
    localStorage.setItem(ROOMS_STORAGE_KEY, JSON.stringify(roomsWithProperty));
  } catch (error) {
    console.error("Error saving room types to localStorage:", error);
    throw new Error("Failed to save room types. Storage quota may be exceeded. Try using fewer or smaller images.");
  }
};

// Get property rooms by property ID
export const getPropertyRooms = (propertyId: string): RoomType[] => {
  const allRooms = getRoomTypes();
  return allRooms.filter(room => room.propertyId === propertyId);
};

// Calculate total rooms for validation
export const calculateTotalRoomsForProperty = (propertyId: string): number => {
  const rooms = getPropertyRooms(propertyId);
  return rooms.reduce((total, room) => total + room.numberOfRooms, 0);
};

// Validate that sum of room type counts doesn't exceed total property rooms
export const validateRoomCounts = (propertyId: string, totalRooms: number): boolean => {
  const calculatedTotal = calculateTotalRoomsForProperty(propertyId);
  return calculatedTotal <= totalRooms;
};

// Convert property details to venue format for marketplace display
export const convertPropertyToVenue = (property: PropertyDetails, rooms: RoomType[]): RoomVenue => {
  // Find the lowest price from all room types
  const lowestPriceRoom = rooms.length > 0 
    ? rooms.reduce((min, room) => room.priceFrom < min.priceFrom ? room : min, rooms[0]) 
    : null;
  
  return {
    id: property.id || `property-${Date.now()}`,
    title: property.name,
    location: `${property.area}, ${property.country}`,
    price: lowestPriceRoom ? lowestPriceRoom.priceFrom : 0,
    priceLabel: "/night",
    rating: property.rating || 4.5,
    totalReviews: property.ratingCount || 0,
    imageUrl: property.photos && property.photos.length > 0 
      ? property.photos[0] 
      : "https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=1770&auto=format&fit=crop&ixlib=rb-4.0.3",
    photos: property.photos || [],
    tags: property.facilities || [],
    category: "rooms" as const,
    about: property.about,
    description: property.about,
    basisOffered: property.basisOffered || [],
    facilities: property.facilities || [],
    totalRooms: property.totalRooms || 0,
    googleLocation: property.googleLocation || "",
    rooms: rooms
  };
};

// Get all properties formatted as venues for marketplace
export const getPropertiesAsVenues = (): RoomVenue[] => {
  const properties = getProperties();
  const allRooms = getRoomTypes();
  
  return properties.map(property => {
    const propertyRooms = allRooms.filter(room => room.propertyId === property.id);
    return convertPropertyToVenue(property, propertyRooms);
  });
};

// Add validation to the Room Supplier Setup
export const validatePropertySetup = (property: PropertyDetails, rooms: RoomType[]): { valid: boolean; message?: string } => {
  // Ensure total rooms is set
  if (!property.totalRooms || property.totalRooms <= 0) {
    return { 
      valid: false, 
      message: "Total number of rooms must be greater than 0" 
    };
  }
  
  // Calculate total from room types
  const totalFromRoomTypes = rooms.reduce((sum, room) => sum + room.numberOfRooms, 0);
  
  // Validate room counts
  if (totalFromRoomTypes > property.totalRooms) {
    return { 
      valid: false, 
      message: `Sum of rooms by type (${totalFromRoomTypes}) exceeds total property rooms (${property.totalRooms})` 
    };
  }
  
  return { valid: true };
};
